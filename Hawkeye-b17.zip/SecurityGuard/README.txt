Rifat's Hawkeye 2.0.3.11 (zip: Hawkeye-b17.zip)
Version rule: 2.0.2.14 -> 2.0.2.14 -> 2.0.2.15 -> 2.0.3.11 ... 2.0.3.15 -> 2.0.4.11 ...
GitHub Actions unzips every Hawkeye-*.zip in name order, so always upload a higher number.
b17: app reads the data repo link by default; learned model is blended with built-in rules.
hawkeye-data/ holds the latest data-repo files (optional, only for the weekly model training).

package com.rifat.guard

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.app.KeyguardManager
import android.app.NotificationManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.location.Location
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

// ফোনের অ্যাডমিন (দূর থেকে লক করার জন্য)
class GuardAdmin : DeviceAdminReceiver() {
    override fun onPasswordFailed(context: Context, intent: Intent) { Guard.wrongPass(context.applicationContext) }
    override fun onPasswordSucceeded(context: Context, intent: Intent) { Store.put(context.applicationContext, "g_fail", "0") }
    override fun onDisabled(context: Context, intent: Intent) { Guard.adminOff(context.applicationContext) }
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence = "Turning this off removes remote lock and anti-theft protection."
}

// চুরি হলে SMS দিয়ে ফোন নিয়ন্ত্রণ: HAWK <কোড> RING | STOP | LOCATE | LOCK | INFO
object Theft {
    private val re = Regex("(?i)^\\s*HAWK\\s+(\\S+)\\s+(\\w+)(?:\\s+(.*?))?\\s*$")

    fun enabled(ctx: Context) = Store.on(ctx, "theft_on", false)
    fun code(ctx: Context) = Store.get(ctx, "theft_code")
    fun num(ctx: Context) = Store.get(ctx, "theft_num")

    fun isCommand(ctx: Context, body: String): Boolean {
        if (!enabled(ctx)) return false
        val m = re.find(body) ?: return false
        val c = code(ctx)
        return c.length >= 6 && m.groupValues[1] == c
    }

    @Volatile var flashing = false

    fun run(ctx: Context, sender: String, body: String) {
        val m = re.find(body) ?: return
        val cmd = m.groupValues[2].uppercase()
        val arg = m.groupValues[3].trim()
        when (cmd) {
            "RING" -> { ring(ctx); reply(ctx, sender, "Hawkeye: alarm started. Send HAWK <code> STOP to stop it.") }
            "STOP" -> { stopRing(ctx); flashing = false; reply(ctx, sender, "Hawkeye: alarm stopped.") }
            "LOCATE" -> locate(ctx, sender)
            "LOCK" -> reply(ctx, sender, if (lock(ctx)) "Hawkeye: phone locked." else "Hawkeye: cannot lock, Device admin is not enabled on the phone.")
            "INFO" -> reply(ctx, sender, info(ctx))
            "STATUS" -> reply(ctx, sender, status(ctx))
            "PING" -> reply(ctx, sender, "Hawkeye: phone is online.")
            "FLASH" -> { flash(ctx, 60); reply(ctx, sender, "Hawkeye: flashlight is blinking. Send STOP to end it.") }
            "TRACK" -> {
                val hrs = (arg.toIntOrNull() ?: 6).coerceIn(1, 72)
                track(ctx, sender, hrs)
                reply(ctx, sender, "Hawkeye: tracking for $hrs hours, a location SMS every 10 minutes. Send UNTRACK to stop.")
            }
            "UNTRACK" -> { Store.put(ctx, "g_track_until", "0"); reply(ctx, sender, "Hawkeye: tracking stopped.") }
            "LOST" -> {
                lostMode(ctx, sender, true, arg)
                reply(ctx, sender, "Hawkeye: lost mode ON. Alarm, flashlight and 24-hour tracking started, and your message shows on the lock screen. Send FOUND to end it.")
            }
            "FOUND" -> { lostMode(ctx, sender, false, ""); reply(ctx, sender, "Hawkeye: lost mode OFF.") }
            "ARM" -> { arm(ctx, true); reply(ctx, sender, "Hawkeye: guard armed (motion, charger and SIM alarms).") }
            "DISARM" -> { arm(ctx, false); reply(ctx, sender, "Hawkeye: guard disarmed.") }
            "HELP" -> reply(ctx, sender, "Hawkeye commands: RING STOP LOCATE LOCK INFO STATUS PING FLASH TRACK <hours> UNTRACK LOST <message> FOUND ARM DISARM")
            else -> reply(ctx, sender, "Hawkeye: unknown command. Send HAWK <code> HELP.")
        }
    }

    // ---- ফ্ল্যাশলাইট ঝলক ----
    fun flash(ctx: Context, seconds: Int) {
        flashing = true
        Thread {
            try {
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                if (id != null) {
                    val end = System.currentTimeMillis() + seconds * 1000L
                    var on = false
                    while (flashing && System.currentTimeMillis() < end) { on = !on; cm.setTorchMode(id, on); Thread.sleep(250) }
                    cm.setTorchMode(id, false)
                }
            } catch (e: Exception) { }
            flashing = false
        }.start()
    }

    // ---- বিস্তারিত অবস্থা ----
    fun status(ctx: Context): String {
        val bi = ctx.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lv = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val ch = (bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1) == BatteryManager.BATTERY_STATUS_CHARGING
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
        val net = when {
            caps == null -> "offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            else -> "other"
        }
        val lm = ctx.getSystemService(LocationManager::class.java)
        val gps = try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (e: Exception) { false }
        val locked = try { ctx.getSystemService(KeyguardManager::class.java).isKeyguardLocked } catch (e: Exception) { false }
        val loc = lastKnown(ctx)?.let { fmt(it) } ?: "no location saved"
        return "Hawkeye status: battery $lv%${if (ch) " (charging)" else ""}, network $net, GPS ${if (gps) "on" else "off"}, screen ${if (locked) "locked" else "unlocked"}, ${Build.MODEL}. Last location: $loc"
    }

    // ---- ট্র্যাকিং ----
    fun track(ctx: Context, to: String, hours: Int) {
        Store.put(ctx, "g_track_until", (System.currentTimeMillis() + hours * 3600000L).toString())
        Store.put(ctx, "g_track_to", to)
        Store.put(ctx, "g_track_next", "0")
        GuardService.start(ctx)
    }

    // ---- হারানো মোড ----
    fun lostMode(ctx: Context, to: String, on: Boolean, msg: String) {
        Store.setOn(ctx, "g_lost", on)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (on) {
            val text = if (msg.isNotBlank()) msg else Store.get(ctx, "g_lost_msg").ifBlank { "This phone is lost. Please call " + num(ctx) }
            Alerts.init(ctx)
            nm.notify(9100, Notification.Builder(ctx, Alerts.CH_ALERT)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("LOST PHONE")
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build())
            ring(ctx); flash(ctx, 30); track(ctx, to, 24)
        } else {
            nm.cancel(9100); stopRing(ctx); flashing = false
            Store.put(ctx, "g_track_until", "0")
        }
    }

    // ---- পাহারা চালু/বন্ধ ----
    fun arm(ctx: Context, on: Boolean) {
        Store.setOn(ctx, "g_armed", on)
        if (on) Store.put(ctx, "g_armed_at", System.currentTimeMillis().toString())
        GuardService.refresh(ctx)
    }

    fun bestLocation(ctx: Context): Location? {
        if (!hasLoc(ctx)) return null
        return current(ctx, LocationManager.GPS_PROVIDER, 15) ?: current(ctx, LocationManager.NETWORK_PROVIDER, 10) ?: lastKnown(ctx)
    }

    fun locateQuiet(ctx: Context, to: String) {
        Thread { val f = bestLocation(ctx); if (f != null) reply(ctx, to, "Hawkeye: location " + fmt(f)) }.start()
    }

    fun setHome(ctx: Context): Boolean {
        val l = lastKnown(ctx) ?: bestLocation(ctx) ?: return false
        Store.put(ctx, "g_home_lat", l.latitude.toString())
        Store.put(ctx, "g_home_lon", l.longitude.toString())
        return true
    }

    fun reply(ctx: Context, to: String, text: String) {
        if (to.isBlank() || ctx.checkSelfPermission("android.permission.SEND_SMS") != 0) return
        try {
            @Suppress("DEPRECATION") val sm = SmsManager.getDefault()
            sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null)
        } catch (e: Exception) { }
    }

    private fun info(ctx: Context): String {
        val i = ctx.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lv = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val ch = (i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1) == BatteryManager.BATTERY_STATUS_CHARGING
        return "Hawkeye: battery $lv%${if (ch) " (charging)" else ""}, ${Build.MANUFACTURER} ${Build.MODEL}."
    }

    // ---- জোরে অ্যালার্ম ----
    fun ring(ctx: Context) {
        try { ctx.startForegroundService(Intent(ctx, TheftService::class.java).setAction("RING")) }
        catch (e: Exception) { TheftService.playDirect(ctx, 9000) }
    }

    fun stopRing(ctx: Context) {
        TheftService.stopPlayer()
        try { ctx.stopService(Intent(ctx, TheftService::class.java)) } catch (e: Exception) { }
    }

    // ---- লোকেশন ----
    private fun hasLoc(ctx: Context) = ctx.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0

    private fun fmt(l: Location): String {
        val age = ((System.currentTimeMillis() - l.time) / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "https://maps.google.com/?q=%.6f,%.6f (accuracy %dm, %ds old)", l.latitude, l.longitude, l.accuracy.toInt(), age)
    }

    private fun lastKnown(ctx: Context): Location? {
        if (!hasLoc(ctx)) return null
        val lm = ctx.getSystemService(LocationManager::class.java)
        return try { lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time } } catch (e: Exception) { null }
    }

    private fun current(ctx: Context, provider: String, secs: Long): Location? {
        if (Build.VERSION.SDK_INT < 30) return null
        val lm = ctx.getSystemService(LocationManager::class.java)
        val latch = CountDownLatch(1)
        var res: Location? = null
        try {
            if (!lm.isProviderEnabled(provider)) return null
            lm.getCurrentLocation(provider, null, ctx.mainExecutor) { l -> res = l; latch.countDown() }
        } catch (e: Exception) { return null }
        latch.await(secs, TimeUnit.SECONDS)
        return res
    }

    fun locate(ctx: Context, to: String) {
        if (!hasLoc(ctx)) { reply(ctx, to, "Hawkeye: location permission is not granted on the phone."); return }
        val last = lastKnown(ctx)
        reply(ctx, to, if (last != null) "Hawkeye: last known location " + fmt(last) else "Hawkeye: no saved location, trying to get a fresh one...")
        Thread {
            val f = current(ctx, LocationManager.GPS_PROVIDER, 25) ?: current(ctx, LocationManager.NETWORK_PROVIDER, 15)
            if (f != null) reply(ctx, to, "Hawkeye: current location " + fmt(f))
        }.start()
    }

    // ---- লক ----
    fun adminActive(ctx: Context): Boolean = try {
        ctx.getSystemService(DevicePolicyManager::class.java).isAdminActive(ComponentName(ctx, GuardAdmin::class.java))
    } catch (e: Exception) { false }

    fun lock(ctx: Context): Boolean {
        if (!adminActive(ctx)) return false
        return try { ctx.getSystemService(DevicePolicyManager::class.java).lockNow(); true } catch (e: Exception) { false }
    }

    fun adminIntent(ctx: Context): Intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(ctx, GuardAdmin::class.java))
        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Lets Hawkeye lock your phone remotely if it is lost.")

    // ---- সিম বদল ----
    private fun simSig(ctx: Context): String = try {
        val l = ctx.getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList
        l?.joinToString("|") { "${it.subscriptionId}:${it.carrierName}:${it.mccString}${it.mncString}" } ?: ""
    } catch (e: Throwable) { "" }

    fun saveSim(ctx: Context) { val s = simSig(ctx); if (s.isNotEmpty()) Store.put(ctx, "theft_sim", s) }

    fun checkSim(ctx: Context) {
        if (!enabled(ctx)) return
        val now = simSig(ctx)
        val old = Store.get(ctx, "theft_sim")
        if (old.isEmpty()) { if (now.isNotEmpty()) Store.put(ctx, "theft_sim", now); return }
        if (now.isNotEmpty() && now != old) {
            Store.put(ctx, "theft_sim", now)
            val n = num(ctx)
            if (n.isNotBlank()) { reply(ctx, n, "Hawkeye ALERT: the SIM card in your phone was changed."); locate(ctx, n) }
        }
    }
}

// অ্যালার্ম বাজানোর সার্ভিস
class TheftService : Service() {
    companion object {
        private var player: MediaPlayer? = null
        private val h = Handler(Looper.getMainLooper())

        fun play(ctx: Context) {
            stopPlayer()
            try {
                val am = ctx.getSystemService(AudioManager::class.java)
                am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                val p = MediaPlayer()
                p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                p.setDataSource(ctx, uri)
                p.isLooping = true
                p.prepare()
                p.start()
                player = p
            } catch (e: Exception) { }
        }

        fun stopPlayer() {
            try { player?.stop(); player?.release() } catch (e: Exception) { }
            player = null
        }

        fun playDirect(ctx: Context, ms: Long) { play(ctx); h.postDelayed({ stopPlayer() }, ms) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") { stopPlayer(); stopSelf(); return START_NOT_STICKY }
        Alerts.init(this)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, Alerts.CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Hawkeye alarm is ringing")
            .setContentText("Open the app, or SMS: HAWK <code> STOP")
            .setContentIntent(open)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(9, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(9, n)
        } catch (e: Exception) { }
        play(this)
        h.postDelayed({ stopPlayer(); stopSelf() }, 120000)
        return START_NOT_STICKY
    }

    override fun onDestroy() { stopPlayer(); super.onDestroy() }
}

package com.rifat.guard

import android.content.Context
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

// MalwareBazaar-এ সরাসরি জিজ্ঞেস করা: ফোনের তালিকায় না থাকলেও সেখানে ধরা পড়া ম্যালওয়্যার চেনা যায় (Auth-Key লাগে)
object Live {
    private val cache = ConcurrentHashMap<String, String>()
    val budget = AtomicInteger(30)

    // চেনা ম্যালওয়্যার হলে তার পরিবারের নাম ("known" যদি নাম না থাকে), নাহলে null
    fun mbLookup(ctx: Context, sha: String): String? {
        val key = Store.get(ctx, "abuse_key").trim()
        if (key.isEmpty() || sha.length != 64) return null
        val c = cache[sha]
        if (c != null) return if (c.isEmpty()) null else c
        try {
            val headers = mapOf("Auth-Key" to key, "Content-Type" to "application/x-www-form-urlencoded")
            val (code, text) = Net.request("https://mb-api.abuse.ch/api/v1/", "POST", headers, "query=get_info&hash=$sha")
            if (code != 200) return null
            val ok = Regex("\"query_status\"\\s*:\\s*\"ok\"").containsMatchIn(text)
            val fam = Regex("\"signature\"\\s*:\\s*\"([^\"]*)\"").find(text)?.groupValues?.get(1) ?: ""
            val r = if (ok) (if (fam.isBlank() || fam == "null") "known" else fam) else ""
            cache[sha] = r
            return if (r.isEmpty()) null else r
        } catch (e: Exception) {
            return null
        }
    }
}

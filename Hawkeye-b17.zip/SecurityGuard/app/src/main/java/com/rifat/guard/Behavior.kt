package com.rifat.guard

import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.io.File
import kotlin.math.exp

class BehaviorResult(val score: Int, val reasons: List<String>, val features: Map<String, Double>)

// আচরণ-ভিত্তিক শনাক্তকরণ: অ্যাপ এখন সত্যিই কী ক্ষমতা ব্যবহার করছে সেটা দেখা
object Behavior {
    private class Env(val acc: Set<String>, val admins: Set<String>, val listeners: Set<String>, val at: Long)
    @Volatile private var env: Env? = null

    private fun env(ctx: Context): Env {
        val e = env
        if (e != null && System.currentTimeMillis() - e.at < 30000) return e
        val acc = try {
            (Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
                .split(":").filter { it.contains("/") }.map { it.substringBefore("/") }.toSet()
        } catch (x: Exception) { emptySet() }
        val adm = try { ctx.getSystemService(DevicePolicyManager::class.java).activeAdmins?.map { it.packageName }?.toSet() ?: emptySet() } catch (x: Exception) { emptySet() }
        val lis = try { NotificationManagerCompat.getEnabledListenerPackages(ctx) } catch (x: Exception) { emptySet() }
        val n = Env(acc, adm, lis, System.currentTimeMillis())
        env = n
        return n
    }

    private fun overlayOn(ctx: Context, ai: ApplicationInfo): Boolean = try {
        ctx.getSystemService(AppOpsManager::class.java).unsafeCheckOpNoThrow("android:system_alert_window", ai.uid, ai.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    fun analyze(ctx: Context, p: PackageInfo, perms: Set<String>, ai: ApplicationInfo, baseScore: Int): BehaviorResult {
        val e = env(ctx)
        val pkg = p.packageName
        val acc = pkg in e.acc
        val adm = pkg in e.admins
        val lis = pkg in e.listeners
        val ovl = overlayOn(ctx, ai)
        val hidden = baseScore >= 20 && ctx.packageManager.getLaunchIntentForPackage(pkg) == null
        val recent = System.currentTimeMillis() - p.firstInstallTime < 3L * 24 * 3600 * 1000
        val oldSdk = ai.targetSdkVersion < 23
        val sms = "android.permission.READ_SMS" in perms || "android.permission.RECEIVE_SMS" in perms

        var s = 0
        val r = ArrayList<String>()
        if (acc) { s += 20; r += L.t("Accessibility service is switched ON right now", "অ্যাক্সেসিবিলিটি সার্ভিস এখন চালু আছে") }
        if (ovl) { s += 15; r += L.t("Is allowed to draw over other apps right now", "এখন অন্য অ্যাপের ওপর আঁকার অনুমতি পেয়ে আছে") }
        if (adm) { s += 20; r += L.t("Is an active device admin right now", "এখন সক্রিয় ডিভাইস অ্যাডমিন") }
        if (lis) { s += 10; r += L.t("Is reading your notifications right now", "এখন আপনার নোটিফিকেশন পড়ছে") }
        if (hidden) { s += 15; r += L.t("Has no launcher icon (hidden app)", "লঞ্চারে আইকন নেই (লুকানো অ্যাপ)") }
        if (sms && (acc || ovl)) { s += 20; r += L.t("Pattern of a banking trojan: SMS access with screen control", "ব্যাংকিং ট্রোজানের ধরন: SMS অ্যাক্সেসের সাথে স্ক্রিন নিয়ন্ত্রণ") }
        if (recent && baseScore + s >= 30) { s += 10; r += L.t("Installed in the last 3 days", "গত ৩ দিনে ইনস্টল হয়েছে") }
        if (oldSdk) { s += 5; r += L.t("Built for very old Android (skips newer protections)", "খুব পুরনো Android-এর জন্য বানানো (নতুন সুরক্ষা এড়ায়)") }

        fun has(x: String) = if ("android.permission.$x" in perms) 1.0 else 0.0
        fun b(x: Boolean) = if (x) 1.0 else 0.0
        val f = mapOf(
            "acc_on" to b(acc), "overlay_on" to b(ovl), "admin_on" to b(adm), "listener_on" to b(lis),
            "hidden" to b(hidden), "recent" to b(recent), "old_sdk" to b(oldSdk),
            "read_sms" to has("READ_SMS"), "recv_sms" to has("RECEIVE_SMS"), "send_sms" to has("SEND_SMS"),
            "install_pkgs" to has("REQUEST_INSTALL_PACKAGES"), "acc_perm" to has("BIND_ACCESSIBILITY_SERVICE"),
            "overlay_perm" to has("SYSTEM_ALERT_WINDOW"), "admin_perm" to has("BIND_DEVICE_ADMIN"),
            "listener_perm" to has("BIND_NOTIFICATION_LISTENER_SERVICE"), "all_files" to has("MANAGE_EXTERNAL_STORAGE"),
            "mic" to has("RECORD_AUDIO"), "camera" to has("CAMERA"), "contacts" to has("READ_CONTACTS"),
            "call_log" to has("READ_CALL_LOG"), "location" to has("ACCESS_FINE_LOCATION"),
            "debuggable" to b((ai.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0),
            "sideloaded" to 0.0
        )
        return BehaviorResult(s, r, f)
    }
}

// ঝুঁকির মডেল: বৈশিষ্ট্য থেকে সম্ভাবনা বের করে। ডিফল্ট ওজন হাতে বসানো, নিজের ট্রেন করা model.json দিলে সেটা চলে।
object ModelScorer {
    private val builtin = mapOf(
        "acc_on" to 2.5, "overlay_on" to 1.5, "admin_on" to 1.5, "listener_on" to 1.0, "hidden" to 1.0, "recent" to 0.5,
        "old_sdk" to 0.5, "read_sms" to 1.5, "recv_sms" to 1.0, "send_sms" to 1.2, "install_pkgs" to 1.0, "acc_perm" to 1.5,
        "overlay_perm" to 1.0, "admin_perm" to 1.0, "listener_perm" to 0.8, "all_files" to 0.6, "mic" to 0.3, "camera" to 0.2,
        "contacts" to 0.2, "call_log" to 0.4, "location" to 0.2, "debuggable" to 0.5, "sideloaded" to 0.8
    )
    @Volatile private var learned: Map<String, Double>? = null
    @Volatile private var learnedBias = -3.0
    @Volatile private var loaded = false

    private fun file(ctx: Context) = File(ctx.filesDir, "model.json")

    private fun load(ctx: Context) {
        if (loaded) return
        var m: Map<String, Double>? = null
        var bs = -3.0
        try {
            val f = file(ctx)
            if (f.exists()) {
                val j = JSONObject(f.readText())
                val wj = j.getJSONObject("weights")
                val mm = HashMap<String, Double>()
                wj.keys().forEach { k -> mm[k] = wj.getDouble(k) }
                if (mm.isNotEmpty()) { m = mm; bs = j.optDouble("bias", -3.0) }
            }
        } catch (e: Exception) { }
        learnedBias = bs
        learned = m
        loaded = true
    }

    private fun sigmoid(z: Double): Double = 1.0 / (1.0 + exp(-z))

    // শেখা মডেল শুধু F-Droid-এর অ্যাপের সাথে তুলনা করে শেখে, তাই একা ছেড়ে দিলে ভালো অ্যাপকেও সন্দেহ করতে পারে।
    // এজন্য হাতে বসানো নিয়মের সাথে গড় করা হয়, আর চলার সময়ের সংকেত (acc_on, overlay_on ইত্যাদি) নিয়মের ওজনেই থাকে।
    fun prob(ctx: Context, f: Map<String, Double>): Double {
        load(ctx)
        var zb = -3.0
        f.forEach { (k, v) -> zb += (builtin[k] ?: 0.0) * v }
        val pb = sigmoid(zb)
        val lw = learned ?: return pb
        var zl = learnedBias
        f.forEach { (k, v) -> zl += (lw[k] ?: builtin[k] ?: 0.0) * v }
        return (pb + sigmoid(zl)) / 2.0
    }

    fun custom(ctx: Context) = file(ctx).exists()

    // নিজের মডেল ফাইলের লিংক থেকে নামানো (ঐচ্ছিক)
    fun update(ctx: Context): String {
        val url = Store.get(ctx, "model_url").ifBlank { DataHub.modelUrl(ctx) }
        if (url.isBlank()) return ""
        return try {
            val (code, text) = Net.request(url)
            if (code != 200) return L.t("Model: server refused (code $code)", "মডেল: সার্ভার রাজি হয়নি (কোড $code)")
            val j = JSONObject(text)
            j.getJSONObject("weights")
            file(ctx).writeText(text)
            loaded = false
            L.t("Risk model updated", "ঝুঁকির মডেল আপডেট হয়েছে")
        } catch (e: Exception) { L.t("Model file was not valid", "মডেল ফাইল ঠিক ছিল না") }
    }
}

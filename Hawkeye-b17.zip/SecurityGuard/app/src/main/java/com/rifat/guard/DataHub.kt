package com.rifat.guard

import android.content.Context
import java.io.File

// নিজের ডেটা সার্ভার (গিটহাবের public রিপো) থেকে তালিকা ও মডেল নামানো
object DataHub {
    private const val DEFAULT_BASE = "https://raw.githubusercontent.com/rifatmahmud2118-glitch/hawkeye-data/main/"

    fun base(ctx: Context): String {
        val b = Store.get(ctx, "data_base").trim()
        return if (b.isEmpty()) DEFAULT_BASE else b.trimEnd('/') + "/"
    }

    fun modelUrl(ctx: Context): String {
        val b = base(ctx)
        return if (b.isEmpty()) "" else b + "model.json"
    }

    fun refresh(ctx: Context): String {
        val b = base(ctx)
        if (b.isEmpty()) return ""
        val parts = mutableListOf<String>()
        try {
            val (code, text) = Net.request(b + "apk_hashes.txt")
            if (code == 200) {
                val found = HashSet<String>()
                text.lineSequence().forEach { val l = it.trim().lowercase(); if (l.length == 64) found.add(l) }
                val added = SigDb.addHashes(ctx, found)
                parts += L.t("My data: ${found.size} Android hashes, $added new", "আমার ডেটা: ${found.size}টি Android হ্যাশ, নতুন ${added}টি")
            } else parts += L.t("My data: hash list not found (code $code)", "আমার ডেটা: হ্যাশ তালিকা পাওয়া যায়নি (কোড $code)")
        } catch (e: Exception) { parts += L.t("My data: hash list failed", "আমার ডেটা: হ্যাশ তালিকা ব্যর্থ") }
        try {
            val (code, text) = Net.request(b + "bad_urls.txt")
            if (code == 200) {
                File(ctx.filesDir, "bad_urls.txt").writeText(text)
                BadUrls.reset()
                parts += L.t("bad link list updated", "ক্ষতিকর লিংক তালিকা আপডেট হয়েছে")
            }
        } catch (e: Exception) { }
        return parts.joinToString(" • ")
    }
}

// URLhaus থেকে বানানো ক্ষতিকর লিংকের তালিকা (u: পুরো লিংক, h: শুধু IP হোস্ট)
object BadUrls {
    @Volatile private var urls: HashSet<String>? = null
    @Volatile private var hosts: HashSet<String>? = null

    private fun file(ctx: Context) = File(ctx.filesDir, "bad_urls.txt")

    fun reset() { urls = null; hosts = null }

    private fun load(ctx: Context) {
        if (urls != null && hosts != null) return
        val u = HashSet<String>()
        val h = HashSet<String>()
        try {
            file(ctx).forEachLine {
                if (it.startsWith("u:")) u.add(it.substring(2)) else if (it.startsWith("h:")) h.add(it.substring(2))
            }
        } catch (e: Exception) { }
        urls = u
        hosts = h
    }

    fun count(ctx: Context): Int { load(ctx); return urls?.size ?: 0 }

    fun hit(ctx: Context, url: String, host: String): Boolean {
        load(ctx)
        val n = url.lowercase().removePrefix("https://").removePrefix("http://").trimEnd('/')
        return (urls?.contains(n) == true) || (host.isNotEmpty() && hosts?.contains(host) == true)
    }
}

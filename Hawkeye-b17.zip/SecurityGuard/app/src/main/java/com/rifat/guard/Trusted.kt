package com.rifat.guard

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File

// ব্যবহারকারীর "বিশ্বস্ত" তালিকা: এগুলো আর ঝুঁকি হিসেবে গোনা হয় না
object Trusted {
    class T(val key: String, val name: String, val kind: String, val at: Long)

    @Volatile private var items: List<T>? = null
    @Volatile private var keys: Set<String>? = null

    private fun file(ctx: Context) = File(ctx.filesDir, "trusted.txt")

    fun keyOf(f: Finding): String = when (f.kind) {
        "app" -> "app:" + f.path
        "file" -> if (f.sha.isNotEmpty()) "sha:" + f.sha else "file:" + f.path
        else -> "dev:" + f.title
    }

    private fun load(ctx: Context) {
        if (items != null) return
        val l = ArrayList<T>()
        try {
            file(ctx).forEachLine { line ->
                val p = line.split("|")
                if (p.size >= 4) l.add(T(p[0], p[1], p[2], p[3].toLongOrNull() ?: 0L))
            }
        } catch (e: Exception) { }
        items = l
        keys = l.map { it.key }.toHashSet()
    }

    private fun save(ctx: Context, l: List<T>) {
        file(ctx).writeText(l.joinToString("\n") { listOf(it.key, it.name, it.kind, it.at).joinToString("|") })
        items = l
        keys = l.map { it.key }.toHashSet()
    }

    fun list(ctx: Context): List<T> { load(ctx); return items ?: emptyList() }

    fun isTrusted(ctx: Context, f: Finding): Boolean { load(ctx); return keys?.contains(keyOf(f)) == true }

    fun isApp(ctx: Context, pkg: String): Boolean { load(ctx); return keys?.contains("app:$pkg") == true }

    fun add(ctx: Context, f: Finding) {
        load(ctx)
        val k = keyOf(f)
        if (keys?.contains(k) == true) return
        val kind = when (f.kind) { "app" -> "app"; "file" -> "file"; else -> "phone setting" }
        save(ctx, list(ctx) + T(k, f.title.replace("|", "_"), kind, System.currentTimeMillis()))
    }

    fun remove(ctx: Context, key: String) { save(ctx, list(ctx).filter { it.key != key }) }
}

@Composable
fun TrustedCard() {
    val ctx = LocalContext.current
    var items by remember { mutableStateOf(Trusted.list(ctx)) }
    GCard {
        H(L.t("Trusted items", "বিশ্বস্ত তালিকা"))
        Hint(L.t("Items you marked as safe. Scans and shields no longer count them as risks. Remove one to check it again.",
            "আপনার নিরাপদ বলে চিহ্নিত জিনিস। স্ক্যান ও শিল্ড এগুলোকে আর ঝুঁকি গোনে না। আবার যাচাই করাতে তালিকা থেকে সরান।"))
        if (items.isEmpty()) Hint(L.t("Nothing here yet.", "এখনও কিছু নেই।"))
        items.forEach { t ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t.name, style = MaterialTheme.typography.titleSmall)
                    Hint(t.kind + " • " + fmtDate(t.at))
                }
                BigButton(L.t("Remove", "সরান"), Icons.Filled.Delete, modifier = Modifier.width(130.dp), outlined = true) {
                    Trusted.remove(ctx, t.key); items = Trusted.list(ctx)
                }
            }
        }
    }
}

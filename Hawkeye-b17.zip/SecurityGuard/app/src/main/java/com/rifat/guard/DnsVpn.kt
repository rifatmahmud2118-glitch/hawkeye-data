package com.rifat.guard

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.io.DataInputStream
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

object VpnState {
    var running by mutableStateOf(false)
    var total by mutableStateOf(0)
    var blocked by mutableStateOf(0)
    var ads by mutableStateOf(0)
    var cached by mutableStateOf(0)
    var encrypted by mutableStateOf(0)
    var fallback by mutableStateOf(0)
    var last by mutableStateOf("")
}

// ক্ষতিকর ডোমেইনের তালিকা
object BlockList {
    @Volatile private var set: HashSet<String>? = null
    private fun file(ctx: Context) = File(ctx.filesDir, "blocklist.txt")

    fun load(ctx: Context): Set<String> {
        set?.let { return it }
        val s = HashSet<String>()
        try { file(ctx).forEachLine { val d = it.trim().lowercase(); if (d.isNotEmpty() && !d.startsWith("#")) s.add(d) } } catch (e: Exception) { }
        set = s
        return s
    }

    fun count(ctx: Context): Int = load(ctx).size

    fun isBlocked(ctx: Context, name: String): Boolean {
        val s = load(ctx)
        var d = name.lowercase().trimEnd('.')
        while (true) {
            if (s.contains(d)) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    private val neverBlock = setOf(
        "google.com", "github.io", "github.com", "githubusercontent.com", "pages.dev", "web.app", "firebaseapp.com",
        "weebly.com", "blogspot.com", "wixsite.com", "herokuapp.com", "netlify.app", "vercel.app", "workers.dev",
        "amazonaws.com", "cloudfront.net", "facebook.com", "t.me", "wa.me", "bit.ly", "drive.google.com", "dropbox.com"
    )

    // OpenPhish: চালু ফিশিং সাইটের তালিকা (ফ্রি)। ব্যর্থ হলে বাকি কাজ থামে না
    private fun addPhish(out: MutableSet<String>) {
        try {
            val (code, text) = Net.request("https://openphish.com/feed.txt")
            if (code != 200) return
            var n = 0
            for (line in text.lineSequence()) {
                if (n++ > 30000) break
                val u = line.trim()
                if (!u.startsWith("http", true)) continue
                val h = try { java.net.URI(u).host?.lowercase() } catch (e: Exception) { null }
                if (h.isNullOrBlank() || h in neverBlock) continue
                if (Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(h)) continue
                out.add(h)
            }
        } catch (e: Exception) { }
    }

    // ক্ষতিকর সাইটের তালিকা: URLhaus-এর তথ্য থেকে বানানো ফ্রি পাবলিক ডোমেইন তালিকা (key লাগে না)।
    // abuse.ch-এর নিজের hostfile বন্ধ হয়ে গেছে (কোড 410), তাই এটা ব্যবহার হচ্ছে
    private val sources = listOf(
        "https://cdn.jsdelivr.net/gh/curbengh/urlhaus-filter/urlhaus-filter-domains-online.txt",
        "https://gitlab.com/curben/urlhaus-filter/raw/master/urlhaus-filter-domains-online.txt"
    )

    private fun addDomains(out: MutableSet<String>): Int {
        for (src in sources) {
            try {
                val (code, text) = Net.request(src)
                if (code != 200) continue
                var added = 0
                for (line in text.lineSequence()) {
                    val d = line.trim().lowercase()
                    if (d.isEmpty() || d.startsWith("#") || d.contains(" ") || d.contains("/") || !d.contains(".")) continue
                    if (d in neverBlock) continue
                    if (Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(d)) continue
                    out.add(d)
                    added++
                }
                if (added > 0) return added
            } catch (e: Exception) { }
        }
        return 0
    }

    // ---- বিজ্ঞাপন ও ট্র্যাকারের তালিকা (StevenBlack hosts, ফ্রি) ----
    private fun adFile(ctx: Context) = File(ctx.filesDir, "adlist.txt")
    @Volatile private var ads: HashSet<String>? = null

    fun loadAds(ctx: Context): Set<String> {
        ads?.let { return it }
        val s = HashSet<String>()
        try { adFile(ctx).forEachLine { val d = it.trim(); if (d.isNotEmpty()) s.add(d) } } catch (e: Exception) { }
        ads = s
        return s
    }

    fun adCount(ctx: Context): Int = loadAds(ctx).size

    fun updateAds(ctx: Context): Int {
        return try {
            val (code, text) = Net.request("https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts")
            if (code != 200) return 0
            val out = LinkedHashSet<String>()
            for (line in text.lineSequence()) {
                val l = line.trim()
                if (l.isEmpty() || l.startsWith("#")) continue
                val parts = l.split(Regex("\\s+"))
                if (parts.size < 2 || (parts[0] != "0.0.0.0" && parts[0] != "127.0.0.1")) continue
                val d = parts[1].lowercase()
                if (!d.contains(".") || d == "localhost" || d in neverBlock) continue
                out.add(d)
            }
            if (out.isEmpty()) return 0
            adFile(ctx).writeText(out.joinToString("\n"))
            ads = null
            Store.put(ctx, "adlist_updated", System.currentTimeMillis().toString())
            out.size
        } catch (e: Exception) { 0 }
    }

    private fun hit(s: Set<String>, name: String): Boolean {
        var d = name.lowercase().trimEnd('.')
        while (true) {
            if (s.contains(d)) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    // 0 = যেতে দাও, 1 = ক্ষতিকর/ফিশিং, 2 = বিজ্ঞাপন/ট্র্যাকার
    fun verdict(ctx: Context, name: String): Int {
        if (Store.on(ctx, "vpn_sec", true) && isBlocked(ctx, name)) return 1
        if (Store.on(ctx, "vpn_ads", true) && hit(loadAds(ctx), name)) return 2
        return 0
    }

    fun update(ctx: Context): String {
        val a = updateSecurity(ctx)
        val n = updateAds(ctx)
        return a + if (n > 0) L.t(" • $n ad and tracker sites", " • ${n}টি বিজ্ঞাপন ও ট্র্যাকার সাইট") else L.t(" • ad list not updated", " • বিজ্ঞাপনের তালিকা আপডেট হয়নি")
    }

    fun updateSecurity(ctx: Context): String = try {
        val out = LinkedHashSet<String>()
        addDomains(out)
        addPhish(out)
        if (out.isEmpty()) L.t("Could not download any list (check internet)", "কোনো তালিকা নামানো গেল না (ইন্টারনেট দেখুন)")
        else {
            file(ctx).writeText(out.joinToString("\n"))
            set = null
            Store.put(ctx, "blocklist_updated", System.currentTimeMillis().toString())
            L.t("Updated: ${out.size} bad sites", "আপডেট হয়েছে: ${out.size}টি ক্ষতিকর সাইট")
        }
    } catch (e: Exception) { L.t("Update failed (check internet)", "আপডেট ব্যর্থ (ইন্টারনেট দেখুন)") }
}

// ফোনের ভেতরে চলা VPN: শুধু DNS প্রশ্ন ধরে, ক্ষতিকর সাইটের নাম আটকে দেয়, বাকি ট্রাফিক সরাসরি যায়
private class Prov(val key: String, val host: String, val ips: List<String>, val plain: String)

private val provs = listOf(
    Prov("adguard", "dns.adguard-dns.com", listOf("94.140.14.14", "94.140.15.15"), "94.140.14.14"),
    Prov("cf", "security.cloudflare-dns.com", listOf("1.1.1.2", "1.0.0.2"), "1.1.1.2"),
    Prov("quad9", "dns.quad9.net", listOf("9.9.9.9", "149.112.112.112"), "9.9.9.9")
)

class DnsVpnService : VpnService() {
    companion object {
        private const val CLIENT = "10.77.0.1"
        private const val FAKE_DNS = "10.77.0.2"
        private val FAKE_DNS_BYTES = byteArrayOf(10, 77, 0, 2)

        fun start(ctx: Context) {
            Store.setOn(ctx, "vpn_on", true)
            try { ctx.startService(Intent(ctx, DnsVpnService::class.java)) } catch (e: Exception) { }
        }

        fun stop(ctx: Context) {
            Store.setOn(ctx, "vpn_on", false)
            try { ctx.startService(Intent(ctx, DnsVpnService::class.java).setAction("STOP")) } catch (e: Exception) { }
        }
    }

    @Volatile private var running = false
    private val dotPool = ConcurrentLinkedQueue<SSLSocket>()
    private val cache = ConcurrentHashMap<String, Pair<Long, ByteArray>>()
    private var tun: ParcelFileDescriptor? = null
    private var pool: ExecutorService? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopVpn(); stopSelf(); return START_NOT_STICKY }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (running) return
        val fd = try {
            Builder().setSession("Hawkeye DNS Shield").addAddress(CLIENT, 32).addDnsServer(FAKE_DNS).addRoute(FAKE_DNS, 32).setMtu(1500).setBlocking(true).establish()
        } catch (e: Exception) { null } ?: return
        tun = fd
        running = true
        VpnState.running = true
        VpnState.total = 0
        VpnState.blocked = 0
        VpnState.ads = 0
        VpnState.cached = 0
        VpnState.encrypted = 0
        VpnState.fallback = 0
        val upstream = provider().plain
        if (BlockList.count(this) == 0 || BlockList.adCount(this) == 0) {
            val app = applicationContext
            Thread { try { BlockList.update(app) } catch (e: Exception) { } }.start()
        }
        val p = Executors.newFixedThreadPool(8)
        pool = p
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        Thread {
            val buf = ByteArray(32767)
            while (running) {
                val n = try { input.read(buf) } catch (e: Exception) { -1 }
                if (n < 0) break
                if (n == 0) continue
                val pkt = buf.copyOf(n)
                try { p.execute { handle(pkt, output, upstream) } } catch (e: Exception) { break }
            }
            if (running) { running = false; VpnState.running = false }
        }.start()
    }

    private fun stopVpn() {
        running = false
        VpnState.running = false
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        pool?.shutdownNow()
        pool = null
        dotPool.forEach { try { it.close() } catch (e: Exception) { } }
        dotPool.clear()
        cache.clear()
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun handle(pkt: ByteArray, out: FileOutputStream, upstream: String) {
        try {
            if (pkt.size < 28) return
            if (((pkt[0].toInt() shr 4) and 0xF) != 4) return
            val ihl = (pkt[0].toInt() and 0xF) * 4
            if (pkt[9].toInt() != 17 || pkt.size < ihl + 8) return
            if (!pkt.copyOfRange(16, 20).contentEquals(FAKE_DNS_BYTES)) return
            val srcPort = u16(pkt, ihl)
            if (u16(pkt, ihl + 2) != 53) return
            val udpLen = u16(pkt, ihl + 4).coerceAtMost(pkt.size - ihl)
            if (udpLen < 8 + 12) return
            val q = pkt.copyOfRange(ihl + 8, ihl + udpLen)
            val (name, qEnd) = parseName(q) ?: return
            VpnState.total++
            val v = BlockList.verdict(this, name)
            val resp: ByteArray? = if (v != 0) {
                if (v == 1) VpnState.blocked++ else VpnState.ads++
                VpnState.last = name
                nxdomain(q, qEnd)
            } else resolve(q, name, u16(q, qEnd - 4), upstream)
            if (resp != null) writeUdp(out, pkt.copyOfRange(12, 16), srcPort, resp)
        } catch (e: Exception) { }
    }

    // DNS প্রশ্ন থেকে ডোমেইন নাম আর প্রশ্নের শেষ জায়গা বের করা
    private fun parseName(q: ByteArray): Pair<String, Int>? {
        var i = 12
        val sb = StringBuilder()
        while (i < q.size) {
            val len = q[i].toInt() and 0xFF
            if (len == 0) { i++; break }
            if (len >= 0xC0 || i + 1 + len > q.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(q, i + 1, len, Charsets.ISO_8859_1))
            i += 1 + len
        }
        val end = i + 4
        if (end > q.size) return null
        return sb.toString() to end
    }

    // "এই নাম নেই" উত্তর (NXDOMAIN)
    private fun nxdomain(q: ByteArray, qEnd: Int): ByteArray {
        val r = q.copyOf(qEnd)
        r[2] = 0x81.toByte(); r[3] = 0x83.toByte()
        r[6] = 0; r[7] = 0; r[8] = 0; r[9] = 0; r[10] = 0; r[11] = 0
        return r
    }

    private fun provider(): Prov = provs.firstOrNull { it.key == Store.get(this, "vpn_prov", "adguard") } ?: provs[0]

    // সংযুক্ত এনক্রিপ্টেড (DNS-over-TLS) লাইন: ISP শুধু দেখে একটা TLS সংযোগ, ভেতরের সাইটের নাম দেখে না
    private fun openDot(pv: Prov): SSLSocket? {
        for (ip in pv.ips) {
            var raw: Socket? = null
            try {
                raw = Socket()
                protect(raw)
                raw.connect(InetSocketAddress(ip, 853), 4000)
                raw.soTimeout = 5000
                val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(raw, pv.host, 853, true) as SSLSocket
                ssl.startHandshake()
                if (!HttpsURLConnection.getDefaultHostnameVerifier().verify(pv.host, ssl.session)) { ssl.close(); continue }
                return ssl
            } catch (e: Exception) { try { raw?.close() } catch (x: Exception) { } }
        }
        return null
    }

    private fun dotQuery(q: ByteArray): ByteArray? {
        val pv = provider()
        for (attempt in 0..1) {
            val s = (if (attempt == 0) dotPool.poll() else null) ?: openDot(pv) ?: return null
            try {
                val msg = ByteArray(2 + q.size)
                msg[0] = (q.size shr 8).toByte(); msg[1] = q.size.toByte()
                System.arraycopy(q, 0, msg, 2, q.size)
                s.outputStream.write(msg)
                s.outputStream.flush()
                val inp = DataInputStream(s.inputStream)
                val len = inp.readUnsignedShort()
                val resp = ByteArray(len)
                inp.readFully(resp)
                if (dotPool.size < 4) dotPool.add(s) else s.close()
                return resp
            } catch (e: Exception) { try { s.close() } catch (x: Exception) { } }
        }
        return null
    }

    private fun servfail(q: ByteArray): ByteArray {
        val r = q.copyOf(minOf(q.size, 512))
        r[2] = 0x81.toByte(); r[3] = 0x82.toByte()
        return r
    }

    // ক্যাশ, তারপর এনক্রিপ্টেড DNS, তারপর (অনুমতি থাকলে) সাধারণ DNS
    private fun resolve(q: ByteArray, name: String, qType: Int, plain: String): ByteArray? {
        val key = name.lowercase() + "|" + qType
        val now = System.currentTimeMillis()
        val hit = cache[key]
        if (hit != null) {
            if (hit.first > now) {
                VpnState.cached++
                val c = hit.second.copyOf(); c[0] = q[0]; c[1] = q[1]
                return c
            }
            cache.remove(key)
        }
        var r: ByteArray? = null
        if (Store.on(this, "vpn_dot", true)) {
            r = dotQuery(q)
            if (r != null) VpnState.encrypted++
        }
        if (r == null) {
            if (Store.on(this, "vpn_dot", true) && Store.on(this, "vpn_strict", false)) return servfail(q)
            r = forward(q, plain)
            if (r != null) VpnState.fallback++
        }
        if (r != null && r.size > 12 && (r[3].toInt() and 0x0F) == 0 && (((r[6].toInt() and 0xFF) shl 8) or (r[7].toInt() and 0xFF)) > 0) {
            if (cache.size > 2000) cache.clear()
            cache[key] = (now + 120000L) to r
        }
        return r
    }

    private fun forward(q: ByteArray, upstream: String): ByteArray? {
        val s = DatagramSocket()
        return try {
            protect(s)
            s.soTimeout = 4000
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(upstream), 53))
            val rb = ByteArray(4096)
            val rp = DatagramPacket(rb, rb.size)
            s.receive(rp)
            rb.copyOf(rp.length)
        } catch (e: Exception) { null } finally { s.close() }
    }

    private fun writeUdp(out: FileOutputStream, dstIp: ByteArray, dstPort: Int, data: ByteArray) {
        val udpLen = 8 + data.size
        val total = 20 + udpLen
        val p = ByteArray(total)
        p[0] = 0x45
        p[2] = (total shr 8).toByte(); p[3] = total.toByte()
        p[6] = 0x40
        p[8] = 64; p[9] = 17
        System.arraycopy(FAKE_DNS_BYTES, 0, p, 12, 4)
        System.arraycopy(dstIp, 0, p, 16, 4)
        var sum = 0
        for (i in 0 until 20 step 2) sum += ((p[i].toInt() and 0xFF) shl 8) or (p[i + 1].toInt() and 0xFF)
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val ck = sum.inv() and 0xFFFF
        p[10] = (ck shr 8).toByte(); p[11] = ck.toByte()
        p[20] = 0; p[21] = 53
        p[22] = (dstPort shr 8).toByte(); p[23] = dstPort.toByte()
        p[24] = (udpLen shr 8).toByte(); p[25] = udpLen.toByte()
        System.arraycopy(data, 0, p, 28, data.size)
        synchronized(out) { out.write(p) }
    }
}

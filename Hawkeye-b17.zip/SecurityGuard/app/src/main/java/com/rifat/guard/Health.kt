package com.rifat.guard

import android.app.KeyguardManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import java.io.File
import java.security.MessageDigest
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Check(val title: String, val ok: Boolean, val detail: String, val penalty: Int)

object DeviceHealth {
    fun run(ctx: Context): List<Check> {
        val l = mutableListOf<Check>()
        val days = try { ChronoUnit.DAYS.between(LocalDate.parse(Build.VERSION.SECURITY_PATCH), LocalDate.now()) } catch (e: Exception) { -1L }
        l += Check(L.t("Security update", "সিকিউরিটি আপডেট"), days in 0..120,
            if (days < 0) L.t("Unknown", "জানা যায়নি") else L.t("Last patch $days days ago", "সর্বশেষ আপডেট $days দিন আগের") + if (days > 120) L.t(", please update the phone", ", সেটিংস থেকে আপডেট দিন") else "", 20)
        l += Check(L.t("Android version", "Android সংস্করণ"), Build.VERSION.SDK_INT >= 31,
            "Android ${Build.VERSION.RELEASE}" + if (Build.VERSION.SDK_INT < 31) L.t(" (old, misses new protections)", " (পুরনো, নতুন সুরক্ষা পায় না)") else "", 10)
        val kg = ctx.getSystemService(KeyguardManager::class.java)
        l += Check(L.t("Screen lock", "স্ক্রিন লক"), kg.isDeviceSecure,
            if (kg.isDeviceSecure) L.t("PIN/pattern is set", "পিন/প্যাটার্ন দেওয়া আছে") else L.t("No screen lock! Set one now", "স্ক্রিন লক নেই! এখনই দিন"), 25)
        val dev = Settings.Global.getInt(ctx.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        l += Check(L.t("Developer mode", "ডেভেলপার মোড"), !dev, if (dev) L.t("On. Turn off if not needed", "চালু আছে, দরকার না হলে বন্ধ করুন") else L.t("Off", "বন্ধ"), 5)
        val adb = Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        l += Check(L.t("USB debugging", "USB ডিবাগিং"), !adb, if (adb) L.t("On. A door into the phone from a computer", "চালু আছে, কম্পিউটার থেকে ফোনে ঢোকার পথ খোলা") else L.t("Off", "বন্ধ"), 10)
        val rooted = Build.TAGS?.contains("test-keys") == true ||
            listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk").any { File(it).exists() }
        l += Check(L.t("Root", "রুট"), !rooted, if (rooted) L.t("Phone looks rooted, protection is weaker", "ফোন রুট করা মনে হচ্ছে, সুরক্ষা দুর্বল") else L.t("Not rooted", "রুট নেই"), 25)
        return l
    }
}

data class ScannedFile(val name: String, val sha: String, val sizeKb: Long)

object FileScanner {
    fun fromUri(ctx: Context, uri: Uri): ScannedFile {
        var name = "file"
        var size = 0L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0) size = c.getLong(si) / 1024
            }
        }
        val sha = try {
            val md = MessageDigest.getInstance("SHA-256")
            ctx.contentResolver.openInputStream(uri)?.use { st ->
                val b = ByteArray(65536)
                while (true) { val n = st.read(b); if (n < 0) break; md.update(b, 0, n) }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) { "" }
        return ScannedFile(name, sha, size)
    }
}

package com.rifat.guard

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

fun scoreRisk(s: Int): Risk = when { s >= 80 -> Risk.LOW; s >= 50 -> Risk.MEDIUM; else -> Risk.HIGH }

@Composable
fun ScanControls(full: Boolean, onReport: () -> Unit) {
    val ctx = LocalContext.current
    val r = ScanState.result
    if (ScanState.running) {
        H(if (ScanState.type == "full") L.t("Full System Scan running", "ফুল সিস্টেম স্ক্যান চলছে") else L.t("Quick Scan running", "কুইক স্ক্যান চলছে"))
        LinearProgressIndicator(progress = { ScanState.progress }, modifier = Modifier.fillMaxWidth())
        Text(ScanState.stage + "  " + (ScanState.progress * 100).toInt() + "%")
        if (ScanState.detail.isNotEmpty()) Hint(ScanState.detail)
        Hint(L.t("You can switch pages or leave the app. Progress also shows in the notification bar, with a sound when done.",
            "অন্য পেইজে গেলে বা অ্যাপ থেকে বের হলেও চলবে। নোটিফিকেশন বারেও প্রোগ্রেস দেখাবে, শেষ হলে সাউন্ড হবে।"))
        BigButton(L.t("Stop", "থামান"), Icons.Filled.Close, outlined = true) { ScanState.cancel = true }
    } else {
        BigButton(L.t("Complete Scan", "Complete Scan"), Icons.Filled.Shield) { ScanState.start(ctx, "full") }
        if (!full) BigButton(L.t("Quick Scan", "কুইক স্ক্যান"), Icons.Filled.Speed, outlined = true) { ScanState.start(ctx, "quick") }
        if (ScanState.stage == L.t("Cancelled", "বাতিল হয়েছে")) Hint(ScanState.stage)
        if (r == null) {
            Hint(L.t("No scan yet. Tap Complete Scan to check everything.", "এখনও স্ক্যান হয়নি। সব কিছু যাচাই করতে Complete Scan চাপুন।"))
        } else {
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatBox(L.t("Score", "স্কোর"), "${r.score}", riskColor(scoreRisk(r.score)))
                StatBox(L.t("Threats", "ভাইরাস"), "${r.threats}", if (r.threats > 0) riskColor(Risk.HIGH) else riskColor(Risk.LOW))
                StatBox(L.t("Suspicious", "সন্দেহজনক"), "${r.suspicious}", if (r.suspicious > 0) riskColor(Risk.MEDIUM) else riskColor(Risk.LOW))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatBox(L.t("Apps", "অ্যাপ"), "${r.apps}")
                StatBox(L.t("Files", "ফাইল"), "${r.files}")
                StatBox(L.t("Time", "সময়"), "${r.seconds}s")
            }
            Hint(L.t("Last scan: ", "সর্বশেষ স্ক্যান: ") + fmtDate(r.at) + " • " + (if (r.type == "full") L.t("Full", "ফুল") else L.t("Quick", "কুইক")) +
                (if (r.skipped > 0) L.t(" • ${r.skipped} very large files skipped", " • ${r.skipped}টি অতি বড় ফাইল বাদ") else ""))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                BigButton(L.t("View report", "রিপোর্ট দেখুন"), Icons.Filled.Description, modifier = Modifier.weight(1f), outlined = true) { onReport() }
                IconButton({ ScanState.start(ctx, r.type) }) { Icon(Icons.Filled.Refresh, L.t("Rescan", "আবার স্ক্যান"), tint = MaterialTheme.colorScheme.primary) }
            }
        }
    }
}

@Composable
fun TRow(a: String, b: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(a, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(b, style = MaterialTheme.typography.bodyMedium)
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)))
}

@Composable
fun BatteryCard() {
    val ctx = LocalContext.current
    var b by remember { mutableStateOf<Batt?>(null) }
    LaunchedEffect(Unit) { while (true) { b = withContext(Dispatchers.IO) { BatteryReader.read(ctx) }; delay(2000) } }
    GCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(if (b?.charging == true) Icons.Filled.Bolt else Icons.Filled.BatteryChargingFull, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            H(L.t("Complete Battery Health", "Complete Battery Health"))
        }
        val x = b
        if (x == null) Hint(L.t("Reading…", "পড়া হচ্ছে…")) else {
            LinearProgressIndicator(progress = { (x.level.coerceAtLeast(0)) / 100f }, modifier = Modifier.fillMaxWidth())
            TRow(L.t("Battery level", "ব্যাটারি লেভেল"), "${x.level}%")
            TRow(L.t("Charging indicator", "চার্জিং ইন্ডিকেটর"), x.status + " • " + x.source)
            TRow(L.t("Battery health", "ব্যাটারি হেলথ"), x.health)
            val dir = if (x.charging) L.t("charging", "চার্জ হচ্ছে") else L.t("discharging", "কমছে")
            val wear = if (x.healthPct >= 0) 100 - x.healthPct else -1
            TRow(L.t("Health estimate", "হেলথ আনুমানিক"), if (x.healthPct >= 0) "${x.healthPct}% • " + L.t("wear $wear%", "ক্ষয় $wear%") else L.t("Phone does not report it", "ফোন এটা জানায় না"))
            val cur = when {
                x.currentMa > 0 -> (if (x.currentEstimated) "≈ " else "") + "${x.currentMa} mA (${String.format("%.2f", x.currentMa / 1000f)} A) $dir"
                x.measuring -> L.t("Measuring… wait about 15 seconds", "মাপা হচ্ছে… প্রায় ১৫ সেকেন্ড অপেক্ষা করুন")
                else -> L.t("Not available", "পাওয়া যায়নি")
            }
            TRow(L.t("Current (ampere)", "কারেন্ট (অ্যাম্পিয়ার)"), cur)
            if (x.avgMa > 0) TRow(L.t("Average current", "গড় কারেন্ট"), "${x.avgMa} mA")
            TRow(L.t("Power", "পাওয়ার"), String.format("%.2f W", x.powerW))
            if (x.charging) {
                val speed = when { x.powerW < 5f -> L.t("Slow", "ধীর"); x.powerW < 10f -> L.t("Normal", "সাধারণ"); x.powerW < 18f -> L.t("Fast", "দ্রুত"); else -> L.t("Super fast", "অতি দ্রুত") }
                if (x.powerW > 0.1f) TRow(L.t("Charging speed", "চার্জিং গতি"), speed)
                if (x.timeToFullMin >= 0) TRow(L.t("Time to full", "পূর্ণ হতে সময়"), L.t("${x.timeToFullMin / 60}h ${x.timeToFullMin % 60}m", "${x.timeToFullMin / 60} ঘণ্টা ${x.timeToFullMin % 60} মিনিট"))
            } else if (x.runtimeMin >= 0) {
                TRow(L.t("Estimated time left", "আনুমানিক চলবে"), L.t("${x.runtimeMin / 60}h ${x.runtimeMin % 60}m", "${x.runtimeMin / 60} ঘণ্টা ${x.runtimeMin % 60} মিনিট"))
            }
            TRow(L.t("Voltage", "ভোল্টেজ"), String.format("%.3f V (%d mV)", x.voltageMv / 1000f, x.voltageMv))
            val tl = when { x.tempC < 35f -> L.t("Cool", "ঠান্ডা"); x.tempC < 40f -> L.t("Normal", "স্বাভাবিক"); x.tempC < 45f -> L.t("Warm", "গরম"); else -> L.t("Hot", "অনেক গরম") }
            TRow(L.t("Temperature", "তাপমাত্রা"), String.format("%.1f °C (%.1f °F) • %s", x.tempC, x.tempC * 9f / 5f + 32f, tl))
            TRow(L.t("Lowest / highest seen", "সর্বনিম্ন / সর্বোচ্চ দেখা"), String.format("%.1f / %.1f °C", x.minTempC, x.maxTempC))
            TRow(L.t("Technology", "প্রযুক্তি"), x.tech)
            TRow(L.t("Charge now", "এখন চার্জ"), if (x.nowMah > 0) "${x.nowMah} mAh" else L.t("Not reported", "ফোন জানায় না"))
            if (x.energyMwh > 0) TRow(L.t("Energy stored", "জমানো শক্তি"), String.format("%.2f Wh", x.energyMwh / 1000f))
            TRow(L.t("Estimated full capacity", "আনুমানিক পূর্ণ ক্যাপাসিটি"), if (x.fullMah > 0) "${x.fullMah} mAh" else L.t("Not reported", "ফোন জানায় না"))
            TRow(L.t("Design capacity", "ডিজাইন ক্যাপাসিটি"), if (x.designMah > 0) "${x.designMah} mAh" else L.t("Not available", "পাওয়া যায়নি"))
            TRow(L.t("Charge cycles", "চার্জ সাইকেল"), if (x.cycles > 0) "${x.cycles}" else if (x.cycles == 0) L.t("0 (may not be reported by this phone)", "০ (ফোন হয়তো জানায় না)") else L.t("Not available", "পাওয়া যায়নি"))
            if (!x.present) TRow(L.t("Battery", "ব্যাটারি"), L.t("Not detected", "পাওয়া যায়নি"))
        }
    }
}

@Composable
fun HomeScreen(onOpen: (Screen) -> Unit) {
    Page {
        GCard { ScanControls(false) { onOpen(Screen.REPORT) } }
        BatteryCard()
    }
}

@Composable
fun FullScanScreen(onOpen: (Screen) -> Unit) {
    Page {
        GCard {
            H(L.t("Full System Scan", "ফুল সিস্টেম স্ক্যান"))
            Hint(L.t("Every installed app, every file on the phone storage (documents, downloads, media, archives, installers). Files are checked against the malware list, for disguised apps (like an app named photo.jpg) and for double-extension tricks. Big areas are scanned in parallel, so it is quick.",
                "ইনস্টল করা সব অ্যাপ এবং ফোনের স্টোরেজের সব ফাইল (ডকুমেন্ট, ডাউনলোড, মিডিয়া, আর্কাইভ, ইনস্টলার)। ভাইরাস তালিকার সাথে মেলানো হয়, ছবি/ভিডিওর নামে লুকানো অ্যাপ এবং ডাবল এক্সটেনশন কৌশলও ধরা হয়। একসাথে কয়েক জায়গা স্ক্যান হয়, তাই দ্রুত।"))
            ScanControls(true) { onOpen(Screen.REPORT) }
        }
        GCard {
            H(L.t("Scan options", "স্ক্যানের অপশন"))
            StoreToggle(Icons.Filled.Apps, L.t("Include system apps", "সিস্টেম অ্যাপও দেখুন"), L.t("Checks updated system apps too", "আপডেট হওয়া সিস্টেম অ্যাপও যাচাই হবে"), "scan_sys")
            StoreToggle(Icons.Filled.Image, L.t("Media and document disguise check", "মিডিয়া ও ডকুমেন্টের ছদ্মবেশ যাচাই"), L.t("Finds apps hiding as photos, videos or PDFs", "ছবি, ভিডিও বা PDF সেজে থাকা অ্যাপ ধরে"), "scan_media")
            StoreToggle(Icons.Filled.Search, L.t("Online check (VirusTotal)", "অনলাইন যাচাই (VirusTotal)"), L.t("Checks the riskiest items with 70+ engines (needs key, slower)", "সবচেয়ে ঝুঁকিপূর্ণগুলো ৭০+ ইঞ্জিনে যাচাই (key লাগে, ধীর)"), "scan_online")
        }
        Hint(L.t("Why not every media file by hash? Photos and videos cannot infect a phone by themselves; the disguise check covers the real risk and keeps the scan fast.",
            "মিডিয়া ফাইলের হ্যাশ কেন না? ছবি বা ভিডিও নিজে ফোনে ভাইরাস ঢোকাতে পারে না। ছদ্মবেশ যাচাইই আসল ঝুঁকি ধরে, তাই স্ক্যান দ্রুত থাকে।"))
    }
}

@Composable
fun ReportScreen() {
    val ctx = LocalContext.current
    val r = ScanState.result
    var confirm by remember { mutableStateOf<Finding?>(null) }
    var trustAsk by remember { mutableStateOf<Finding?>(null) }
    if (r == null) { Page { GCard { Hint(L.t("No report yet. Run a scan from Home.", "রিপোর্ট নেই। হোম থেকে স্ক্যান চালান।")) } }; return }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            GCard {
                H(L.t("Scan overview", "স্ক্যানের ওভারভিউ"))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    StatBox(L.t("Score", "স্কোর"), "${r.score}", riskColor(scoreRisk(r.score)))
                    StatBox(L.t("Threats", "ভাইরাস"), "${r.threats}", riskColor(if (r.threats > 0) Risk.HIGH else Risk.LOW))
                    StatBox(L.t("Suspicious", "সন্দেহজনক"), "${r.suspicious}", riskColor(if (r.suspicious > 0) Risk.MEDIUM else Risk.LOW))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    StatBox(L.t("Apps", "অ্যাপ"), "${r.apps}"); StatBox(L.t("Files", "ফাইল"), "${r.files}"); StatBox(L.t("Time", "সময়"), "${r.seconds}s")
                }
                Hint(fmtDate(r.at) + " • " + if (r.type == "full") L.t("Full System Scan", "ফুল সিস্টেম স্ক্যান") else L.t("Quick Scan", "কুইক স্ক্যান"))
            }
        }
        if (r.findings.isEmpty()) item { GCard { Text(L.t("Nothing suspicious was found.", "সন্দেহজনক কিছু পাওয়া যায়নি।")) } }
        items(r.findings) { f ->
            GCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(when (f.kind) { "app" -> Icons.Filled.Android; "file" -> Icons.Filled.Description; else -> Icons.Filled.Settings }, null, tint = riskColor(f.risk))
                    Spacer(Modifier.width(8.dp))
                    Text(f.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    Text(f.risk.label(), style = MaterialTheme.typography.labelMedium, color = riskColor(f.risk))
                }
                if (f.detail.isNotEmpty()) Text(f.detail, style = MaterialTheme.typography.bodyMedium)
                if (f.path.isNotEmpty() && f.kind == "file") Hint(f.path)
                VtLine(VtStore.map[f.sha])
                if (f.kind == "app") BigButton(L.t("Open app settings (uninstall)", "অ্যাপের সেটিংস (মুছতে)"), Icons.Filled.Settings, outlined = true) {
                    Perms.open(ctx, Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + f.path)))
                }
                if (f.kind == "file") BigButton(L.t("Delete file", "ফাইল মুছুন"), Icons.Filled.Delete, outlined = true) { confirm = f }
                BigButton(L.t("I know it is safe: skip next time", "আমি জানি নিরাপদ: পরের বার বাদ"), Icons.Filled.CheckCircle, outlined = true) {
                    if (f.risk == Risk.HIGH) trustAsk = f else { Trusted.add(ctx, f); ScanState.removeFinding(ctx, f) }
                }
            }
        }
        item { TrustedCard() }
    }
    trustAsk?.let { f ->
        AlertDialog(onDismissRequest = { trustAsk = null },
            title = { Text(L.t("Mark as safe?", "নিরাপদ বলে চিহ্নিত করবেন?")) },
            text = { Text(L.t("This was rated high risk. If you are sure it is safe, it will not be flagged again. You can undo this in the Trusted items list.",
                "এটা উচ্চ ঝুঁকির ছিল। আপনি নিশ্চিত হলে এটা আর কখনও ঝুঁকি দেখাবে না। বিশ্বস্ত তালিকা থেকে পরে ফিরিয়ে নিতে পারবেন।")) },
            confirmButton = { TextButton({ Trusted.add(ctx, f); ScanState.removeFinding(ctx, f); trustAsk = null }) { Text(L.t("Yes, it is safe", "হ্যাঁ, নিরাপদ")) } },
            dismissButton = { TextButton({ trustAsk = null }) { Text(L.t("Cancel", "বাতিল")) } })
    }
    confirm?.let { f ->
        AlertDialog(onDismissRequest = { confirm = null },
            title = { Text(L.t("Delete this file?", "ফাইলটি মুছবেন?")) },
            text = { Text(f.path) },
            confirmButton = { TextButton({ File(f.path).delete(); ScanState.removeFinding(ctx, f); confirm = null }) { Text(L.t("Delete", "মুছুন")) } },
            dismissButton = { TextButton({ confirm = null }) { Text(L.t("Cancel", "বাতিল")) } })
    }
}

package com.rifat.guard

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import java.io.File

// রিয়েল-টাইম সুরক্ষার চলতি হিসাব
object ShieldStats {
    var checked by mutableStateOf(0)
    var blocked by mutableStateOf(0)
    var last by mutableStateOf("")
}

class QItem(val id: String, val name: String, val original: String, val sha: String, val size: Long, val at: Long)

// কোয়ারেন্টিন: নিশ্চিত হুমকি ফাইল অ্যাপের ব্যক্তিগত জায়গায় .bin নামে সরিয়ে রাখা হয়, চালানো যায় না
object Quarantine {
    private fun dir(ctx: Context): File { val d = File(ctx.filesDir, "quarantine"); d.mkdirs(); return d }
    private fun meta(ctx: Context) = File(dir(ctx), "index.txt")

    fun list(ctx: Context): List<QItem> {
        val out = ArrayList<QItem>()
        try {
            meta(ctx).forEachLine { line ->
                val p = line.split("|")
                if (p.size >= 6 && File(dir(ctx), p[0] + ".bin").exists())
                    out.add(QItem(p[0], p[1], p[2], p[3], p[4].toLongOrNull() ?: 0L, p[5].toLongOrNull() ?: 0L))
            }
        } catch (e: Exception) { }
        return out.reversed()
    }

    private fun write(ctx: Context, items: List<QItem>) {
        meta(ctx).writeText(items.reversed().joinToString("\n") { listOf(it.id, it.name, it.original, it.sha, it.size, it.at).joinToString("|") })
    }

    fun move(ctx: Context, f: File, sha: String): Boolean {
        return try {
            val id = System.currentTimeMillis().toString() + "_" + (f.name.hashCode() and 0x7fffffff)
            val dst = File(dir(ctx), "$id.bin")
            f.copyTo(dst, overwrite = true)
            if (!f.delete()) { dst.delete(); return false }
            val item = QItem(id, f.name.replace("|", "_"), f.path.replace("|", "_"), sha, dst.length(), System.currentTimeMillis())
            write(ctx, list(ctx) + item)
            true
        } catch (e: Exception) { false }
    }

    fun restore(ctx: Context, q: QItem): Boolean {
        return try {
            val src = File(dir(ctx), q.id + ".bin")
            val to = File(q.original)
            to.parentFile?.mkdirs()
            src.copyTo(to, overwrite = true)
            src.delete()
            write(ctx, list(ctx).filter { it.id != q.id })
            true
        } catch (e: Exception) { false }
    }

    fun delete(ctx: Context, q: QItem) {
        try { File(dir(ctx), q.id + ".bin").delete(); write(ctx, list(ctx).filter { it.id != q.id }) } catch (e: Exception) { }
    }
}

// সুরক্ষা হঠাৎ বন্ধ হয়ে গেলে আবার চালু করার চেষ্টা বা জানানো (প্রতি ১৫ মিনিটে দেখে)
object Watchdog {
    fun check(ctx: Context) {
        val app = ctx.applicationContext
        if (!Store.on(app, "shield_on", false)) return
        if (ShieldService.alive) return
        try {
            app.startForegroundService(Intent(app, ShieldService::class.java))
        } catch (e: Exception) {
            val now = System.currentTimeMillis()
            if (now - Store.long(app, "wd_note", 0L) > 3600000L) {
                Store.put(app, "wd_note", now.toString())
                Alerts.notify(app, L.t("Protection stopped", "সুরক্ষা বন্ধ হয়ে গেছে"),
                    L.t("Android stopped the real-time protection. Tap to open the app and turn it on.", "Android রিয়েল-টাইম সুরক্ষা বন্ধ করে দিয়েছে। অ্যাপ খুলে আবার চালু করতে চাপুন।"))
            }
        }
    }
}

@Composable
fun QuarantineCard() {
    val ctx = LocalContext.current
    var items by remember { mutableStateOf(Quarantine.list(ctx)) }
    GCard {
        H(L.t("Quarantine", "কোয়ারেন্টিন"))
        if (items.isEmpty()) Hint(L.t("Nothing here. Blocked files are kept switched off inside this app.", "এখানে কিছু নেই। আটকানো ফাইল এই অ্যাপের ভেতরে নিষ্ক্রিয় অবস্থায় থাকে।"))
        items.forEach { q ->
            Text(q.name, style = MaterialTheme.typography.titleSmall)
            Hint(fmtBytes(q.size) + " • " + fmtDate(q.at))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton(L.t("Restore", "ফিরিয়ে দিন"), Icons.Filled.Refresh, modifier = Modifier.weight(1f), outlined = true) { Quarantine.restore(ctx, q); items = Quarantine.list(ctx) }
                BigButton(L.t("Delete", "মুছুন"), Icons.Filled.Delete, modifier = Modifier.weight(1f), outlined = true) { Quarantine.delete(ctx, q); items = Quarantine.list(ctx) }
            }
        }
        if (items.isNotEmpty()) BigButton(L.t("Refresh", "রিফ্রেশ"), Icons.Filled.Refresh, outlined = true) { items = Quarantine.list(ctx) }
    }
}

package com.rifat.guard

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

enum class Risk {
    HIGH, MEDIUM, LOW;
    fun label(): String = when (this) {
        HIGH -> L.t("High risk", "উচ্চ ঝুঁকি")
        MEDIUM -> L.t("Medium risk", "মাঝারি ঝুঁকি")
        LOW -> L.t("Low risk", "কম ঝুঁকি")
    }
}

data class AuditResult(
    val name: String, val pkg: String, val score: Int, val risk: Risk,
    val reasons: List<String>, val sha256: String, val system: Boolean = false, val knownBad: Boolean = false
)

object AppAuditor {
    private class Perm(val w: Int, val en: String, val bn: String)

    private val dangerous = mapOf(
        "android.permission.BIND_ACCESSIBILITY_SERVICE" to Perm(40, "Can see and control your screen (banking trojans abuse this)", "স্ক্রিনের সব কিছু দেখতে ও নিজে নিজে চাপ দিতে পারে (ব্যাংকিং ভাইরাস এটা ব্যবহার করে)"),
        "android.permission.BIND_DEVICE_ADMIN" to Perm(35, "Wants to be device admin, can resist removal", "ফোনের অ্যাডমিন হতে চায়, মুছে ফেলা কঠিন করে দিতে পারে"),
        "android.permission.READ_SMS" to Perm(30, "Can read your SMS (OTP theft risk)", "আপনার SMS পড়তে পারে (OTP চুরির ঝুঁকি)"),
        "android.permission.RECEIVE_SMS" to Perm(25, "Can intercept incoming SMS (OTP theft risk)", "আসা SMS ধরতে পারে (OTP চুরির ঝুঁকি)"),
        "android.permission.SEND_SMS" to Perm(25, "Can send SMS in your name and cost you money", "আপনার নামে SMS পাঠাতে পারে, বিল কাটতে পারে"),
        "android.permission.SYSTEM_ALERT_WINDOW" to Perm(25, "Can draw fake screens over other apps", "অন্য অ্যাপের উপর নকল স্ক্রিন বসাতে পারে"),
        "android.permission.REQUEST_INSTALL_PACKAGES" to Perm(20, "Can try to install more apps", "আরও অ্যাপ ইনস্টল করার চেষ্টা করতে পারে"),
        "android.permission.MANAGE_EXTERNAL_STORAGE" to Perm(20, "Can see all files on the phone", "ফোনের সব ফাইল দেখতে পারে"),
        "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE" to Perm(20, "Can read all your notifications", "আপনার সব নোটিফিকেশন পড়তে পারে"),
        "android.permission.READ_CALL_LOG" to Perm(15, "Can see your call history", "কল লিস্ট দেখতে পারে"),
        "android.permission.RECORD_AUDIO" to Perm(15, "Can use the microphone", "মাইক চালাতে পারে"),
        "android.permission.CAMERA" to Perm(10, "Can use the camera", "ক্যামেরা চালাতে পারে"),
        "android.permission.READ_CONTACTS" to Perm(10, "Can read your contacts", "কন্টাক্ট লিস্ট দেখতে পারে"),
        "android.permission.ACCESS_FINE_LOCATION" to Perm(10, "Knows your exact location", "সঠিক লোকেশন জানতে পারে"),
    )

    // বিশ্বস্ত অ্যাপ স্টোর (এগুলো থেকে ইনস্টল হলে "বাইরের উৎস" ধরা হয় না)
    private val trustedStores = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.huawei.appmarket", "com.xiaomi.mipicks",
        "com.heytap.market", "com.oppo.market", "com.vivo.appstore", "com.amazon.venezia"
    )

    // নকল অ্যাপ ধরা: নামে পরিচিত ব্র্যান্ড, কিন্তু প্যাকেজ আসলটার নয়
    private val brands = mapOf(
        "whatsapp" to listOf("com.whatsapp"),
        "facebook" to listOf("com.facebook."),
        "messenger" to listOf("com.facebook."),
        "telegram" to listOf("org.telegram.", "org.thunderdog.challegram"),
        "instagram" to listOf("com.instagram."),
        "tiktok" to listOf("com.zhiliaoapp.", "com.ss.android.ugc."),
        "youtube" to listOf("com.google.android.youtube", "com.google.android.apps.youtube."),
        "bkash" to listOf("com.bkash."),
        "nagad" to listOf("com.konasl.nagad"),
        "paypal" to listOf("com.paypal."),
        "chrome" to listOf("com.android.chrome", "com.chrome.")
    )

    // পরিচিত আসল অ্যাপ: স্টোর থেকে ইনস্টল থাকলে শুধু ক্ষমতার জন্য উচ্চ ঝুঁকি দেখানো হবে না
    private val knownGood = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "com.truecaller", "org.telegram.messenger",
        "com.facebook.katana", "com.facebook.orca", "com.facebook.lite", "com.facebook.mlite",
        "com.instagram.android", "com.imo.android.imoim", "com.bkash.customerapp", "com.konasl.nagad"
    )

    private fun fakeBrand(name: String, pkg: String): String? {
        val n = name.lowercase()
        val pk = pkg.lowercase()
        for ((b, ok) in brands) {
            if (Regex("(^|[^a-z])" + b + "([^a-z]|\$)").containsMatchIn(n) && ok.none { pk.startsWith(it.lowercase()) }) return b
        }
        return null
    }

    private fun debugSigned(p: PackageInfo): Boolean = try {
        val sigs = p.signingInfo?.apkContentsSigners ?: emptyArray<android.content.pm.Signature>()
        val cf = java.security.cert.CertificateFactory.getInstance("X.509")
        sigs.any {
            val c = cf.generateCertificate(java.io.ByteArrayInputStream(it.toByteArray())) as java.security.cert.X509Certificate
            c.subjectX500Principal.name.contains("Android Debug", true)
        }
    } catch (e: Exception) { false }

    private fun isSystem(p: PackageInfo): Boolean = ((p.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM) != 0

    suspend fun scan(ctx: Context, includeSystem: Boolean = false, onProgress: (Int, Int) -> Unit = { _, _ -> }): List<AuditResult> =
        withContext(Dispatchers.IO) {
            Live.budget.set(30)
            val pm = ctx.packageManager
            val all = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNING_CERTIFICATES).filter { it.packageName != ctx.packageName }
            val list = if (includeSystem) all else all.filter { !isSystem(it) }
            var done = 0
            val out = ArrayList<AuditResult>()
            for (chunk in list.chunked(8)) {
                out += chunk.map { async { audit(ctx, it) } }.awaitAll()
                done += chunk.size
                onProgress(done, list.size)
            }
            out.sortedByDescending { it.score }
        }

    fun auditOne(ctx: Context, pkg: String): AuditResult? = try {
        Live.budget.set(30)
        audit(ctx, ctx.packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNING_CERTIFICATES))
    } catch (e: Exception) { null }

    private fun audit(ctx: Context, p: PackageInfo): AuditResult {
        val pm = ctx.packageManager
        val ai = p.applicationInfo!!
        val name = pm.getApplicationLabel(ai).toString()
        val sys = isSystem(p)
        val updated = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        // ফোনের সিস্টেম পার্টিশনের মূল অ্যাপ নিরাপদ পার্টিশনে থাকে, তাই শুধু আপডেট হওয়াগুলোর হ্যাশ দেখা হয়
        val sha = if (!sys || updated) sha256(File(ai.sourceDir)) else ""
        val bad = SigDb.isBad(ctx, sha)
        if (sys) return AuditResult(name, p.packageName, if (bad) 100 else 0, if (bad) Risk.HIGH else Risk.LOW, emptyList(), sha, true, bad)

        var score = 0
        val reasons = mutableListOf<String>()
        val req = p.requestedPermissions ?: emptyArray()
        val rf = p.requestedPermissionsFlags ?: IntArray(0)
        req.forEachIndexed { i, perm ->
            val granted = (rf.getOrNull(i) ?: 0) and PackageInfo.REQUESTED_PERMISSION_GRANTED != 0
            dangerous[perm]?.let { d ->
                if (granted || d.w >= 20) { score += d.w; reasons += L.t(d.en, d.bn) }
            }
        }
        val installer = try {
            if (android.os.Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(p.packageName).installingPackageName
            else @Suppress("DEPRECATION") pm.getInstallerPackageName(p.packageName)
        } catch (e: Exception) { null }
        val fromStore = installer != null && installer in trustedStores
        // হ্যাশ তালিকায় না থাকলেও MalwareBazaar-এ সরাসরি জিজ্ঞেস (শুধু স্টোরের বাইরের অ্যাপের জন্য)
        var liveFam: String? = null
        if (!bad && !fromStore && sha.isNotEmpty() && Live.budget.getAndDecrement() > 0) liveFam = Live.mbLookup(ctx, sha)
        val isBad = bad || liveFam != null
        if (!fromStore) { score += 20; reasons += L.t("Installed from outside a trusted app store", "বিশ্বস্ত অ্যাপ স্টোরের বাইরের উৎস থেকে ইনস্টল করা") }
        val fake = fakeBrand(name, p.packageName)
        if (fake != null) { score += 45; reasons += L.t("Uses the name \"$fake\" but is not the official app", "\"$fake\" নাম ব্যবহার করছে কিন্তু আসল অ্যাপ নয়") }
        if (debugSigned(p)) { score += 15; reasons += L.t("Signed with a developer test key (not a normal release)", "ডেভেলপার টেস্ট কী দিয়ে সাইন করা (সাধারণ রিলিজ নয়)") }
        if ((ai.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) { score += 10; reasons += L.t("Running in debug mode (unusual)", "ডিবাগ মোডে আছে (সাধারণ অ্যাপে থাকার কথা নয়)") }
        val ex = Behavior.analyze(ctx, p, req.toSet(), ai, score)
        score += ex.score
        reasons += ex.reasons
        // কোডের ভেতর দেখা (নতুন ম্যালওয়্যার ধরার জন্য): স্টোরের বাইরের বা সন্দেহজনক অ্যাপে
        if (!fromStore || ex.score > 0 || fake != null) {
            val st = StaticScan.analyze(File(ai.sourceDir))
            score += st.score
            reasons += st.reasons
        }
        val prob = ModelScorer.prob(ctx, ex.features + ("sideloaded" to (if (!fromStore) 1.0 else 0.0)))
        if (prob >= 0.5) reasons += L.t("Risk model estimate: ${(prob * 100).toInt()}%", "ঝুঁকির মডেলের আন্দাজ: ${(prob * 100).toInt()}%")
        score = maxOf(score, (prob * 100).toInt())
        // স্টোর থেকে আসা অ্যাপ, এখন কোনো সন্দেহজনক ক্ষমতা ব্যবহার করছে না: শুধু অনুমতির তালিকার জন্য ভুল সতর্কতা নয়
        if (fromStore && ex.score == 0 && fake == null && !isBad) score = minOf(score, 29)
        if (fromStore && p.packageName.lowercase() in knownGood && !isBad) score = minOf(score, 29)
        if (isBad) {
            score = 100
            val fam = liveFam
            reasons.add(0, if (fam != null && fam != "known") L.t("Known malware found on MalwareBazaar: $fam", "MalwareBazaar-এ ধরা পড়া ম্যালওয়্যার: $fam")
                else if (fam != null) L.t("Known malware found on MalwareBazaar", "MalwareBazaar-এ ধরা পড়া ম্যালওয়্যার")
                else L.t("Matches a known malware signature", "পরিচিত ম্যালওয়্যারের সাথে মিলেছে"))
        }
        val risk = when { score >= 60 -> Risk.HIGH; score >= 30 -> Risk.MEDIUM; else -> Risk.LOW }
        return AuditResult(name, p.packageName, score.coerceAtMost(100), risk, reasons, sha, false, isBad)
    }

    fun sha256(f: File): String = try {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { s ->
            val buf = ByteArray(262144)
            while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { "" }
}

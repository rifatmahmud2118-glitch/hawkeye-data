package com.rifat.guard

import android.content.Context
import android.content.Intent
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger

data class Finding(val kind: String, val title: String, val detail: String, val risk: Risk, val path: String = "", val sha: String = "")

data class ScanResult(
    val type: String, val at: Long, val seconds: Long, val apps: Int, val files: Int, val skipped: Int,
    val threats: Int, val suspicious: Int, val score: Int, val findings: List<Finding>
)

// স্ক্যানের অবস্থা অ্যাপের ভেতরের পেইজ বদলালেও হারায় না, কারণ এটা কোনো পেইজের অংশ নয়
object ScanState {
    var running by mutableStateOf(false)
    var type by mutableStateOf("quick")
    var progress by mutableStateOf(0f)
    var stage by mutableStateOf("")
    var detail by mutableStateOf("")
    var result by mutableStateOf<ScanResult?>(null)
    var apps by mutableStateOf<List<AuditResult>>(emptyList())
    @Volatile var cancel = false
    private var loaded = false

    fun load(ctx: Context) { if (!loaded) { loaded = true; result = ResultIO.read(ctx) } }

    fun start(ctx: Context, t: String): Boolean {
        if (running) return false
        running = true; type = t; progress = 0f; cancel = false; detail = ""
        stage = L.t("Starting…", "শুরু হচ্ছে…")
        return try {
            ctx.applicationContext.startForegroundService(Intent(ctx.applicationContext, ScanService::class.java).putExtra("type", t))
            true
        } catch (e: Exception) { running = false; false }
    }

    fun removeFinding(ctx: Context, f: Finding) {
        val r = result ?: return
        val nl = r.findings.filter { it != f }
        val hi = nl.count { it.risk == Risk.HIGH }
        val md = nl.count { it.risk == Risk.MEDIUM }
        val n = r.copy(findings = nl, threats = hi, suspicious = md, score = (100 - minOf(60, hi * 15) - minOf(40, md * 4)).coerceIn(0, 100))
        result = n
        ResultIO.write(ctx, n)
    }
}

object ResultIO {
    fun write(ctx: Context, r: ScanResult) {
        val a = JSONArray()
        r.findings.take(500).forEach { f ->
            a.put(JSONObject().put("k", f.kind).put("t", f.title).put("d", f.detail).put("r", f.risk.name).put("p", f.path).put("s", f.sha))
        }
        val o = JSONObject().put("type", r.type).put("at", r.at).put("sec", r.seconds).put("apps", r.apps).put("files", r.files)
            .put("skip", r.skipped).put("thr", r.threats).put("sus", r.suspicious).put("score", r.score).put("f", a)
        File(ctx.filesDir, "last_scan.json").writeText(o.toString())
    }

    fun read(ctx: Context): ScanResult? = try {
        val o = JSONObject(File(ctx.filesDir, "last_scan.json").readText())
        val a = o.getJSONArray("f")
        val list = (0 until a.length()).map {
            val j = a.getJSONObject(it)
            Finding(j.getString("k"), j.getString("t"), j.getString("d"), Risk.valueOf(j.getString("r")), j.optString("p"), j.optString("s"))
        }
        ScanResult(o.getString("type"), o.getLong("at"), o.getLong("sec"), o.getInt("apps"), o.getInt("files"), o.getInt("skip"),
            o.getInt("thr"), o.getInt("sus"), o.getInt("score"), list)
    } catch (e: Exception) { null }
}

class FileVerdict(val finding: Finding?, val sha: String, val isApk: Boolean, val skipped: Boolean)

object Scanner {
    private val riskyExt = setOf("apk", "xapk", "apks", "jar", "dex", "exe", "scr", "bat", "cmd", "js", "vbs", "msi", "sh", "lnk", "dll")
    private val archiveExt = setOf("zip", "rar", "7z", "tar", "gz", "iso")
    private val docExt = setOf("pdf", "doc", "docm", "docx", "xls", "xlsm", "xlsx", "ppt", "pptm", "pptx", "rtf")
    private val mediaExt = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "mp3", "mp4", "mkv", "avi", "mov", "3gp", "wav", "ogg", "m4a", "aac", "flac")
    private val dblExt = Regex("(?i).*\\.(pdf|jpe?g|png|gif|docx?|xlsx?|pptx?|mp[34]|txt)\\.(apk|exe|scr|bat|cmd|js|vbs|jar|msi|sh|lnk)$")

    private enum class Magic { PK, ELF, MZ, DEX, OTHER }

    private fun magicOf(f: File): Magic = try {
        f.inputStream().use { s ->
            val b = ByteArray(8)
            val n = s.read(b)
            when {
                n < 4 -> Magic.OTHER
                b[0] == 0x50.toByte() && b[1] == 0x4B.toByte() && b[2] == 3.toByte() && b[3] == 4.toByte() -> Magic.PK
                b[0] == 0x7F.toByte() && b[1] == 'E'.code.toByte() && b[2] == 'L'.code.toByte() && b[3] == 'F'.code.toByte() -> Magic.ELF
                b[0] == 'M'.code.toByte() && b[1] == 'Z'.code.toByte() -> Magic.MZ
                b[0] == 'd'.code.toByte() && b[1] == 'e'.code.toByte() && b[2] == 'x'.code.toByte() && b[3] == 10.toByte() -> Magic.DEX
                else -> Magic.OTHER
            }
        }
    } catch (e: Exception) { Magic.OTHER }

    fun evaluate(ctx: Context, f: File, db: Set<String>, media: Boolean): FileVerdict {
        val name = f.name
        val ext = f.extension.lowercase()
        val size = f.length()
        val dbl = dblExt.matches(name)
        var disguised = false
        if (media && (ext in mediaExt || ext == "pdf") && !f.path.contains("sticker", true)) {
            val m = magicOf(f)
            disguised = m == Magic.PK || m == Magic.ELF || m == Magic.MZ || m == Magic.DEX
        }
        val limitMb = when {
            ext in riskyExt -> 400L
            ext in archiveExt -> 150L
            ext in docExt -> 60L
            else -> 0L
        }
        val limit = limitMb * 1024 * 1024
        val tooBig = limit > 0 && size > limit && !disguised && !dbl
        val need = disguised || dbl || (limit > 0 && size in 1..limit)
        if (!need) return FileVerdict(null, "", false, tooBig)
        val sha = AppAuditor.sha256(f)
        if (sha.isEmpty()) return FileVerdict(null, "", false, false)
        var fnd = when {
            db.contains(sha) -> Finding("file", name, L.t("Known malware (matches signature list)", "পরিচিত ম্যালওয়্যার (তালিকার সাথে মিলেছে)"), Risk.HIGH, f.path, sha)
            disguised -> Finding("file", name, L.t("An app or archive hiding behind a .$ext name", ".$ext নামের আড়ালে লুকানো অ্যাপ বা আর্কাইভ"), Risk.HIGH, f.path, sha)
            dbl -> Finding("file", name, L.t("Double-extension trick", "ডাবল এক্সটেনশন কৌশল"), Risk.HIGH, f.path, sha)
            ext == "apk" && Live.budget.getAndDecrement() > 0 && Live.mbLookup(ctx, sha) != null ->
                Finding("file", name, L.t("Known malware found on MalwareBazaar", "MalwareBazaar-এ ধরা পড়া ম্যালওয়্যার"), Risk.HIGH, f.path, sha)
            else -> null
        }
        if (fnd == null && ext == "apk") {
            val st = StaticScan.analyze(f)
            if (st.score >= 30) fnd = Finding("file", name, st.reasons.joinToString("; "), if (st.score >= 55) Risk.HIGH else Risk.MEDIUM, f.path, sha)
        }
        return FileVerdict(fnd, sha, ext == "apk" || ext == "xapk", false)
    }

    private fun setP(p: Float, stage: String, detail: String = "") {
        ScanState.progress = p; ScanState.stage = stage; ScanState.detail = detail
    }

    suspend fun run(ctx: Context, type: String) = withContext(Dispatchers.Default) {
        val t0 = System.currentTimeMillis()
        val full = type == "full"
        val findings: MutableList<Finding> = Collections.synchronizedList(ArrayList<Finding>())
        val db = SigDb.load(ctx)
        Live.budget.set(30)
        val media = Store.on(ctx, "scan_media", true)

        // ১) অ্যাপ
        val s1 = L.t("Checking installed apps", "ইনস্টল করা অ্যাপ যাচাই হচ্ছে")
        setP(0.02f, s1)
        val apps = AppAuditor.scan(ctx, full && Store.on(ctx, "scan_sys", true)) { d, n -> setP(0.02f + 0.18f * d / maxOf(n, 1), s1, "$d / $n") }
        ScanState.apps = apps.filter { !it.system }
        apps.forEach { a ->
            if (Trusted.isApp(ctx, a.pkg)) return@forEach
            if (a.knownBad) findings.add(Finding("app", a.name, L.t("Matches a known malware signature", "পরিচিত ম্যালওয়্যারের সাথে মিলেছে"), Risk.HIGH, a.pkg, a.sha256))
            else if (!a.system && a.risk != Risk.LOW) findings.add(Finding("app", a.name, a.reasons.joinToString("; "), a.risk, a.pkg, a.sha256))
        }
        if (ScanState.cancel) return@withContext

        // ২) ফাইলের তালিকা
        setP(0.22f, L.t("Indexing files", "ফাইল তালিকা করা হচ্ছে"))
        val base = Environment.getExternalStorageDirectory()
        val roots: List<File> = if (full) listOf(base) else
            listOf(Environment.DIRECTORY_DOWNLOADS, Environment.DIRECTORY_DOCUMENTS).map { Environment.getExternalStoragePublicDirectory(it) } + File(base, "Bluetooth")
        val depth = if (full) Int.MAX_VALUE else 3
        val files = ArrayList<File>()
        for (r in roots) {
            if (!r.exists()) continue
            r.walkTopDown().maxDepth(depth)
                .onEnter { d -> !d.path.contains("/Android/data") && !d.path.contains("/Android/obb") }
                .forEach { if (it.isFile) files.add(it) }
            if (ScanState.cancel) return@withContext
        }

        // ৩) প্রতিটি ফাইল (একসাথে কয়েকটা করে, তাই দ্রুত)
        val total = files.size
        val counted = AtomicInteger(0)
        val skipped = AtomicInteger(0)
        val apkFiles: MutableList<Finding> = Collections.synchronizedList(ArrayList<Finding>())
        val s3 = L.t("Scanning files", "ফাইল স্ক্যান হচ্ছে")
        var done = 0
        for (chunk in files.chunked(250)) {
            if (ScanState.cancel) break
            chunk.map { f ->
                async(Dispatchers.IO) {
                    try {
                        val v = evaluate(ctx, f, db, media)
                        counted.incrementAndGet()
                        if (v.skipped) skipped.incrementAndGet()
                        val fd = v.finding?.takeIf { !Trusted.isTrusted(ctx, it) }
                        if (fd != null) {
                            findings.add(fd)
                        } else if (v.isApk && v.sha.isNotEmpty()) {
                            apkFiles.add(Finding("file", f.name, "", Risk.LOW, f.path, v.sha))
                        }
                    } catch (e: Exception) { }
                    Unit
                }
            }.awaitAll()
            done += chunk.size
            setP(0.24f + 0.56f * done / maxOf(total, 1), s3, "$done / $total")
        }
        if (ScanState.cancel) return@withContext

        // ৪) ফোনের অবস্থা
        setP(0.82f, L.t("Checking phone settings", "ফোনের সেটিং যাচাই হচ্ছে"))
        DeviceHealth.run(ctx).filter { !it.ok }.forEach {
            val nf = Finding("device", it.title, it.detail, if (it.penalty >= 20) Risk.MEDIUM else Risk.LOW)
            if (!Trusted.isTrusted(ctx, nf)) findings.add(nf)
        }

        // ৫) অনলাইন যাচাই (VirusTotal)
        if (!ScanState.cancel && Store.get(ctx, "vt_key").isNotBlank() && Store.on(ctx, "scan_online", true)) {
            val cap = if (full) 12 else 4
            val pool = ArrayList<Finding>()
            pool += findings.filter { it.sha.isNotEmpty() && it.risk == Risk.MEDIUM }
            pool += apkFiles.take(cap)
            pool += apps.filter { !it.system && it.risk == Risk.LOW && it.sha256.isNotEmpty() }.sortedByDescending { it.score }.take(cap)
                .map { Finding("app", it.name, "", Risk.LOW, it.pkg, it.sha256) }
            val picks = pool.distinctBy { it.sha }.take(cap)
            var i = 0
            for (c in picks) {
                if (ScanState.cancel) break
                i++
                setP(0.88f + 0.11f * i / maxOf(picks.size, 1), L.t("Online check (VirusTotal)", "অনলাইনে যাচাই (VirusTotal)"), "$i / ${picks.size}: ${c.title}")
                val cached = VirusTotal.cached(ctx, c.sha)
                val r = cached ?: VirusTotal.fetch(ctx, c.sha).also { delay(16000) }
                VtStore.map[c.sha] = r
                if (r.level != Risk.LOW) {
                    val old = findings.firstOrNull { it.sha == c.sha }
                    findings.removeAll { it.sha == c.sha }
                    val d = if (old != null && old.detail.isNotEmpty()) old.detail + "; " + r.text() else r.text()
                    val nf = Finding(c.kind, c.title, d, r.level, c.path, c.sha)
                    if (!Trusted.isTrusted(ctx, nf)) findings.add(nf)
                }
            }
        }
        if (ScanState.cancel) return@withContext

        val list = findings.toList().sortedBy { it.risk.ordinal }.take(500)
        val high = list.count { it.risk == Risk.HIGH }
        val med = list.count { it.risk == Risk.MEDIUM }
        val score = (100 - minOf(60, high * 15) - minOf(40, med * 4)).coerceIn(0, 100)
        val res = ScanResult(type, t0, (System.currentTimeMillis() - t0) / 1000, apps.size, counted.get(), skipped.get(), high, med, score, list)
        ScanState.result = res
        ResultIO.write(ctx, res)
        setP(1f, L.t("Done", "শেষ"))
    }
}

// ---------- জাঙ্ক ক্লিনার ----------
data class Junk(val id: String, val title: String, val files: List<File>, val bytes: Long, val safe: Boolean = true, val note: String = "")
data class CleanResult(val freed: Long, val deleted: Int, val failed: Int)

object JunkCleaner {
    private val tempExt = setOf("tmp", "temp", "log", "bak", "old", "cache", "dmp", "chk", "crdownload", "part", "partial", "swp")

    private fun hash(f: File): String? = try {
        val md = java.security.MessageDigest.getInstance("MD5")
        val len = f.length()
        val buf = ByteArray(65536)
        if (len <= 32L * 1024 * 1024) {
            f.inputStream().use { ins -> while (true) { val n = ins.read(buf); if (n <= 0) break; md.update(buf, 0, n) } }
        } else {
            // বড় ফাইলের জন্য শুরু, মাঝ ও শেষের অংশ মিলিয়ে দেখা
            java.io.RandomAccessFile(f, "r").use { r ->
                for (pos in longArrayOf(0L, len / 2, len - 1048576L)) {
                    r.seek(pos.coerceAtLeast(0L))
                    var left = 1048576
                    while (left > 0) { val n = r.read(buf, 0, minOf(buf.size, left)); if (n <= 0) break; md.update(buf, 0, n); left -= n }
                }
            }
        }
        md.update(len.toString().toByteArray())
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { null }

    fun scan(ctx: Context, onProgress: (String) -> Unit = {}): List<Junk> {
        val base = Environment.getExternalStorageDirectory()
        val temp = ArrayList<File>(); val thumbs = ArrayList<File>(); val apks = ArrayList<File>()
        val trash = ArrayList<File>(); val zero = ArrayList<File>(); val large = ArrayList<File>()
        val dirs = ArrayList<File>()
        val bySize = HashMap<Long, MutableList<File>>()
        var seen = 0
        onProgress(L.t("Scanning storage…", "স্টোরেজ দেখা হচ্ছে…"))
        base.walkTopDown()
            .onEnter { d -> !(d.parentFile == base && d.name == "Android") }
            .onFail { _, _ -> }
            .forEach { f ->
                if (f.isDirectory) { if (f != base) dirs.add(f); return@forEach }
                seen++
                if (seen % 400 == 0) onProgress(L.t("Checked $seen files…", "$seen টি ফাইল দেখা হয়েছে…"))
                val n = f.name.lowercase(); val e = f.extension.lowercase(); val p = f.path; val len = f.length()
                if (p.contains("/.thumbnails/") || p.contains("/.thumbcache") || n.startsWith(".thumbdata")) thumbs.add(f)
                else if (n.startsWith(".trashed-") || p.contains("/.Trash/") || p.contains("/.trash/") || p.contains("/.recycle")) trash.add(f)
                else if (e in tempExt || n.endsWith("~")) temp.add(f)
                else if (e == "apk" && (p.contains("/Download") || f.parentFile == base || p.contains("/Bluetooth"))) apks.add(f)
                else if (len == 0L && n != ".nomedia") zero.add(f)
                else {
                    if (len > 100L * 1024 * 1024) large.add(f)
                    if (len >= 1048576L && !n.startsWith(".")) bySize.getOrPut(len) { ArrayList() }.add(f)
                }
            }

        // খালি ফোল্ডার (ভেতরে শুধু খালি ফোল্ডার থাকলেও খালি ধরা হয়, প্রধান ফোল্ডারগুলো বাদ)
        onProgress(L.t("Looking for empty folders…", "খালি ফোল্ডার খোঁজা হচ্ছে…"))
        val emptySet = HashSet<File>()
        dirs.sortedByDescending { it.path.length }.forEach { d ->
            val ch = d.listFiles()
            if (ch != null && ch.all { it in emptySet }) emptySet.add(d)
        }
        val empty = emptySet.filter { it.parentFile != base }

        // একই ফাইল একাধিক জায়গায় (সবচেয়ে পুরনোটা রাখা হয়)
        onProgress(L.t("Looking for duplicate files…", "একই ফাইল খোঁজা হচ্ছে…"))
        val dupes = ArrayList<File>()
        bySize.values.filter { it.size > 1 }.forEach { group ->
            val byHash = HashMap<String, MutableList<File>>()
            group.forEach { f -> val h = hash(f); if (h != null) byHash.getOrPut(h) { ArrayList() }.add(f) }
            byHash.values.filter { it.size > 1 }.forEach { g -> g.sortedBy { it.lastModified() }.drop(1).forEach { dupes.add(it) } }
        }
        val dupeSet = dupes.toHashSet()
        val bigOnly = large.filter { it !in dupeSet }.sortedByDescending { it.length() }.take(40)

        // এই অ্যাপের ক্যাশ
        val own = ArrayList<File>()
        listOfNotNull(ctx.cacheDir, ctx.externalCacheDir, ctx.codeCacheDir).forEach { d -> d.walkTopDown().forEach { if (it.isFile) own.add(it) } }

        // অন্য অ্যাপের ক্যাশ ও আনইনস্টল করা অ্যাপের ফেলে যাওয়া ফাইল (Android বাধা দিলে ফাঁকা আসবে)
        onProgress(L.t("Checking app leftovers…", "অ্যাপের পড়ে থাকা ফাইল দেখা হচ্ছে…"))
        val otherCache = ArrayList<File>(); val leftovers = ArrayList<File>()
        try {
            val pm = ctx.packageManager
            File(base, "Android/data").listFiles()?.forEach { d ->
                if (!d.isDirectory || d.name == ctx.packageName) return@forEach
                val installed = try { pm.getPackageInfo(d.name, 0); true } catch (e: Exception) { false }
                if (installed) File(d, "cache").walkTopDown().forEach { if (it.isFile) otherCache.add(it) }
                else d.walkTopDown().forEach { if (it.isFile) leftovers.add(it) }
            }
        } catch (e: Exception) { }

        fun sum(l: List<File>) = l.sumOf { if (it.isFile) it.length() else 0L }
        val all = listOf(
            Junk("own", L.t("This app's cache", "এই অ্যাপের ক্যাশ"), own, sum(own)),
            Junk("appcache", L.t("Other apps' cache", "অন্য অ্যাপের ক্যাশ"), otherCache, sum(otherCache)),
            Junk("temp", L.t("Temporary and log files", "অস্থায়ী ও লগ ফাইল"), temp, sum(temp)),
            Junk("thumb", L.t("Thumbnail cache", "থাম্বনেইল ক্যাশ"), thumbs, sum(thumbs)),
            Junk("trash", L.t("Recycle bin / trashed files", "রিসাইকেল বিন / ট্র্যাশের ফাইল"), trash, sum(trash)),
            Junk("zero", L.t("Empty (0 byte) files", "খালি (০ বাইট) ফাইল"), zero, 0L),
            Junk("empty", L.t("Empty folders", "খালি ফোল্ডার"), empty, 0L),
            Junk("apk", L.t("Downloaded installer files (.apk)", "ডাউনলোড করা ইনস্টলার ফাইল (.apk)"), apks, sum(apks), false,
                L.t("Check first. Your latest app update file may be here.", "আগে দেখে নিন। আপনার নতুন অ্যাপ আপডেটের ফাইলও এখানে থাকতে পারে।")),
            Junk("dupe", L.t("Duplicate files", "একই ফাইলের কপি"), dupes, sum(dupes), false,
                L.t("The oldest copy of each is kept. Check the list first.", "প্রতিটার সবচেয়ে পুরনো কপি থেকে যাবে। আগে তালিকা দেখে নিন।")),
            Junk("large", L.t("Large files (over 100 MB)", "বড় ফাইল (১০০ MB এর বেশি)"), bigOnly, sum(bigOnly), false,
                L.t("Only you know if you need these. Check the list first.", "এগুলো দরকার কিনা শুধু আপনি জানেন। আগে তালিকা দেখুন।")),
            Junk("left", L.t("Leftovers of uninstalled apps", "আনইনস্টল করা অ্যাপের ফেলে যাওয়া ফাইল"), leftovers, sum(leftovers), false,
                L.t("Games may keep saved data here.", "গেমের সেভ করা ডাটা এখানে থাকতে পারে।"))
        )
        return all.filter { it.files.isNotEmpty() }
    }

    fun clean(items: List<Junk>): CleanResult {
        var freed = 0L; var ok = 0; var bad = 0
        items.forEach { j ->
            val list = if (j.id == "empty") j.files.sortedByDescending { it.path.length } else j.files
            list.forEach { f ->
                val s = if (f.isFile) f.length() else 0L
                if (f.delete()) { freed += s; ok++ } else if (f.exists()) bad++
            }
        }
        return CleanResult(freed, ok, bad)
    }
}

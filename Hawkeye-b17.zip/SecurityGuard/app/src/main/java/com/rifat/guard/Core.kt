package com.rifat.guard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

// ভাষা: ডিফল্ট ইংরেজি
object L {
    var bn by mutableStateOf(false)
    fun t(en: String, bnText: String): String = if (bn) bnText else en
}

object Net {
    fun request(url: String, method: String = "GET", headers: Map<String, String> = emptyMap(), body: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 6000
            c.readTimeout = 8000
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { o: OutputStream -> o.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val s = if (code < 400) c.inputStream else c.errorStream
            return code to (s?.bufferedReader()?.use { it.readText() } ?: "")
        } finally { c.disconnect() }
    }

    fun bytes(url: String): Pair<Int, ByteArray> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 60000
            val code = c.responseCode
            val s = if (code < 400) c.inputStream else c.errorStream
            return code to (s?.readBytes() ?: ByteArray(0))
        } finally { c.disconnect() }
    }
}

object Store {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("guard", Context.MODE_PRIVATE)
    fun get(ctx: Context, k: String, d: String = ""): String = p(ctx).getString(k, d) ?: d
    fun put(ctx: Context, k: String, v: String) = p(ctx).edit().putString(k, v).apply()
    fun on(ctx: Context, k: String, d: Boolean = true): Boolean = get(ctx, k, if (d) "1" else "0") == "1"
    fun setOn(ctx: Context, k: String, v: Boolean) = put(ctx, k, if (v) "1" else "0")
    fun long(ctx: Context, k: String, d: Long = 0L): Long = get(ctx, k, d.toString()).toLongOrNull() ?: d
}

object Alerts {
    const val CH_ALERT = "guard_alerts"
    const val CH_QUIET = "guard_quiet"
    const val CH_PROGRESS = "guard_progress"
    const val CH_SHIELD = "guard_shield"

    fun init(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_QUIET, "Scan finished (silent)", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Scan progress", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_SHIELD, "Protection status", NotificationManager.IMPORTANCE_MIN))
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun notify(ctx: Context, title: String, text: String, channel: String = CH_ALERT, id: Int = (System.nanoTime() % 100000).toInt()) {
        init(ctx)
        val n = Notification.Builder(ctx, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }

    fun notifyAction(ctx: Context, title: String, text: String, label: String, action: PendingIntent, id: Int = (System.nanoTime() % 100000).toInt()) {
        init(ctx)
        val n = Notification.Builder(ctx, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.ic_menu_delete), label, action).build())
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }

    fun done(ctx: Context, title: String, text: String) {
        val ch = if (Store.on(ctx, "scan_sound", true)) CH_ALERT else CH_QUIET
        notify(ctx, title, text, ch, 4242)
    }

    fun progress(ctx: Context, title: String, text: String, pct: Int, indeterminate: Boolean): Notification {
        init(ctx)
        val stop = PendingIntent.getService(
            ctx, 1, Intent(ctx, ScanService::class.java).setAction("cancel"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setProgress(100, pct, indeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel), L.t("Stop", "থামান"), stop).build())
            .build()
    }

    fun shield(ctx: Context): Notification {
        init(ctx)
        return Notification.Builder(ctx, CH_SHIELD)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle(L.t("Real-time protection is on", "রিয়েল-টাইম সুরক্ষা চালু আছে"))
            .setContentText(L.t("Watching new files, installs and permissions", "নতুন ফাইল, ইনস্টল ও অনুমতি পাহারা দিচ্ছে"))
            .setOngoing(true)
            .setContentIntent(openApp(ctx))
            .build()
    }
}

package com.rifat.guard

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import java.io.File
import kotlin.math.abs

data class Batt(
    val level: Int, val status: String, val charging: Boolean, val source: String, val health: String,
    val tempC: Float, val voltageMv: Int, val currentMa: Int, val powerW: Float, val tech: String,
    val nowMah: Int, val fullMah: Int, val designMah: Int, val healthPct: Int, val cycles: Int,
    val currentEstimated: Boolean = false, val measuring: Boolean = false, val avgMa: Int = 0,
    val energyMwh: Int = 0, val timeToFullMin: Int = -1, val runtimeMin: Int = -1,
    val minTempC: Float = 0f, val maxTempC: Float = 0f, val present: Boolean = true
)

object BatteryReader {
    private var lastCounter = 0L
    private var lastAt = 0L
    private var lastCharging: Boolean? = null
    private var estMa = 0
    private var minT = 1000f
    private var maxT = -1000f

    private fun prop(bm: BatteryManager, id: Int): Int = try { bm.getIntProperty(id) } catch (e: Throwable) { Int.MIN_VALUE }

    fun read(ctx: Context): Batt {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val status = when (st) {
            BatteryManager.BATTERY_STATUS_CHARGING -> L.t("Charging", "চার্জ হচ্ছে")
            BatteryManager.BATTERY_STATUS_DISCHARGING -> L.t("Discharging", "চার্জ কমছে")
            BatteryManager.BATTERY_STATUS_FULL -> L.t("Full", "পূর্ণ")
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> L.t("Not charging", "চার্জ হচ্ছে না")
            else -> L.t("Unknown", "জানা যায়নি")
        }
        val source = when (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) {
            BatteryManager.BATTERY_PLUGGED_AC -> L.t("AC charger", "AC চার্জার")
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> L.t("Wireless", "ওয়্যারলেস")
            0 -> L.t("Battery", "ব্যাটারি")
            else -> L.t("Dock", "ডক")
        }
        val health = when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0) {
            BatteryManager.BATTERY_HEALTH_GOOD -> L.t("Good", "ভালো")
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> L.t("Overheating", "অতিরিক্ত গরম")
            BatteryManager.BATTERY_HEALTH_DEAD -> L.t("Dead", "নষ্ট")
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> L.t("Over voltage", "ভোল্টেজ বেশি")
            BatteryManager.BATTERY_HEALTH_COLD -> L.t("Too cold", "অতিরিক্ত ঠান্ডা")
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> L.t("Failure", "ত্রুটি")
            else -> L.t("Unknown", "জানা যায়নি")
        }
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val volt = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val tech = i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "-"
        val present = i?.getBooleanExtra(BatteryManager.EXTRA_PRESENT, true) ?: true
        if (temp != 0f) { if (temp < minT) minT = temp; if (temp > maxT) maxT = temp }

        val bm = ctx.getSystemService(BatteryManager::class.java)

        // কারেন্ট: প্রথমে সিস্টেমের মান, না পেলে সিস্টেম ফাইল, না পেলে চার্জ কাউন্টারের পরিবর্তন থেকে হিসাব
        fun norm(raw: Int): Int = if (raw == Int.MIN_VALUE || raw == 0) 0 else if (abs(raw) < 20000) abs(raw) else abs(raw) / 1000
        fun normL(c: Long?): Int = if (c == null || c == 0L) 0 else (if (abs(c) < 20000) abs(c) else abs(c) / 1000).toInt()
        var ma = norm(prop(bm, BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
        var avg = norm(prop(bm, BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE))
        if (ma == 0) ma = normL(sys("current_now", "batt_current_ua_now", "current_avg"))
        if (avg == 0) avg = normL(sys("current_avg"))
        if (ma == 0 && avg > 0) ma = avg

        var design = designCapacity(ctx)
        if (design == 0) design = toMah(sysPos("charge_full_design"))

        // চার্জ কাউন্টার (µAh)
        val counterRaw = prop(bm, BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        var cu: Long = if (counterRaw > 0) counterRaw.toLong() else (sysPos("charge_counter", "charge_now") ?: 0L)
        if (cu in 1L..100000L) cu *= 1000
        // কাউন্টারের মান ডিজাইন ক্যাপাসিটির সাথে না মিললে ভুল ধরে বাদ দেওয়া হয়
        if (cu > 0 && design > 0) {
            val m = (cu / 1000).toInt()
            if (m > design * 13 / 10 || (pct >= 5 && m * 100 / pct < design * 35 / 100)) cu = 0
        }
        val nowMah = (cu / 1000).toInt()

        val tNow = SystemClock.elapsedRealtime()
        if (cu > 0) {
            if (lastCharging != charging) { lastCharging = charging; lastAt = tNow; lastCounter = cu; estMa = 0 }
            else if (lastAt == 0L) { lastAt = tNow; lastCounter = cu }
            else if (tNow - lastAt >= 12000) {
                val d = cu - lastCounter
                if (d != 0L) estMa = abs(d * 3600L / (tNow - lastAt)).toInt()
                lastAt = tNow; lastCounter = cu
            }
        }
        var estimated = false
        var measuring = false
        if (ma == 0 && cu > 0) { if (estMa > 0) { ma = estMa; estimated = true } else measuring = true }

        // ক্যাপাসিটি
        var full = toMah(sysPos("charge_full"))
        if (design > 0 && (full < design * 35 / 100 || full > design * 13 / 10)) full = 0
        if (full == 0 && nowMah > 0 && pct >= 5) full = nowMah * 100 / pct

        // চার্জ সাইকেল
        var cyc = if (Build.VERSION.SDK_INT >= 34) (i?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) ?: -1) else -1
        if (cyc <= 0) {
            val c = sys("cycle_count", "batt_cycle", "battery_cycle", "bat_cycle")
            if (c != null && c >= 0 && c > cyc) cyc = c.toInt()
        }

        // হেলথ: Android 14+ এ সরাসরি, না হলে বর্তমান ও ডিজাইন ক্যাপাসিটির তুলনা
        val soh = if (Build.VERSION.SDK_INT >= 34) prop(bm, 10) else Int.MIN_VALUE
        val hp = if (soh in 1..100) soh else if (design > 0 && full > 0) (full * 100 / design).coerceAtMost(100) else -1

        val energy = try { bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_ENERGY_COUNTER) } catch (e: Throwable) { Long.MIN_VALUE }
        val energyMwh = if (energy > 0) (energy / 1_000_000L).toInt() else 0

        var ttf = -1
        if (charging) {
            val r = try { bm.computeChargeTimeRemaining() } catch (e: Throwable) { -1L }
            if (r > 0) ttf = (r / 60000L).toInt()
            else if (ma > 0 && full > nowMah && nowMah > 0 && pct < 100) ttf = (full - nowMah) * 60 / ma
        }
        val runtime = if (!charging && ma > 0 && nowMah > 0) nowMah * 60 / ma else -1

        val watts = volt / 1000f * ma / 1000f
        return Batt(pct, status, charging, source, health, temp, volt, ma, watts, tech, nowMah, full, design, hp, cyc,
            currentEstimated = estimated, measuring = measuring, avgMa = avg, energyMwh = energyMwh,
            timeToFullMin = ttf, runtimeMin = runtime,
            minTempC = if (minT > 999f) temp else minT, maxTempC = if (maxT < -999f) temp else maxT, present = present)
    }

    // ব্যাটারি-সংক্রান্ত সিস্টেম ফোল্ডার (সব ফোনে পড়া যায় না)
    private fun dirs(): List<File> {
        val root = File("/sys/class/power_supply")
        val all = try { root.listFiles()?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }
        val keys = listOf("battery", "bms", "bat", "fg", "main")
        val picked = all.filter { d -> keys.any { d.name.lowercase().contains(it) } }
        return if (picked.isEmpty()) listOf(File(root, "battery"), File(root, "bms")) else picked.sortedBy { d -> keys.indexOfFirst { d.name.lowercase().contains(it) } }
    }

    private fun sys(vararg names: String): Long? {
        for (d in dirs()) for (n in names) {
            try {
                val v = File(d, n).readText().trim().toLongOrNull()
                if (v != null) return v
            } catch (e: Exception) { }
        }
        return null
    }

    private fun sysPos(vararg names: String): Long? {
        for (d in dirs()) for (n in names) {
            try {
                val v = File(d, n).readText().trim().toLongOrNull()
                if (v != null && v > 0) return v
            } catch (e: Exception) { }
        }
        return null
    }

    private fun toMah(v: Long?): Int = if (v == null || v <= 0) 0 else if (v > 100000) (v / 1000).toInt() else v.toInt()

    private fun designCapacity(ctx: Context): Int = try {
        val c = Class.forName("com.android.internal.os.PowerProfile")
        val o = c.getConstructor(Context::class.java).newInstance(ctx)
        (c.getMethod("getBatteryCapacity").invoke(o) as Double).toInt()
    } catch (e: Throwable) { 0 }
}

package com.rifat.guard

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object Perms {
    fun files() = Environment.isExternalStorageManager()
    fun sms(c: Context) = c.checkSelfPermission("android.permission.RECEIVE_SMS") == 0
    fun phone(c: Context) = c.checkSelfPermission("android.permission.READ_PHONE_STATE") == 0 && c.checkSelfPermission("android.permission.READ_CALL_LOG") == 0
    fun notifAccess(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    fun battery(c: Context) = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
    fun post(c: Context) = Build.VERSION.SDK_INT < 33 || c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == 0
    fun open(c: Context, i: Intent) { try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } }
    fun filesIntent(c: Context) = Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${c.packageName}"))
    fun batteryIntent(c: Context) = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}"))
    fun listenerIntent() = Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
}

fun setShield(ctx: Context, on: Boolean) {
    Store.setOn(ctx, "shield_on", on)
    val i = Intent(ctx, ShieldService::class.java)
    try { if (on) ctx.startForegroundService(i) else ctx.stopService(i) } catch (e: Exception) { }
}

@Composable
fun PermRow(ok: Boolean, title: String, onGrant: () -> Unit) {
    ActionRow(if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning, title,
        if (ok) L.t("Granted", "দেওয়া আছে") else L.t("Not granted. Tap to allow", "দেওয়া নেই। চাপ দিয়ে অনুমতি দিন")) { if (!ok) onGrant() }
}

@Composable
fun ShieldsScreen() {
    val ctx = LocalContext.current
    val tick = resumeTick()
    var master by remember { mutableStateOf(Store.on(ctx, "shield_on", false)) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    val files = remember(tick) { Perms.files() }
    val listener = remember(tick) { Perms.notifAccess(ctx) }
    val sms = remember(tick) { Perms.sms(ctx) }
    Page {
        GCard {
            SettingRow(Icons.Filled.Shield, L.t("Real-time protection", "রিয়েল-টাইম প্রোটেকশন"),
                L.t("Keeps the shields below watching in the background", "নিচের শিল্ডগুলো ব্যাকগ্রাউন্ডে পাহারা দেবে"), master) { master = it; setShield(ctx, it) }
            if (!Perms.battery(ctx)) ActionRow(Icons.Filled.BatteryChargingFull, L.t("Allow unrestricted battery use", "ব্যাটারি সীমা তুলে দিন"),
                L.t("Stops the phone from killing protection in the background", "ফোন যেন পেছনে সুরক্ষা বন্ধ না করে")) { Perms.open(ctx, Perms.batteryIntent(ctx)) }
        }
        GCard {
            val alive = ShieldService.alive
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (alive) Icons.Filled.CheckCircle else Icons.Filled.Warning, null, tint = if (alive) riskColor(Risk.LOW) else riskColor(Risk.HIGH))
                Spacer(Modifier.width(8.dp))
                H(if (alive) L.t("Protection is running", "সুরক্ষা চলছে") else L.t("Protection is stopped", "সুরক্ষা বন্ধ"))
            }
            TRow(L.t("Items checked", "যাচাই করা জিনিস"), "${ShieldStats.checked}")
            TRow(L.t("Threats blocked", "আটকানো হুমকি"), "${ShieldStats.blocked}")
            if (ShieldStats.last.isNotEmpty()) TRow(L.t("Last threat", "সর্বশেষ হুমকি"), ShieldStats.last)
            StoreToggle(Icons.Filled.Delete, L.t("Auto-quarantine dangerous files", "বিপজ্জনক ফাইল নিজে কোয়ারেন্টিনে"),
                L.t("Moves confirmed threats out of your folders the moment they appear", "নিশ্চিত হুমকি আসামাত্র আপনার ফোল্ডার থেকে সরিয়ে ফেলে"), "auto_q", true)
        }
        QuarantineCard()
        SectionLabel(L.t("Shields", "শিল্ড"))
        GCard {
            StoreToggle(Icons.Filled.Folder, "File Shield", L.t("Checks every new download or file the moment it lands (Downloads, Documents, Bluetooth, WhatsApp and Telegram files)", "নতুন ডাউনলোড বা ফাইল আসার সাথে সাথে যাচাই করে (ডাউনলোড, ডকুমেন্ট, ব্লুটুথ, WhatsApp ও Telegram ফাইল)"), "file_on")
            PermRow(files, L.t("All files access", "সব ফাইল অ্যাক্সেস")) { Perms.open(ctx, Perms.filesIntent(ctx)) }
        }
        GCard {
            StoreToggle(Icons.Filled.BugReport, "Behavior Shield", L.t("Catches suspicious behavior: a new app with risky permissions, or an app suddenly getting Accessibility, notification reading, device admin or default SMS rights", "সন্দেহজনক আচরণ ধরে: ঝুঁকিপূর্ণ অনুমতিওয়ালা নতুন অ্যাপ, বা হঠাৎ Accessibility, নোটিফিকেশন পড়া, ডিভাইস অ্যাডমিন বা ডিফল্ট SMS অধিকার পাওয়া অ্যাপ"), "beh_on")
        }
        GCard {
            StoreToggle(Icons.Filled.Email, "Email Shield", L.t("Scans phishing links and warnings in Gmail, Outlook, Yahoo and other mail notifications. Attachments are caught by File Shield when saved, or share them to this app.", "Gmail, Outlook, Yahoo ইত্যাদির নোটিফিকেশনের ফিশিং লিংক যাচাই। অ্যাটাচমেন্ট সেভ হলে File Shield ধরে, অথবা এই অ্যাপে শেয়ার করুন।"), "email_on")
            StoreToggle(Icons.Filled.Chat, "Message Shield", L.t("Checks links in WhatsApp, Messenger and Telegram notifications", "WhatsApp, Messenger ও Telegram নোটিফিকেশনের লিংক যাচাই"), "msg_on")
            PermRow(listener, L.t("Notification access", "নোটিফিকেশন অ্যাক্সেস")) { Perms.open(ctx, Perms.listenerIntent()) }
        }
        GCard {
            StoreToggle(Icons.Filled.Sms, "SMS Shield", L.t("Checks links and OTP traps in incoming SMS", "আসা SMS-এর লিংক ও OTP ফাঁদ যাচাই"), "sms_on")
            PermRow(sms, L.t("SMS permission", "SMS অনুমতি")) {
                val p = mutableListOf("android.permission.RECEIVE_SMS")
                if (Build.VERSION.SDK_INT >= 33) p += "android.permission.POST_NOTIFICATIONS"
                perm.launch(p.toTypedArray())
            }
        }
        Hint(L.t("If the phone blocks a permission (restricted settings): Phone Settings > Apps > Rifat's Hawkeye > three dots > Allow restricted settings.",
            "ফোন অনুমতি আটকালে: ফোনের Settings > Apps > Rifat's Hawkeye > তিন ফোঁটা > Allow restricted settings।"))
    }
}

@Composable
fun CallsScreen() {
    val ctx = LocalContext.current
    val tick = resumeTick()
    val scope = rememberCoroutineScope()
    val phone = remember(tick) { Perms.phone(ctx) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    val role = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}
    var spam by remember { mutableStateOf(CallRisk.spamList(ctx)) }
    var num by remember { mutableStateOf("") }
    var test by remember { mutableStateOf("") }
    Page {
        GCard {
            StoreToggle(Icons.Filled.Phone, L.t("Spam call protection", "স্প্যাম কল সুরক্ষা"),
                L.t("Warns when a risky number rings. Works without making this your default phone app.", "ঝুঁকিপূর্ণ নম্বর থেকে কল এলে সতর্ক করে। এই অ্যাপকে ডিফল্ট কল অ্যাপ করতে হয় না।"), "call_on")
            PermRow(phone, L.t("Phone state and call log access", "ফোন স্টেট ও কল লগ অ্যাক্সেস")) {
                perm.launch(arrayOf("android.permission.READ_PHONE_STATE", "android.permission.READ_CALL_LOG"))
            }
            Hint(L.t("How it works: Android tells this app when a call rings and from which number (needs the two permissions above). The number is checked against your spam list and for foreign-number scam patterns, including one-ring missed-call traps. Calls are never recorded or blocked.",
                "কীভাবে কাজ করে: কল বাজলে Android এই অ্যাপকে নম্বরটা জানায় (উপরের দুটো অনুমতি লাগে)। নম্বরটা আপনার স্প্যাম তালিকা ও বিদেশি-নম্বর ফাঁদের ধরনের সাথে মেলানো হয়, এক রিংয়ের মিসড কল ফাঁদসহ। কল কখনও রেকর্ড বা আটকানো হয় না।"))
            val rm = ctx.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) && !rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING))
                ActionRow(Icons.Filled.Shield, L.t("Optional: stronger call screening", "ঐচ্ছিক: আরও জোরালো কল স্ক্রিনিং"),
                    L.t("Android's call screening role. Not a default dialer.", "Android-এর কল স্ক্রিনিং ভূমিকা। ডিফল্ট ডায়ালার নয়।")) {
                    role.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                }
        }
        GCard {
            H(L.t("My spam numbers", "আমার স্প্যাম নম্বর"))
            OutlinedTextField(num, { num = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(L.t("Phone number", "ফোন নম্বর")) })
            BigButton(L.t("Add to spam list", "স্প্যাম তালিকায় যোগ"), Icons.Filled.Add, enabled = num.length >= 6) {
                Store.put(ctx, "spam_list", (spam + num.trim()).joinToString("\n")); spam = CallRisk.spamList(ctx); num = ""
            }
            spam.forEach { s ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(s, Modifier.weight(1f))
                    IconButton({ Store.put(ctx, "spam_list", (spam - s).joinToString("\n")); spam = CallRisk.spamList(ctx) }) { Icon(Icons.Filled.Delete, null) }
                }
            }
        }
        GCard {
            H(L.t("Check a number", "নম্বর যাচাই"))
            var q by remember { mutableStateOf("") }
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(L.t("Number to check", "যাচাইয়ের নম্বর")) })
            BigButton(L.t("Check", "যাচাই"), Icons.Filled.Search, enabled = q.length >= 4) {
                val r = CallRisk.check(ctx, q)
                test = if (r.isEmpty()) L.t("Nothing suspicious found in this number's pattern.", "নম্বরের ধরনে সন্দেহজনক কিছু পাওয়া যায়নি।") else r.joinToString("\n• ", "• ")
            }
            if (test.isNotEmpty()) Text(test)
        }
    }
}

@Composable
fun LinksScreen(shared: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember(shared) { mutableStateOf(shared) }
    var rep by remember { mutableStateOf<Report?>(null) }
    var busy by remember { mutableStateOf(false) }
    Page {
        Hint(L.t("Paste a suspicious link or a whole message. You can also share text from any app to Rifat's Hawkeye.", "সন্দেহজনক লিংক বা পুরো মেসেজ পেস্ট করুন। যেকোনো অ্যাপ থেকে লেখা শেয়ার করেও পাঠানো যাবে।"))
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), minLines = 3)
        BigButton(if (busy) L.t("Checking…", "যাচাই চলছে…") else L.t("Check", "যাচাই করুন"), Icons.Filled.Link, enabled = !busy && text.isNotBlank()) {
            busy = true; scope.launch(Dispatchers.IO) { rep = Inspector.analyze(ctx, text); busy = false }
        }
        rep?.let {
            GCard {
                Text(it.level.label(), style = MaterialTheme.typography.titleLarge, color = riskColor(it.level))
                if (it.reasons.isEmpty()) Text(L.t("Nothing suspicious found. Still, never share an OTP or password with anyone.", "সন্দেহজনক কিছু পাওয়া যায়নি। তবুও কাউকে OTP বা পাসওয়ার্ড দেবেন না।"))
                it.reasons.forEach { r -> Text("• $r", style = MaterialTheme.typography.bodyMedium) }
            }
        }
    }
}

@Composable
fun FilesScreen(shared: List<Uri>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<ScannedFile>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    fun verify(uris: List<Uri>) {
        busy = true
        scope.launch(Dispatchers.IO) {
            val db = SigDb.load(ctx)
            val list = uris.take(10).map { FileScanner.fromUri(ctx, it) }
            files = list
            for ((i, f) in list.withIndex()) {
                if (db.contains(f.sha)) { VtStore.map[f.sha] = VtResult("bad", 99, 0); continue }
                msg = L.t("VirusTotal check ${i + 1}/${list.size}", "VirusTotal যাচাই ${i + 1}/${list.size}")
                val c = VirusTotal.cached(ctx, f.sha)
                if (c != null) { VtStore.map[f.sha] = c; continue }
                val r = VirusTotal.fetch(ctx, f.sha); VtStore.map[f.sha] = r
                if (r.status == "nokey") break
                delay(16000)
            }
            msg = L.t("Done", "শেষ"); busy = false
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { if (it.isNotEmpty()) verify(it) }
    LaunchedEffect(shared) { if (shared.isNotEmpty()) verify(shared) }
    Page {
        Hint(L.t("Pick suspicious files (APK, ZIP, PDF, documents, email attachments), up to 10. You can also share a file from any app to Rifat's Hawkeye. Only the files you choose are read.",
            "সন্দেহজনক ফাইল (APK, ZIP, PDF, ডকুমেন্ট, ইমেইলের অ্যাটাচমেন্ট) বাছুন, সর্বোচ্চ ১০টি। যেকোনো অ্যাপ থেকে ফাইল শেয়ার করেও পাঠানো যাবে। শুধু আপনার বাছাই করা ফাইল পড়া হবে।"))
        BigButton(if (busy) L.t("Checking…", "যাচাই চলছে…") else L.t("Choose files and check", "ফাইল বাছুন ও যাচাই করুন"), Icons.Filled.Description, enabled = !busy) { picker.launch(arrayOf("*/*")) }
        if (msg.isNotEmpty()) Hint(msg)
        files.forEach { f ->
            GCard { Text(f.name, style = MaterialTheme.typography.titleSmall); Hint("${f.sizeKb} KB"); VtLine(VtStore.map[f.sha]) }
        }
    }
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val apps = ScanState.apps
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton(L.t("Check app permissions", "অ্যাপের অনুমতি যাচাই"), Icons.Filled.Apps, enabled = !busy) {
                    busy = true; scope.launch { ScanState.apps = AppAuditor.scan(ctx); busy = false }
                }
                BigButton(L.t("Check top 12 with VirusTotal", "সবচেয়ে ঝুঁকিপূর্ণ ১২টি VirusTotal-এ যাচাই"), Icons.Filled.Search, enabled = !busy && apps.isNotEmpty(), outlined = true) {
                    busy = true
                    scope.launch(Dispatchers.IO) {
                        for ((i, a) in apps.take(12).withIndex()) {
                            msg = "${i + 1}/12: ${a.name}"
                            val c = VirusTotal.cached(ctx, a.sha256)
                            if (c != null) { VtStore.map[a.sha256] = c; continue }
                            val r = VirusTotal.fetch(ctx, a.sha256); VtStore.map[a.sha256] = r
                            if (r.status == "nokey") break
                            delay(16000)
                        }
                        msg = L.t("Done", "শেষ"); busy = false
                    }
                }
                if (msg.isNotEmpty()) Hint(msg)
                if (apps.isEmpty()) Hint(L.t("Tap the first button to list your apps by risk.", "প্রথম বাটন চেপে অ্যাপগুলো ঝুঁকি অনুযায়ী দেখুন।"))
            }
        }
        items(apps) { r ->
            GCard {
                var isT by remember(r.pkg) { mutableStateOf(Trusted.isApp(ctx, r.pkg)) }
                Row(Modifier.fillMaxWidth()) {
                    Text(r.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    if (isT) Text(L.t("Trusted", "বিশ্বস্ত"), style = MaterialTheme.typography.labelMedium, color = riskColor(Risk.LOW))
                    else Text("${r.risk.label()} (${r.score})", style = MaterialTheme.typography.labelMedium, color = riskColor(r.risk))
                }
                Hint(r.pkg)
                r.reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
                VtLine(VtStore.map[r.sha256])
                if (r.risk != Risk.LOW) BigButton(L.t("Open app settings", "অ্যাপের সেটিংস"), Icons.Filled.Settings, outlined = true) {
                    Perms.open(ctx, Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + r.pkg)))
                }
                if (r.risk != Risk.LOW && !isT) BigButton(L.t("I know it is safe: skip next time", "আমি জানি নিরাপদ: পরের বার বাদ"), Icons.Filled.CheckCircle, outlined = true) {
                    Trusted.add(ctx, Finding("app", r.name, "", r.risk, r.pkg, r.sha256)); isT = true
                }
                if (isT) BigButton(L.t("Remove from trusted", "বিশ্বস্ত তালিকা থেকে সরান"), Icons.Filled.Delete, outlined = true) {
                    Trusted.remove(ctx, "app:" + r.pkg); isT = false
                }
            }
        }
    }
}

@Composable
fun JunkScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<Junk>>(emptyList()) }
    val sel = remember { mutableStateMapOf<String, Boolean>() }
    var expanded by remember { mutableStateOf(setOf<String>()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var scanned by remember { mutableStateOf(false) }
    var ask by remember { mutableStateOf(false) }
    val files = remember(resumeTick()) { Perms.files() }
    val st = remember(msg, scanned) {
        try { val s = StatFs(Environment.getExternalStorageDirectory().path); s.availableBytes to s.totalBytes } catch (e: Exception) { 0L to 0L }
    }
    val root = Environment.getExternalStorageDirectory().path
    val chosen = items.filter { sel[it.id] == true }
    val total = chosen.sumOf { it.bytes }
    val count = chosen.sumOf { it.files.size }
    val review = chosen.any { !it.safe }
    Page {
        GCard {
            H(L.t("Phone storage", "ফোনের স্টোরেজ"))
            if (st.second > 0) {
                val used = st.second - st.first
                LinearProgressIndicator(progress = { used.toFloat() / st.second }, modifier = Modifier.fillMaxWidth())
                Hint(L.t("${fmtBytes(used)} used • ${fmtBytes(st.first)} free • ${fmtBytes(st.second)} total", "${fmtBytes(used)} ব্যবহৃত • ${fmtBytes(st.first)} খালি • মোট ${fmtBytes(st.second)}"))
            }
        }
        Hint(L.t("Finds cache, temporary and log files, thumbnails, trash, empty files and folders, duplicates, old installers and large files. Items marked safe are selected for you. Android locks other apps' private caches, so some may not show.",
            "ক্যাশ, অস্থায়ী ও লগ ফাইল, থাম্বনেইল, ট্র্যাশ, খালি ফাইল ও ফোল্ডার, একই ফাইলের কপি, পুরনো ইনস্টলার ও বড় ফাইল খোঁজে। নিরাপদগুলো নিজে থেকে বাছা থাকে। অন্য অ্যাপের ব্যক্তিগত ক্যাশ Android তালাবদ্ধ রাখে, তাই কিছু নাও দেখা যেতে পারে।"))
        if (!files) PermRow(false, L.t("All files access", "সব ফাইল অ্যাক্সেস")) { Perms.open(ctx, Perms.filesIntent(ctx)) }
        BigButton(if (busy) L.t("Working…", "কাজ চলছে…") else L.t("Scan for junk", "জাঙ্ক খুঁজুন"), Icons.Filled.CleaningServices, enabled = !busy) {
            busy = true; msg = ""; status = ""
            scope.launch(Dispatchers.IO) {
                val r = try { JunkCleaner.scan(ctx) { status = it } } catch (e: Exception) { emptyList<Junk>() }
                withContext(Dispatchers.Main) {
                    items = r; sel.clear(); expanded = emptySet()
                    r.forEach { sel[it.id] = it.safe }
                    busy = false; scanned = true; status = ""
                }
            }
        }
        if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth()); if (status.isNotEmpty()) Hint(status) }
        if (scanned && items.isEmpty() && !busy) Text(L.t("Nothing to clean. Your phone is tidy.", "পরিষ্কার করার মতো কিছু নেই। ফোন গোছানো আছে।"), style = MaterialTheme.typography.titleSmall)
        if (items.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton({ items.forEach { sel[it.id] = true } }) { Text(L.t("Select all", "সব বাছুন")) }
                TextButton({ items.forEach { sel[it.id] = false } }) { Text(L.t("Select none", "কিছুই না")) }
                TextButton({ items.forEach { sel[it.id] = it.safe } }) { Text(L.t("Safe only", "শুধু নিরাপদ")) }
            }
        }
        items.forEach { j ->
            val icon = when (j.id) {
                "large" -> Icons.Filled.Storage; "dupe" -> Icons.Filled.ContentCopy; "apk" -> Icons.Filled.Android
                "empty", "zero" -> Icons.Filled.FolderOpen; "trash" -> Icons.Filled.DeleteSweep; else -> Icons.Filled.Delete
            }
            val sub = "${j.files.size} " + L.t("items", "টি") + (if (j.bytes > 0) " • " + fmtBytes(j.bytes) else "")
            GCard {
                SettingRow(icon, j.title, sub, sel[j.id] == true) { sel[j.id] = it }
                if (j.note.isNotEmpty()) Hint(j.note)
                val shown = j.id in expanded
                TextButton({ expanded = if (shown) expanded - j.id else expanded + j.id }) { Text(if (shown) L.t("Hide files", "ফাইল লুকান") else L.t("Show files", "ফাইল দেখুন")) }
                if (shown) {
                    j.files.take(12).forEach { f ->
                        Hint(f.path.removePrefix(root) + (if (f.isFile) "  •  " + fmtBytes(f.length()) else ""))
                    }
                    if (j.files.size > 12) Hint(L.t("+ ${j.files.size - 12} more", "+ আরও ${j.files.size - 12} টি"))
                }
            }
        }
        if (items.isNotEmpty()) {
            BigButton(L.t("Clean selected (${fmtBytes(total)})", "বাছাইগুলো পরিষ্কার (${fmtBytes(total)})"), Icons.Filled.CleaningServices, enabled = count > 0 && !busy) { ask = true }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.titleSmall)
        BigButton(L.t("System storage and app cache", "সিস্টেম স্টোরেজ ও অ্যাপ ক্যাশ"), Icons.Filled.Storage, outlined = true) {
            Perms.open(ctx, Intent(android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
        }
    }
    if (ask) AlertDialog(onDismissRequest = { ask = false },
        title = { Text(L.t("Delete selected junk?", "বাছাই করা জাঙ্ক মুছবেন?")) },
        text = {
            Text(
                L.t("$count items (${fmtBytes(total)}) will be permanently deleted.", "$count টি আইটেম (${fmtBytes(total)}) চিরতরে মুছে যাবে।") +
                    (if (review) "\n\n" + L.t("Some selected groups (duplicates, large files, installers or leftovers) may be things you want. Check their file lists first.",
                        "বাছাইয়ের কিছু অংশ (একই ফাইলের কপি, বড় ফাইল, ইনস্টলার বা ফেলে যাওয়া ফাইল) আপনার দরকারি হতে পারে। আগে ফাইলের তালিকা দেখে নিন।") else "")
            )
        },
        confirmButton = {
            TextButton({
                ask = false; busy = true
                val toClean = chosen
                scope.launch(Dispatchers.IO) {
                    val r = JunkCleaner.clean(toClean)
                    withContext(Dispatchers.Main) {
                        msg = L.t("Freed ${fmtBytes(r.freed)} • ${r.deleted} items deleted", "${fmtBytes(r.freed)} জায়গা খালি হয়েছে • ${r.deleted} টি মুছেছে") +
                            (if (r.failed > 0) L.t(" • ${r.failed} could not be deleted", " • ${r.failed} টি মোছা যায়নি") else "")
                        items = emptyList(); scanned = false; busy = false
                    }
                }
            }) { Text(L.t("Delete", "মুছুন")) }
        },
        dismissButton = { TextButton({ ask = false }) { Text(L.t("Cancel", "বাতিল")) } })
}

@Composable
fun BreachScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var r1 by remember { mutableStateOf("") }
    var r2 by remember { mutableStateOf("") }
    Page {
        GCard {
            H(L.t("Has my email leaked?", "আমার ইমেইল ফাঁস হয়েছে কি?"))
            OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Email") })
            BigButton(L.t("Check email", "ইমেইল যাচাই"), Icons.Filled.Email, enabled = email.contains("@")) {
                scope.launch(Dispatchers.IO) { r1 = L.t("Checking…", "যাচাই চলছে…"); r1 = Breach.email(ctx, email.trim()) }
            }
            if (r1.isNotEmpty()) Text(r1)
        }
        GCard {
            H(L.t("Has my password leaked?", "আমার পাসওয়ার্ড ফাঁস হয়েছে কি?"))
            Hint(L.t("Your password is never sent or saved. Only the first 5 characters of its hash leave the phone.", "পাসওয়ার্ড কোথাও পাঠানো বা জমা হয় না। শুধু হ্যাশের প্রথম ৫ অক্ষর যায়।"))
            OutlinedTextField(pw, { pw = it }, Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(L.t("Password", "পাসওয়ার্ড")) })
            BigButton(L.t("Check password", "পাসওয়ার্ড যাচাই"), Icons.Filled.Lock, enabled = pw.isNotEmpty()) {
                scope.launch(Dispatchers.IO) { r2 = L.t("Checking…", "যাচাই চলছে…"); r2 = Breach.password(pw) }
            }
            if (r2.isNotEmpty()) Text(r2)
        }
    }
}

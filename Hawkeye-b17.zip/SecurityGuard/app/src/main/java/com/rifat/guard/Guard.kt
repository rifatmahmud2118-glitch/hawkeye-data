package com.rifat.guard

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.TelephonyManager
import kotlin.math.abs
import kotlin.math.sqrt

// চুরি-বিরোধী স্বয়ংক্রিয় পাহারার নিয়ম
object Guard {
    fun armed(ctx: Context) = Store.on(ctx, "g_armed", false)
    fun lost(ctx: Context) = Store.on(ctx, "g_lost", false)

    private fun gate(ctx: Context, key: String, ms: Long): Boolean {
        val now = System.currentTimeMillis()
        if (now - Store.long(ctx, key, 0L) < ms) return false
        Store.put(ctx, key, now.toString())
        return true
    }

    fun alertOwner(ctx: Context, text: String, withLocation: Boolean = true) {
        Alerts.notify(ctx, "Hawkeye anti-theft", text)
        val n = Theft.num(ctx)
        if (n.isNotBlank()) {
            Theft.reply(ctx, n, "Hawkeye ALERT: $text")
            if (withLocation) Theft.locateQuiet(ctx, n)
        }
    }

    fun battLow(ctx: Context) {
        if (!Theft.enabled(ctx) || !Store.on(ctx, "g_battlow", true)) return
        if (!gate(ctx, "g_t_batt", 3 * 3600000L)) return
        val n = Theft.num(ctx)
        if (n.isNotBlank()) {
            Theft.reply(ctx, n, "Hawkeye: battery is very low, the phone may switch off soon.")
            Theft.locateQuiet(ctx, n)
        }
    }

    fun chargerOff(ctx: Context) {
        if (!Theft.enabled(ctx) || !armed(ctx) || !Store.on(ctx, "g_charger", true)) return
        if (!gate(ctx, "g_t_chg", 60000L)) return
        Theft.ring(ctx)
        Theft.flash(ctx, 20)
        alertOwner(ctx, "the charger was unplugged while the guard is armed.")
    }

    fun motion(ctx: Context) {
        if (!Theft.enabled(ctx) || !armed(ctx) || !Store.on(ctx, "g_motion", true)) return
        if (!gate(ctx, "g_t_move", 120000L)) return
        Theft.ring(ctx)
        alertOwner(ctx, "the phone is being moved while the guard is armed.")
    }

    fun airplane(ctx: Context) {
        if (!Theft.enabled(ctx) || !(armed(ctx) || lost(ctx)) || !Store.on(ctx, "g_air", true)) return
        val on = android.provider.Settings.Global.getInt(ctx.contentResolver, android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        if (on && gate(ctx, "g_t_air", 60000L)) Theft.ring(ctx)
    }

    fun wrongPass(ctx: Context) {
        if (!Theft.enabled(ctx)) return
        val lim = Store.long(ctx, "g_wrong", 3L).toInt()
        if (lim <= 0) return
        val c = Store.long(ctx, "g_fail", 0L).toInt() + 1
        Store.put(ctx, "g_fail", c.toString())
        if (c >= lim && gate(ctx, "g_t_wrong", 300000L)) {
            Thread { try { alertOwner(ctx, "$c wrong unlock attempts on your phone.") } catch (e: Exception) { } }.start()
        }
    }

    fun adminOff(ctx: Context) {
        if (!Theft.enabled(ctx)) return
        Thread { try { alertOwner(ctx, "Device admin was turned off on your phone.") } catch (e: Exception) { } }.start()
    }

    private fun simAbsent(ctx: Context) {
        if (!Store.on(ctx, "g_simabs", true) || !(armed(ctx) || lost(ctx))) return
        val tm = ctx.getSystemService(TelephonyManager::class.java)
        if (tm.simState == TelephonyManager.SIM_STATE_ABSENT && gate(ctx, "g_t_sim", 1800000L)) {
            Theft.ring(ctx)
            Alerts.notify(ctx, "Hawkeye anti-theft", "The SIM card was removed while the guard is armed.")
        }
    }

    private fun homeCheck(ctx: Context) {
        if (!Store.on(ctx, "g_home_on", false) || !armed(ctx)) return
        val la = Store.get(ctx, "g_home_lat").toDoubleOrNull() ?: return
        val lo = Store.get(ctx, "g_home_lon").toDoubleOrNull() ?: return
        val r = Store.long(ctx, "g_home_r", 300L).toFloat()
        val now = System.currentTimeMillis()
        if (now < Store.long(ctx, "g_geo_next", 0L)) return
        Store.put(ctx, "g_geo_next", (now + 300000L).toString())
        val l = Theft.bestLocation(ctx) ?: return
        val res = FloatArray(1)
        Location.distanceBetween(la, lo, l.latitude, l.longitude, res)
        if (res[0] > r && gate(ctx, "g_t_geo", 1800000L)) alertOwner(ctx, "the phone left the home zone (${res[0].toInt()} m away).")
    }

    private fun trackTick(ctx: Context) {
        val now = System.currentTimeMillis()
        if (Store.long(ctx, "g_track_until", 0L) <= now) return
        if (now < Store.long(ctx, "g_track_next", 0L)) return
        Store.put(ctx, "g_track_next", (now + 600000L).toString())
        val to = Store.get(ctx, "g_track_to").ifBlank { Theft.num(ctx) }
        if (to.isNotBlank()) Theft.locateQuiet(ctx, to)
    }

    fun poll(ctx: Context) {
        if (!Theft.enabled(ctx)) return
        simAbsent(ctx)
        trackTick(ctx)
        homeCheck(ctx)
    }
}

// চুরি-বিরোধী পাহারার সার্ভিস: চার্জার, ব্যাটারি, এয়ারপ্লেন, নড়াচড়া ও সিম দেখে
class GuardService : Service(), SensorEventListener {
    companion object {
        fun start(ctx: Context) {
            try { ctx.applicationContext.startForegroundService(Intent(ctx.applicationContext, GuardService::class.java)) } catch (e: Exception) { }
        }
        fun stop(ctx: Context) {
            try { ctx.applicationContext.stopService(Intent(ctx.applicationContext, GuardService::class.java)) } catch (e: Exception) { }
        }
        fun refresh(ctx: Context) { if (Theft.enabled(ctx)) start(ctx) else stop(ctx) }
    }

    private val h = Handler(Looper.getMainLooper())
    private var recv: BroadcastReceiver? = null
    private var started = false
    private var sensing = false
    private var hits = 0

    private val poll = object : Runnable {
        override fun run() {
            val c = applicationContext
            Thread { try { Guard.poll(c) } catch (e: Exception) { } }.start()
            syncSensor()
            h.postDelayed(this, 30000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Alerts.init(this)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, Alerts.CH_SHIELD)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle(L.t("Anti-theft guard is on", "চুরি-বিরোধী পাহারা চালু"))
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(11, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(11, n)
        if (!started) { started = true; register(); h.post(poll) } else syncSensor()
        return START_STICKY
    }

    private fun register() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        }
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val app = c.applicationContext
                val act = i.action
                Thread {
                    try {
                        when (act) {
                            Intent.ACTION_BATTERY_LOW -> Guard.battLow(app)
                            Intent.ACTION_POWER_DISCONNECTED -> Guard.chargerOff(app)
                            Intent.ACTION_AIRPLANE_MODE_CHANGED -> Guard.airplane(app)
                        }
                    } catch (e: Exception) { }
                }.start()
            }
        }
        recv = r
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_EXPORTED) else registerReceiver(r, f)
    }

    private fun syncSensor() {
        val want = Theft.enabled(this) && Guard.armed(this) && Store.on(this, "g_motion", true)
        val sm = getSystemService(SensorManager::class.java)
        if (want && !sensing) {
            val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (s != null) { sm.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL); sensing = true; hits = 0 }
        } else if (!want && sensing) {
            sm.unregisterListener(this)
            sensing = false
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (System.currentTimeMillis() - Store.long(this, "g_armed_at", 0L) < 15000L) return
        val mag = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        if (abs(mag - 9.81f) > 2.5f) hits++ else if (hits > 0) hits--
        if (hits >= 4) {
            hits = 0
            val app = applicationContext
            Thread { try { Guard.motion(app) } catch (x: Exception) { } }.start()
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) { }

    override fun onDestroy() {
        h.removeCallbacks(poll)
        if (sensing) { try { getSystemService(SensorManager::class.java).unregisterListener(this) } catch (e: Exception) { } }
        recv?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        super.onDestroy()
    }
}

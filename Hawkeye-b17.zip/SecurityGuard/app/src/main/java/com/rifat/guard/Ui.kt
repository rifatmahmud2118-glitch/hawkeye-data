package com.rifat.guard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

enum class Screen { HOME, FULL, REPORT, SHIELDS, CALLS, LINKS, FILES, APPS, JUNK, BREACH, SCHEDULE, UPDATES, SETTINGS, THEFT, WIFI, VPN }

val LocalDark = compositionLocalOf { true }
val LocalCardColor = compositionLocalOf { Color(0xFF2E2347) }
val LocalHeaderTint = compositionLocalOf { Color(0xFF120C1F) }

class UiState(private val ctx: Context) {
    var dark by mutableStateOf(Store.get(ctx, "dark", "1") == "1")
    var scale by mutableStateOf(Store.get(ctx, "scale", "1.0").toFloatOrNull() ?: 1f)
    var bgVer by mutableStateOf(Store.get(ctx, "bg_ver", "0"))

    var hue by mutableStateOf(Store.get(ctx, "th_h", "265").toFloatOrNull() ?: 265f)
    var sat by mutableStateOf(Store.get(ctx, "th_s", "0.5").toFloatOrNull() ?: 0.5f)
    var shade by mutableStateOf(Store.get(ctx, "th_b", "0.35").toFloatOrNull() ?: 0.35f)

    fun applyTheme(h: Float, s: Float, b: Float) {
        hue = h; sat = s; shade = b
        Store.put(ctx, "th_h", h.toString()); Store.put(ctx, "th_s", s.toString()); Store.put(ctx, "th_b", b.toString())
    }

    init { L.bn = Store.get(ctx, "lang", "en") == "bn" }

    fun applyDark(v: Boolean) { dark = v; Store.put(ctx, "dark", if (v) "1" else "0") }
    fun applyScale(v: Float) { scale = v; Store.put(ctx, "scale", v.toString()) }
    fun setBg(v: String) { bgVer = v; Store.put(ctx, "bg_ver", v) }
    fun setLang(bn: Boolean) { L.bn = bn; Store.put(ctx, "lang", if (bn) "bn" else "en") }
}

// গুরুত্ব অনুযায়ী লেখার আকার: শিরোনাম বড়, মূল লেখা মাঝারি, ছোট নোট ছোট
private fun typo(f: FontFamily): Typography {
    fun s(size: Int, line: Int) = TextStyle(fontFamily = f, fontSize = size.sp, lineHeight = line.sp)
    return Typography(
        displayLarge = s(40, 48), displayMedium = s(34, 42), displaySmall = s(28, 36),
        headlineLarge = s(30, 38), headlineMedium = s(26, 34), headlineSmall = s(22, 30),
        titleLarge = s(21, 28), titleMedium = s(17, 24), titleSmall = s(15, 22),
        bodyLarge = s(15, 22), bodyMedium = s(14, 20), bodySmall = s(12, 17),
        labelLarge = s(14, 20), labelMedium = s(12, 16), labelSmall = s(11, 15)
    )
}

@Composable
fun AppTheme(ui: UiState, content: @Composable () -> Unit) {
    val dark = ui.dark
    val h = ui.hue; val s = ui.sat; val b = ui.shade
    fun c(sat: Float, v: Float) = Color.hsv(h, sat.coerceIn(0f, 1f), v.coerceIn(0f, 1f))
    val scheme = if (dark) {
        val v = 0.06f + 0.24f * b
        darkColorScheme(
            primary = c(s * 0.55f, 0.95f), onPrimary = c(s * 0.9f, 0.10f),
            secondary = c(s * 0.5f, 0.85f), onSecondary = c(s * 0.9f, 0.10f),
            background = c(s * 0.9f, v), onBackground = c(0.06f, 0.95f),
            surface = c(s * 0.85f, v + 0.04f), onSurface = c(0.06f, 0.95f),
            surfaceVariant = c(s * 0.8f, v + 0.10f), onSurfaceVariant = c(minOf(0.2f, s * 0.3f), 0.78f),
            outline = c(s * 0.5f, 0.65f)
        )
    } else lightColorScheme(
        primary = c(0.45f + s * 0.4f, 0.55f), onPrimary = Color.White,
        secondary = c(0.4f + s * 0.3f, 0.65f), onSecondary = Color.White,
        background = c(s * 0.12f, 0.90f + 0.09f * b), onBackground = c(0.5f, 0.15f),
        surface = c(s * 0.08f, 0.97f), onSurface = c(0.5f, 0.15f),
        surfaceVariant = c(s * 0.22f, 0.91f), onSurfaceVariant = c(0.25f, 0.36f),
        outline = c(0.3f, 0.6f)
    )
    val font = FontFamily(Font(R.font.bcc_purno_black))
    val d = LocalDensity.current
    MaterialTheme(colorScheme = scheme, typography = typo(font)) {
        CompositionLocalProvider(
            LocalDark provides dark,
            LocalHeaderTint provides c(s * 0.9f, 0.10f),
            LocalDensity provides Density(d.density, d.fontScale * ui.scale)
        ) { content() }
    }
}

@Composable
fun riskColor(r: Risk): Color {
    val d = LocalDark.current
    return when (r) {
        Risk.HIGH -> if (d) Color(0xFFFF6B6B) else Color(0xFFC62828)
        Risk.MEDIUM -> if (d) Color(0xFFFFB74D) else Color(0xFFE65100)
        Risk.LOW -> if (d) Color(0xFF81C784) else Color(0xFF2E7D32)
    }
}

@Composable
fun GCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = LocalCardColor.current)
    ) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp), content = content) }
}

@Composable fun H(text: String) = Text(text, style = MaterialTheme.typography.titleMedium)
@Composable fun Hint(text: String) = Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
@Composable fun SectionLabel(text: String) = Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 10.dp, start = 4.dp))

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)

@Composable
fun SettingRow(icon: ImageVector, title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (sub.isNotEmpty()) Hint(sub)
        }
        Switch(checked, onChange)
    }
}

@Composable
fun StoreToggle(icon: ImageVector, title: String, sub: String, key: String, def: Boolean = true, onChange: (Boolean) -> Unit = {}) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var v by remember { mutableStateOf(Store.on(ctx, key, def)) }
    SettingRow(icon, title, sub, v) { v = it; Store.setOn(ctx, key, it); onChange(it) }
}

@Composable
fun ActionRow(icon: ImageVector, title: String, sub: String = "", onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (sub.isNotEmpty()) Hint(sub)
        }
    }
}

@Composable
fun BigButton(text: String, icon: ImageVector? = null, enabled: Boolean = true, modifier: Modifier = Modifier.fillMaxWidth(), outlined: Boolean = false, onClick: () -> Unit) {
    val body: @Composable () -> Unit = {
        if (icon != null) { Icon(icon, null, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
    if (outlined) OutlinedButton(onClick, modifier, enabled = enabled) { body() }
    else Button(onClick, modifier, enabled = enabled) { body() }
}

@Composable
fun ChoiceRow(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (k, label) ->
            val m = Modifier.weight(1f)
            if (k == selected) Button({ onSelect(k) }, m, contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)) { Text(label, style = MaterialTheme.typography.labelMedium) }
            else OutlinedButton({ onSelect(k) }, m, contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)) { Text(label, style = MaterialTheme.typography.labelMedium) }
        }
    }
}

@Composable
fun StatBox(label: String, value: String, color: Color = MaterialTheme.colorScheme.onSurface, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, color = color)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun VtLine(r: VtResult?) {
    if (r != null) Text(r.text(), style = MaterialTheme.typography.bodySmall, color = riskColor(r.level))
}

@Composable
fun HeaderBanner(title: String, subtitle: String, tall: Boolean, onMenu: () -> Unit, onRefresh: () -> Unit, onHome: (() -> Unit)?) {
    val tint = LocalHeaderTint.current
    Box(Modifier.fillMaxWidth().height(if (tall) 214.dp else 112.dp)) {
        Image(painterResource(R.drawable.header), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.45f), tint.copy(alpha = 0.93f)))))
        if (tall) Image(painterResource(R.drawable.logo), null,
            Modifier.align(Alignment.TopCenter).padding(top = 20.dp).size(88.dp).clip(CircleShape).border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape),
            contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onMenu) { Icon(Icons.Filled.Menu, null, tint = Color.White) }
            Spacer(Modifier.weight(1f))
            IconButton(onRefresh) { Icon(Icons.Filled.Refresh, null, tint = Color.White) }
            if (onHome != null) IconButton(onHome, Modifier.size(48.dp).background(Color(0x33FFFFFF), CircleShape)) { Icon(Icons.Filled.Home, null, tint = Color.White) }
        }
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text(title, style = if (tall) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.headlineSmall, color = Color.White)
            if (subtitle.isNotEmpty()) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFD9CCF0))
        }
    }
}

// সেটিংস থেকে ফিরে এলে অবস্থা আবার পড়ার জন্য
@Composable
fun resumeTick(): Int {
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var tick by remember { mutableStateOf(0) }
    DisposableEffect(owner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e -> if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

fun fmtBytes(n: Long): String = when {
    n >= 1L shl 30 -> String.format("%.1f GB", n / 1073741824.0)
    n >= 1L shl 20 -> String.format("%.1f MB", n / 1048576.0)
    n >= 1L shl 10 -> String.format("%.0f KB", n / 1024.0)
    else -> "$n B"
}

fun fmtDate(t: Long): String = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(t))

fun loadBg(ctx: Context): ImageBitmap? = try {
    BitmapFactory.decodeFile(File(ctx.filesDir, "bg.jpg").path)?.asImageBitmap()
} catch (e: Exception) { null }

fun saveBg(ctx: Context, uri: Uri): Boolean {
    try {
        val o1 = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o1) }
        var sample = 1
        while (o1.outWidth / sample > 1600 || o1.outHeight / sample > 1600) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return false
        File(ctx.filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        return true
    } catch (e: Exception) { return false }
}

// পাসওয়ার্ড সুরক্ষা
object Pass {
    private fun hash(salt: String, pin: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
    fun enabled(ctx: Context) = Store.get(ctx, "pw_hash").isNotEmpty()
    fun set(ctx: Context, pin: String) {
        val salt = java.util.UUID.randomUUID().toString()
        Store.put(ctx, "pw_salt", salt); Store.put(ctx, "pw_hash", hash(salt, pin))
    }
    fun check(ctx: Context, pin: String) = hash(Store.get(ctx, "pw_salt"), pin) == Store.get(ctx, "pw_hash")
    fun clear(ctx: Context) { Store.put(ctx, "pw_hash", ""); Store.put(ctx, "pw_salt", "") }
}

package com.rifat.guard

import java.io.File
import java.util.zip.ZipFile

class StaticResult(val score: Int, val reasons: List<String>)

// অ্যাপের কোড (dex) ভেতর থেকে পড়ে সন্দেহজনক চিহ্ন খোঁজে। এটা নতুন ও অচেনা ম্যালওয়্যার ধরার জন্য।
// হ্যাশ তালিকায় না থাকলেও কোডের আচরণ দেখে ঝুঁকি আন্দাজ করে (নিশ্চিত রায় নয়, শুধু ঝুঁকির স্কোর)
object StaticScan {
    private class Sig(val grp: String, val needle: ByteArray, val w: Int, val en: String, val bn: String)

    private fun sig(grp: String, s: String, w: Int, en: String, bn: String) =
        Sig(grp, s.toByteArray(Charsets.UTF_8), w, en, bn)

    private val sigs = listOf(
        sig("mem", "InMemoryDexClassLoader", 15, "Loads hidden code straight from memory", "মেমরি থেকে লুকানো কোড চালায়"),
        sig("dex", "Ldalvik/system/DexClassLoader;", 10, "Loads extra code while running", "চলার সময় বাইরের কোড লোড করে"),
        sig("sms", "sendTextMessage", 10, "Contains code that sends SMS", "SMS পাঠানোর কোড আছে"),
        sig("sms", "sendMultipartTextMessage", 10, "Contains code that sends SMS", "SMS পাঠানোর কোড আছে"),
        sig("tap", "dispatchGesture", 10, "Can tap the screen by itself", "নিজে নিজে স্ক্রিনে ট্যাপ করার কোড আছে"),
        sig("lock", "lockNow", 10, "Can lock the screen (locker or ransomware trick)", "স্ক্রিন লক করার কোড আছে (লকার বা র‍্যানসমওয়্যার কৌশল)"),
        sig("wipe", "wipeData", 15, "Can erase the whole phone", "পুরো ফোন মুছে ফেলার কোড আছে"),
        sig("pwd", "resetPassword", 15, "Can change the screen lock password", "স্ক্রিন লকের পাসওয়ার্ড বদলানোর কোড আছে"),
        sig("root", "/system/xbin/su", 10, "Looks for root access", "রুট অ্যাক্সেস খোঁজে"),
        sig("root", "Superuser.apk", 10, "Looks for root access", "রুট অ্যাক্সেস খোঁজে"),
        sig("miner", "stratum+tcp://", 40, "Contains a crypto-miner address", "ক্রিপ্টো মাইনারের ঠিকানা আছে"),
        sig("miner", "xmrig", 40, "Contains a crypto-miner address", "ক্রিপ্টো মাইনারের ঠিকানা আছে"),
        sig("miner", "coinhive", 40, "Contains a crypto-miner address", "ক্রিপ্টো মাইনারের ঠিকানা আছে"),
        sig("miner", "cryptonight", 30, "Contains a crypto-miner address", "ক্রিপ্টো মাইনারের ঠিকানা আছে"),
        sig("tg", "api.telegram.org/bot", 20, "Sends data to a Telegram bot (data-stealer trick)", "টেলিগ্রাম বটে তথ্য পাঠায় (তথ্য চুরির কৌশল)"),
        sig("dc", "discord.com/api/webhooks", 20, "Sends data to a Discord webhook (data-stealer trick)", "Discord ওয়েবহুকে তথ্য পাঠায় (তথ্য চুরির কৌশল)"),
        sig("inst", "application/vnd.android.package-archive", 5, "Can install other apps", "অন্য অ্যাপ ইনস্টলের কোড আছে")
    )

    private val byFirst: Array<List<Sig>> = Array(256) { b -> sigs.filter { (it.needle[0].toInt() and 0xff) == b } }

    private val dexName = Regex("^classes\\d*\\.dex$")
    private const val MAX_DEX = 32L * 1024 * 1024
    private const val MAX_APK = 200L * 1024 * 1024

    // একসাথে অনেক অ্যাপ পড়লে মেমরি ভরে যেতে পারে, তাই একবারে একটাই পড়া হয়
    fun analyze(apk: File): StaticResult = synchronized(this) { analyzeInner(apk) }

    private fun analyzeInner(apk: File): StaticResult {
        try {
            if (!apk.exists() || apk.length() > MAX_APK) return StaticResult(0, emptyList())
            val hit = LinkedHashMap<String, Sig>()
            var hidden = false
            ZipFile(apk).use { z ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    val n = e.name
                    if (dexName.matches(n)) {
                        if (e.size in 1..MAX_DEX) {
                            val data = z.getInputStream(e).use { it.readBytes() }
                            scan(data, hit)
                        }
                    } else if (!hidden && (n.startsWith("assets/") || n.startsWith("res/raw/")) && e.size > 8192) {
                        val low = n.lowercase()
                        if (low.endsWith(".apk") || low.endsWith(".dex") || low.endsWith(".jar")) hidden = true
                        else {
                            val head = ByteArray(4)
                            val r = z.getInputStream(e).use { it.read(head) }
                            if (r == 4 && head[0] == 'd'.code.toByte() && head[1] == 'e'.code.toByte() && head[2] == 'x'.code.toByte() && head[3] == 10.toByte()) hidden = true
                        }
                    }
                }
            }
            var score = 0
            val reasons = ArrayList<String>()
            for (s in hit.values) { score += s.w; reasons.add(L.t(s.en, s.bn)) }
            if (hidden) { score += 25; reasons.add(L.t("Hides another app or code inside its own files", "নিজের ফাইলের ভেতরে আরেকটা অ্যাপ বা কোড লুকিয়ে রেখেছে")) }
            return StaticResult(minOf(score, 60), reasons)
        } catch (e: Throwable) {
            return StaticResult(0, emptyList())
        }
    }

    // একবার পড়ে সব চিহ্ন খোঁজা
    private fun scan(h: ByteArray, hit: MutableMap<String, Sig>) {
        var i = 0
        val n = h.size
        while (i < n) {
            val cands = byFirst[h[i].toInt() and 0xff]
            if (cands.isNotEmpty()) {
                for (s in cands) {
                    if (hit.containsKey(s.grp)) continue
                    val nd = s.needle
                    if (i + nd.size > n) continue
                    var j = 1
                    while (j < nd.size && h[i + j] == nd[j]) j++
                    if (j == nd.size) hit[s.grp] = s
                }
            }
            i++
        }
    }
}

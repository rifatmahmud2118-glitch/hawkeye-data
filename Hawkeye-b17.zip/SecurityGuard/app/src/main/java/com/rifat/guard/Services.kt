package com.rifat.guard

import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telephony.TelephonyManager
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i)
        val sender = msgs.firstOrNull()?.originatingAddress ?: ""
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        if (Theft.isCommand(ctx, body)) {
            val pr0 = goAsync()
            val app0 = ctx.applicationContext
            Thread { try { Theft.run(app0, sender, body) } finally { pr0.finish() } }.start()
            return
        }
        if (!Store.on(ctx, "sms_on", true)) return
        val pr = goAsync()
        val app = ctx.applicationContext
        Thread { try { Inspector.inspect(app, "SMS ($sender)", body) } finally { pr.finish() } }.start()
    }
}

// মেসেজ অ্যাপ (Message Shield) ও ইমেইল অ্যাপ (Email Shield)-এর নোটিফিকেশন
class NotifListener : NotificationListenerService() {
    private val msgApps = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "com.facebook.orca", "com.facebook.mlite",
        "org.telegram.messenger", "org.telegram.messenger.web", "com.imo.android.imoim"
    )
    private val mailApps = setOf(
        "com.google.android.gm", "com.microsoft.office.outlook", "com.yahoo.mobile.client.android.mail",
        "com.samsung.android.email.provider", "ch.protonmail.android", "com.fsck.k9"
    )
    private val seen = LinkedHashSet<String>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        val isMail = pkg in mailApps
        if (!isMail && pkg !in msgApps) return
        if (!Store.on(this, if (isMail) "email_on" else "msg_on", true)) return
        val ex = sbn.notification.extras
        val a = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val b = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""
        val text = if (b.length > a.length) b else a
        if (text.isBlank() || !seen.add(sbn.key + text.hashCode())) return
        if (seen.size > 200) seen.remove(seen.first())
        val ctx = applicationContext
        val label = if (isMail) L.t("Email Shield", "ইমেইল শিল্ড") else L.t("Message Shield", "মেসেজ শিল্ড")
        Thread { Inspector.inspect(ctx, label, text) }.start()
    }
}

object CallRisk {
    fun spamList(ctx: Context): List<String> = Store.get(ctx, "spam_list").split("\n").filter { it.isNotBlank() }
    private fun norm(n: String) = n.filter { it.isDigit() || it == '+' }
    fun isForeign(n: String): Boolean = (n.startsWith("+") && !n.startsWith("+880")) || (n.startsWith("00") && !n.startsWith("00880"))

    fun check(ctx: Context, num: String): List<String> {
        val n = norm(num)
        val r = mutableListOf<String>()
        if (n.length < 4) return r
        val tail = n.takeLast(10)
        if (spamList(ctx).any { norm(it).takeLast(10) == tail }) r += L.t("This number is in your spam list", "নম্বরটি আপনার স্প্যাম তালিকায় আছে")
        if (isForeign(n)) r += L.t("Foreign number (common in missed-call and prize scams)", "বিদেশি নম্বর (মিসড কল ও পুরস্কারের ফাঁদে দেখা যায়)")
        return r
    }

    private val last = HashMap<String, Long>()

    @Synchronized
    fun alertIfRisky(ctx: Context, num: String) {
        val now = System.currentTimeMillis()
        val k = norm(num)
        if ((last[k] ?: 0L) + 15000 > now) return
        val r = check(ctx, num)
        if (r.isEmpty()) return
        last[k] = now
        Alerts.notify(ctx, L.t("Suspicious call", "সন্দেহজনক কল"), num + "\n" + r.joinToString("\n• ", "• ") +
            L.t("\nNever share an OTP or PIN on a call.", "\nকলে কখনও OTP বা পিন দেবেন না।"))
    }
}

// ডিফল্ট কল অ্যাপ না করেও: ফোন স্টেটের মাধ্যমে আসা নম্বর যাচাই (READ_PHONE_STATE + READ_CALL_LOG লাগে)
class PhoneStateReceiver : BroadcastReceiver() {
    companion object { var lastNumber = ""; var ringAt = 0L; var answered = false }

    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (!Store.on(ctx, "call_on", true)) return
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE)
        @Suppress("DEPRECATION")
        val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (!num.isNullOrBlank()) {
                    lastNumber = num; ringAt = System.currentTimeMillis(); answered = false
                    CallRisk.alertIfRisky(ctx.applicationContext, num)
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> answered = true
            TelephonyManager.EXTRA_STATE_IDLE -> {
                if (!answered && lastNumber.isNotBlank() && System.currentTimeMillis() - ringAt < 9000 && CallRisk.isForeign(lastNumber)) {
                    Alerts.notify(ctx.applicationContext, L.t("Missed-call trap?", "মিসড কল ফাঁদ?"),
                        lastNumber + L.t("\nA foreign number rang once and hung up. Do NOT call back, it can cost you money.", "\nবিদেশি নম্বর একবার রিং দিয়ে কেটে দিয়েছে। ফেরত কল করবেন না, বিল কাটতে পারে।"))
                }
                lastNumber = ""
            }
        }
    }
}

// ঐচ্ছিক, আরও জোরালো: কল স্ক্রিনিং ভূমিকা দিলে কাজ করে
class CallScreener : CallScreeningService() {
    override fun onScreenCall(d: Call.Details) {
        respondToCall(d, CallResponse.Builder().build())
        if (!Store.on(this, "call_on", true)) return
        if (d.callDirection != Call.Details.DIRECTION_INCOMING) return
        val num = d.handle?.schemeSpecificPart ?: return
        CallRisk.alertIfRisky(applicationContext, num)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        if (Store.on(ctx, "shield_on", false) && Store.on(ctx, "boot_on", true)) {
            try { ctx.startForegroundService(Intent(ctx, ShieldService::class.java)) } catch (e: Exception) { }
        }
        val app = ctx.applicationContext
        if (Theft.enabled(app)) GuardService.start(app)
        Thread { try { Theft.checkSim(app) } catch (e: Exception) { } }.start()
        try { if (Store.on(ctx, "vpn_on", false) && android.net.VpnService.prepare(ctx) == null) DnsVpnService.start(app) } catch (e: Exception) { }
    }
}

class UpdateWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val c = applicationContext
        try { Updater.autoDump(c) } catch (e: Exception) { }
        try { SigDb.update(c) } catch (e: Exception) { }
        try { BlockList.update(c) } catch (e: Exception) { }
        return Result.success()
    }
}

class TickWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val c = applicationContext
        try { Scheduler.runIfDue(c) } catch (e: Exception) { }
        try { Watchdog.check(c) } catch (e: Exception) { }
        // সিস্টেম সার্ভিস মেরে ফেললে আবার চালু করা
        try {
            if (Store.on(c, "shield_on", false) && !ShieldService.alive) c.startForegroundService(Intent(c, ShieldService::class.java))
        } catch (e: Exception) { }
        try {
            if (Store.on(c, "vpn_on", false) && !VpnState.running && android.net.VpnService.prepare(c) == null) DnsVpnService.start(c)
        } catch (e: Exception) { }
        return Result.success()
    }
}

object Updater {
    // key বসানো আছে অথচ তালিকা প্রায় ফাঁকা (নতুন ইনস্টল): Wi-Fi থাকলে নিজে থেকে পুরো ইতিহাস নামানো
    fun autoDump(ctx: Context) {
        try {
            val c = ctx.applicationContext
            if (Store.get(c, "abuse_key").isBlank()) return
            if (SigDb.count(c) >= 5000) return
            if (DumpState.running || ScanState.running) return
            val last = Store.long(c, "auto_dump_try", 0L)
            if (System.currentTimeMillis() - last < 6 * 3600 * 1000L) return
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return
            if (!caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) return
            Store.put(c, "auto_dump_try", System.currentTimeMillis().toString())
            DumpState.running = true; DumpState.cancel = false; DumpState.progress = 0f
            DumpState.status = L.t("Starting…", "শুরু হচ্ছে…")
            c.startForegroundService(Intent(c, ScanService::class.java).putExtra("type", "dump"))
        } catch (e: Exception) { DumpState.running = false }
    }

    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        if (!Store.on(ctx, "auto_update", true)) { wm.cancelUniqueWork("sig_update"); return }
        val hours = Store.long(ctx, "upd_hours", 24L)
        wm.enqueueUniquePeriodicWork(
            "sig_update", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<UpdateWorker>(hours, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        )
    }

    fun ensureTick(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "tick", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<TickWorker>(15, TimeUnit.MINUTES).build()
        )
    }
}

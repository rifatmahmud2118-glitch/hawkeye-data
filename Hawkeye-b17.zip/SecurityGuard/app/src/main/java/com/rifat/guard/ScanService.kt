package com.rifat.guard

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

// অ্যাপ বন্ধ করলেও স্ক্যান বা ডাউনলোড চলতে থাকে, নোটিফিকেশনে প্রোগ্রেস দেখায়
class ScanService : Service() {
    private var job: Job? = null
    private val nid = 9001

    override fun onBind(intent: Intent?): IBinder? = null

    private fun title(type: String) = when (type) {
        "full" -> L.t("Full System Scan", "ফুল সিস্টেম স্ক্যান")
        "dump" -> L.t("Downloading malware history", "ভাইরাসের ইতিহাস নামানো হচ্ছে")
        else -> L.t("Quick Scan", "কুইক স্ক্যান")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "cancel") { ScanState.cancel = true; DumpState.cancel = true; return START_NOT_STICKY }
        val type = intent?.getStringExtra("type") ?: "quick"
        val dump = type == "dump"
        if (job?.isActive == true) { if (dump) DumpState.running = false; return START_NOT_STICKY }
        val n = Alerts.progress(this, title(type), L.t("Starting…", "শুরু হচ্ছে…"), 0, true)
        if (Build.VERSION.SDK_INT >= 34) startForeground(nid, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(nid, n)
        if (dump) { DumpState.running = true; DumpState.cancel = false } else { ScanState.running = true; ScanState.type = type }
        val wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "guard:scan")
        wl.acquire(90 * 60 * 1000L)
        val nm = getSystemService(NotificationManager::class.java)
        val ctx: Context = applicationContext
        job = CoroutineScope(Dispatchers.Default).launch {
            val ticker = launch {
                while (isActive) {
                    delay(1000)
                    val txt = if (dump) DumpState.status else ScanState.stage + if (ScanState.detail.isNotEmpty()) " • " + ScanState.detail else ""
                    val pct = ((if (dump) DumpState.progress else ScanState.progress) * 100).toInt()
                    nm.notify(nid, Alerts.progress(ctx, title(type), txt, pct, false))
                }
            }
            if (dump) {
                try { DumpState.status = SigDb.fullDump(ctx) } catch (e: Exception) { DumpState.status = "Error: " + e.message }
            } else {
                try { Scanner.run(ctx, type) } catch (e: Exception) { ScanState.stage = "Error: " + e.message }
            }
            ticker.cancel()
            if (wl.isHeld) wl.release()
            stopForeground(STOP_FOREGROUND_REMOVE)
            if (dump) {
                val cancelled = DumpState.cancel
                DumpState.running = false
                if (!cancelled) Alerts.done(ctx, L.t("Download finished", "নামানো শেষ"), DumpState.status)
            } else {
                val cancelled = ScanState.cancel
                ScanState.running = false
                if (!cancelled) {
                    val r = ScanState.result
                    if (r != null) Alerts.done(ctx, L.t("Scan complete", "স্ক্যান শেষ"),
                        L.t("Score ${r.score}/100 • ${r.threats} threats • ${r.suspicious} suspicious • ${r.files} files, ${r.apps} apps",
                            "স্কোর ${r.score}/১০০ • ${r.threats}টি ভাইরাস • ${r.suspicious}টি সন্দেহজনক • ${r.files}টি ফাইল, ${r.apps}টি অ্যাপ"))
                } else {
                    ScanState.stage = L.t("Cancelled", "বাতিল হয়েছে")
                }
            }
            stopSelf()
        }
        return START_NOT_STICKY
    }
}

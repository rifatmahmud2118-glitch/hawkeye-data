package com.rifat.guard

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ScheduleScreen() {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Store.on(ctx, "sch_on", false)) }
    var freq by remember { mutableStateOf(Store.get(ctx, "sch_freq", "daily")) }
    var dow by remember { mutableStateOf(Store.get(ctx, "sch_dow", "6")) }
    var type by remember { mutableStateOf(Store.get(ctx, "sch_type", "quick")) }
    var h by remember { mutableStateOf(Store.long(ctx, "sch_h", 9).toInt()) }
    var m by remember { mutableStateOf(Store.long(ctx, "sch_m", 0).toInt()) }
    var next by remember { mutableStateOf(Store.long(ctx, "sch_next", 0)) }
    fun save() {
        Store.setOn(ctx, "sch_on", on); Store.put(ctx, "sch_freq", freq); Store.put(ctx, "sch_dow", dow); Store.put(ctx, "sch_type", type)
        Store.put(ctx, "sch_h", h.toString()); Store.put(ctx, "sch_m", m.toString()); Scheduler.reschedule(ctx)
        next = Store.long(ctx, "sch_next", 0)
    }
    Page {
        GCard {
            SettingRow(Icons.Filled.Schedule, L.t("Scheduled Scan", "শিডিউল স্ক্যান"), L.t("Run a scan automatically at a set time", "নির্দিষ্ট সময়ে নিজে নিজে স্ক্যান চালায়"), on) { on = it; save() }
        }
        GCard {
            H(L.t("How often", "কতবার"))
            ChoiceRow(listOf("daily" to L.t("Every day", "প্রতিদিন"), "weekly" to L.t("Every week", "প্রতি সপ্তাহে")), freq) { freq = it; save() }
            if (freq == "weekly") {
                H(L.t("Day", "বার"))
                ChoiceRow(listOf("1" to L.t("Sun", "রবি"), "2" to L.t("Mon", "সোম"), "3" to L.t("Tue", "মঙ্গল"), "4" to L.t("Wed", "বুধ"),
                    "5" to L.t("Thu", "বৃহ"), "6" to L.t("Fri", "শুক্র"), "7" to L.t("Sat", "শনি")), dow) { dow = it; save() }
            }
            H(L.t("Time", "সময়"))
            BigButton(String.format("%02d:%02d", h, m), Icons.Filled.Schedule, outlined = true) {
                android.app.TimePickerDialog(ctx, { _, hh, mm -> h = hh; m = mm; save() }, h, m, false).show()
            }
            H(L.t("Scan type", "স্ক্যানের ধরন"))
            ChoiceRow(listOf("quick" to L.t("Quick Scan", "কুইক স্ক্যান"), "full" to L.t("Full System Scan", "ফুল সিস্টেম স্ক্যান")), type) { type = it; save() }
            if (on && next > 0) Hint(L.t("Next scan: ", "পরের স্ক্যান: ") + fmtDate(next))
        }
        Hint(L.t("For reliable timing, keep Real-time protection on or allow unrestricted battery use for this app. If Android blocks a background start, you will get a notification to tap.",
            "সময়মতো চলার জন্য রিয়েল-টাইম প্রোটেকশন চালু রাখুন বা অ্যাপকে ব্যাটারির সীমাহীন অনুমতি দিন। Android ব্যাকগ্রাউন্ডে চালু করতে না দিলে নোটিফিকেশন আসবে, সেটায় চাপ দিন।"))
    }
}

@Composable
fun UpdatesScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var auto by remember { mutableStateOf(Store.on(ctx, "auto_update", true)) }
    var hours by remember { mutableStateOf(Store.get(ctx, "upd_hours", "24")) }
    var key by remember { mutableStateOf(Store.get(ctx, "abuse_key")) }
    var modelUrl by remember { mutableStateOf(Store.get(ctx, "model_url")) }
    var dataBase by remember { mutableStateOf(Store.get(ctx, "data_base")) }
    var dumpLink by remember { mutableStateOf(Store.get(ctx, "dump_link")) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var count by remember { mutableStateOf(SigDb.count(ctx)) }
    var last by remember { mutableStateOf(Store.long(ctx, "db_updated", 0)) }
    LaunchedEffect(DumpState.running) {
        val c = withContext(Dispatchers.IO) { SigDb.count(ctx) }
        count = c; last = Store.long(ctx, "db_updated", 0)
    }
    Page {
        GCard {
            H(L.t("Virus database", "ভাইরাস ডেটাবেস"))
            TRow(L.t("Known malware signatures on this phone", "ফোনে থাকা পরিচিত ভাইরাস সিগনেচার"), "$count")
            TRow(L.t("Last updated", "সর্বশেষ আপডেট"), if (last > 0) fmtDate(last) else L.t("Never", "কখনও না"))
            BigButton(if (busy) L.t("Updating…", "আপডেট চলছে…") else L.t("Update now", "এখনই আপডেট"), Icons.Filled.Update, enabled = !busy) {
                busy = true; msg = ""
                scope.launch(Dispatchers.IO) {
                    val r = SigDb.update(ctx)
                    withContext(Dispatchers.Main) { msg = r; count = SigDb.count(ctx); last = Store.long(ctx, "db_updated", 0); busy = false }
                }
            }
            if (msg.isNotEmpty()) Text(msg)
        }
        GCard {
            H(L.t("Full history download", "পুরো ইতিহাস নামান"))
            Hint(L.t("Downloads the whole MalwareBazaar history once and keeps only Android app (apk) hashes. Use Wi-Fi and a charger. It runs in the background with a progress notification.",
                "MalwareBazaar-এর পুরো ইতিহাস একবার নামিয়ে শুধু Android অ্যাপের (apk) হ্যাশ রাখে। ওয়াইফাই আর চার্জার ব্যবহার করুন। ব্যাকগ্রাউন্ডে চলে, নোটিফিকেশনে প্রোগ্রেস দেখায়।"))
            OutlinedTextField(dumpLink, { dumpLink = it }, Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(),
                label = { Text(L.t("Full data dump link (CSV, zip)", "Full data dump লিংক (CSV, zip)")) })
            BigButton(L.t("Save link", "লিংক সংরক্ষণ"), Icons.Filled.Lock, outlined = true) { Store.put(ctx, "dump_link", dumpLink.trim()) }
            Hint(L.t("How to get it: on bazaar.abuse.ch/export, long-press \"download\" next to CSV > Full data dump, then choose Copy link address. The link contains your key, keep it private. If left empty, the app tries the usual address with your Auth-Key.",
                "কীভাবে পাবেন: bazaar.abuse.ch/export পাতায় CSV > Full data dump-এর পাশের \"download\" চেপে ধরে Copy link address চাপুন। লিংকে আপনার key থাকে, গোপন রাখুন। ঘর ফাঁকা থাকলে অ্যাপ আপনার Auth-Key দিয়ে সাধারণ ঠিকানা চেষ্টা করবে।"))
            if (DumpState.running) {
                LinearProgressIndicator(progress = { DumpState.progress }, modifier = Modifier.fillMaxWidth())
                Text(DumpState.status)
                BigButton(L.t("Stop", "থামান"), Icons.Filled.Close, outlined = true) { DumpState.cancel = true }
            } else {
                BigButton(L.t("Download full history", "পুরো ইতিহাস নামান"), Icons.Filled.Download, enabled = !ScanState.running) {
                    Store.put(ctx, "dump_link", dumpLink.trim())
                    DumpState.running = true; DumpState.cancel = false; DumpState.progress = 0f
                    DumpState.status = L.t("Starting…", "শুরু হচ্ছে…")
                    try {
                        ctx.applicationContext.startForegroundService(Intent(ctx.applicationContext, ScanService::class.java).putExtra("type", "dump"))
                    } catch (e: Exception) { DumpState.running = false; DumpState.status = L.t("Could not start", "চালু করা গেল না") }
                }
                if (DumpState.status.isNotEmpty()) Text(DumpState.status)
            }
        }
        GCard {
            SettingRow(Icons.Filled.Sync, L.t("Auto-update", "অটো-আপডেট"), L.t("Updates by itself in the background when internet is available", "ইন্টারনেট থাকলে ব্যাকগ্রাউন্ডে নিজে আপডেট হয়"), auto) {
                auto = it; Store.setOn(ctx, "auto_update", it); Updater.schedule(ctx)
            }
            if (auto) {
                H(L.t("How often", "কতক্ষণ পর পর"))
                ChoiceRow(listOf("6" to L.t("6 hours", "৬ ঘণ্টা"), "12" to L.t("12 hours", "১২ ঘণ্টা"), "24" to L.t("Daily", "প্রতিদিন"), "168" to L.t("Weekly", "সাপ্তাহিক")), hours) {
                    hours = it; Store.put(ctx, "upd_hours", it); Updater.schedule(ctx)
                }
            }
            Hint(L.t("When off, update manually with the button above.", "বন্ধ থাকলে উপরের বাটন চেপে নিজে আপডেট দিন।"))
        }
        GCard {
            H(L.t("abuse.ch Auth-Key (free)", "abuse.ch Auth-Key (ফ্রি)"))
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text("Auth-Key") })
            BigButton(L.t("Save key", "key সংরক্ষণ"), Icons.Filled.Lock, outlined = true) { Store.put(ctx, "abuse_key", key.trim()) }
            H(L.t("Risk model link (optional)", "ঝুঁকির মডেলের লিংক (ঐচ্ছিক)"))
            OutlinedTextField(modelUrl, { modelUrl = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("https://…/model.json") })
            BigButton(L.t("Save link", "লিংক সংরক্ষণ"), Icons.Filled.Lock, outlined = true) { Store.put(ctx, "model_url", modelUrl.trim()) }
            H(L.t("My data server link (optional)", "আমার ডেটা সার্ভারের লিংক (ঐচ্ছিক)"))
            OutlinedTextField(dataBase, { dataBase = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("https://raw.githubusercontent.com/.../main/") })
            BigButton(L.t("Save data link", "ডেটা লিংক সংরক্ষণ"), Icons.Filled.Lock, outlined = true) { Store.put(ctx, "data_base", dataBase.trim()) }
            Hint(L.t("Your own GitHub data repo builds a bigger Android virus list, a bad-link list and a trained risk model every week. The app fetches all three from this link on every update.",
                "আপনার নিজের গিটহাব ডেটা রিপো প্রতি সপ্তাহে বড় Android ভাইরাস তালিকা, ক্ষতিকর লিংকের তালিকা আর শেখানো ঝুঁকির মডেল বানায়। প্রতিটি আপডেটে অ্যাপ এই লিংক থেকে তিনটাই নামায়।"))
            Hint(L.t("Get it free at auth.abuse.ch (sign up, then copy your Auth-Key).", "auth.abuse.ch থেকে ফ্রি পাবেন (সাইন আপ করে Auth-Key কপি করুন)।"))
        }
        GCard {
            H(L.t("Where updates come from", "আপডেট কোথা থেকে আসে"))
            Text("• MalwareBazaar (abuse.ch): " + L.t("hashes of malware seen in the last 48 hours, downloaded to this phone and matched offline. Needs the free Auth-Key above.", "গত ৪৮ ঘণ্টায় দেখা ম্যালওয়্যারের হ্যাশ, ফোনে নামিয়ে অফলাইনে মেলানো হয়। উপরের ফ্রি Auth-Key লাগে।"), style = MaterialTheme.typography.bodyMedium)
            Text("• VirusTotal: " + L.t("live lookup by file fingerprint across 70+ engines, always current. Needs a free key in Settings.", "ফাইলের আঙুলের ছাপ দিয়ে ৭০+ ইঞ্জিনে লাইভ যাচাই, সব সময় নতুন। সেটিংসে ফ্রি key লাগে।"), style = MaterialTheme.typography.bodyMedium)
            Text("• Google Safe Browsing: " + L.t("live check of links for phishing and malware. Needs a free key in Settings.", "ফিশিং ও ম্যালওয়্যার লিংকের লাইভ যাচাই। সেটিংসে ফ্রি key লাগে।"), style = MaterialTheme.typography.bodyMedium)
            Text("• Android: " + L.t("your phone's own security patch level is checked on every scan.", "প্রতিটি স্ক্যানে ফোনের নিজস্ব সিকিউরিটি প্যাচের অবস্থা দেখা হয়।"), style = MaterialTheme.typography.bodyMedium)
            Hint(L.t("This updates threat lists, not the app itself. A new app version must be installed manually.", "এটা ভাইরাসের তালিকা আপডেট করে, অ্যাপ নিজে নয়। অ্যাপের নতুন সংস্করণ নিজে ইনস্টল করতে হবে।"))
        }
    }
}

@Composable
fun PwDialog(mode: String, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDone,
        title = { Text(when (mode) { "set" -> L.t("Set password", "পাসওয়ার্ড দিন"); "change" -> L.t("Change password", "পাসওয়ার্ড বদলান"); else -> L.t("Remove password", "পাসওয়ার্ড সরান") }) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (mode != "set") OutlinedTextField(a, { a = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(L.t("Current password", "বর্তমান পাসওয়ার্ড")) })
                if (mode != "remove") OutlinedTextField(b, { b = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(L.t("New password (min 4)", "নতুন পাসওয়ার্ড (কমপক্ষে ৪)")) })
                if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)
                if (mode == "set") Hint(L.t("There is no recovery. If you forget it, clear the app's data.", "পুনরুদ্ধারের উপায় নেই। ভুলে গেলে অ্যাপের ডেটা মুছতে হবে।"))
            }
        },
        confirmButton = {
            TextButton({
                val wrong = mode != "set" && !Pass.check(ctx, a)
                val short = mode != "remove" && b.length < 4
                when {
                    wrong -> err = L.t("Wrong password", "পাসওয়ার্ড ভুল")
                    short -> err = L.t("Too short", "খুব ছোট")
                    mode == "remove" -> { Pass.clear(ctx); onDone() }
                    else -> { Pass.set(ctx, b); onDone() }
                }
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onDone) { Text(L.t("Cancel", "বাতিল")) } })
}

@Composable
fun LockScreen(title: String, onOk: () -> Unit) {
    val ctx = LocalContext.current
    var p by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(start = 24.dp, end = 24.dp, top = 28.dp, bottom = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Top) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(84.dp).clip(CircleShape), contentScale = ContentScale.Crop)
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(p, { p = it; err = false }, singleLine = true, visualTransformation = PasswordVisualTransformation(),
            label = { Text(L.t("Password", "পাসওয়ার্ড")) }, isError = err)
        if (err) Text(L.t("Wrong password", "পাসওয়ার্ড ভুল"), color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(12.dp))
        BigButton(L.t("Unlock", "খুলুন"), Icons.Filled.Lock, modifier = Modifier.fillMaxWidth()) { if (Pass.check(ctx, p)) onOk() else err = true }
    }
}

@Composable
fun SettingsScreen(ui: UiState, onOpen: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = resumeTick()
    var vt by remember { mutableStateOf(Store.get(ctx, "vt_key")) }
    var sb by remember { mutableStateOf(Store.get(ctx, "sb_key")) }
    var hibp by remember { mutableStateOf(Store.get(ctx, "hibp_key")) }
    var pwDialog by remember { mutableStateOf("") }
    var hasPw by remember(tick, pwDialog) { mutableStateOf(Pass.enabled(ctx)) }
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) { if (saveBg(ctx, uri)) withContext(Dispatchers.Main) { ui.setBg(System.currentTimeMillis().toString()) } }
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val version = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    Page {
        SectionLabel(L.t("Appearance", "চেহারা"))
        GCard {
            SettingRow(Icons.Filled.DarkMode, L.t("Dark theme", "ডার্ক থিম"), L.t("Dark look. Turn off for light.", "ডার্ক লুক। বন্ধ করলে হালকা।"), ui.dark) { ui.applyDark(it) }
            H(L.t("Language", "ভাষা"))
            ChoiceRow(listOf("en" to "English", "bn" to "বাংলা"), if (L.bn) "bn" else "en") { ui.setLang(it == "bn") }
            H(L.t("Text size", "লেখার আকার") + "  ${(ui.scale * 100).toInt()}%")
            Slider(ui.scale, { ui.applyScale(it) }, valueRange = 0.7f..1.6f)
            ThemePicker(ui)
            H(L.t("Background", "ব্যাকগ্রাউন্ড"))
            BigButton(L.t("Choose background picture", "ব্যাকগ্রাউন্ড ছবি বাছুন"), Icons.Filled.Image, outlined = true) { bgPicker.launch("image/*") }
            if (ui.bgVer != "0") BigButton(L.t("Remove background", "ব্যাকগ্রাউন্ড সরান"), Icons.Filled.Delete, outlined = true) {
                File(ctx.filesDir, "bg.jpg").delete(); ui.setBg("0")
            }
        }

        SectionLabel(L.t("Protection", "সুরক্ষা"))
        GCard {
            var shield by remember { mutableStateOf(Store.on(ctx, "shield_on", false)) }
            SettingRow(Icons.Filled.Shield, L.t("Real-time protection", "রিয়েল-টাইম প্রোটেকশন"), L.t("File and Behavior shields in the background", "ব্যাকগ্রাউন্ডে ফাইল ও বিহেভিয়র শিল্ড"), shield) { shield = it; setShield(ctx, it) }
            StoreToggle(Icons.Filled.Update, L.t("Start after reboot", "রিবুটের পর নিজে চালু"), L.t("Protection resumes when the phone restarts", "ফোন রিস্টার্টের পর সুরক্ষা আবার চালু হয়"), "boot_on")
            StoreToggle(Icons.Filled.Notifications, L.t("Sound when scan finishes", "স্ক্যান শেষে সাউন্ড"), L.t("Plays a notification sound on completion", "শেষ হলে নোটিফিকেশন সাউন্ড বাজে"), "scan_sound")
            ActionRow(Icons.Filled.Shield, L.t("Shields in detail", "শিল্ডের বিস্তারিত"), L.t("File, Behavior, Email, Message, SMS", "File, Behavior, Email, Message, SMS")) { onOpen(Screen.SHIELDS) }
            ActionRow(Icons.Filled.Phone, L.t("Spam call protection", "স্প্যাম কল সুরক্ষা"), "") { onOpen(Screen.CALLS) }
        }

        SectionLabel(L.t("Scanning", "স্ক্যান"))
        GCard {
            StoreToggle(Icons.Filled.Apps, L.t("Include system apps", "সিস্টেম অ্যাপও দেখুন"), "", "scan_sys")
            StoreToggle(Icons.Filled.Image, L.t("Media and document disguise check", "মিডিয়া ও ডকুমেন্টের ছদ্মবেশ যাচাই"), "", "scan_media")
            StoreToggle(Icons.Filled.Search, L.t("Online check (VirusTotal)", "অনলাইন যাচাই (VirusTotal)"), "", "scan_online")
            ActionRow(Icons.Filled.Schedule, L.t("Scheduled Scan", "শিডিউল স্ক্যান"), "") { onOpen(Screen.SCHEDULE) }
            ActionRow(Icons.Filled.Update, L.t("Update Settings", "আপডেট সেটিংস"), "") { onOpen(Screen.UPDATES) }
        }

        SectionLabel(L.t("Permissions", "অনুমতি"))
        GCard {
            PermRow(remember(tick) { Perms.files() }, L.t("All files access", "সব ফাইল অ্যাক্সেস")) { Perms.open(ctx, Perms.filesIntent(ctx)) }
            PermRow(remember(tick) { Perms.notifAccess(ctx) }, L.t("Notification access", "নোটিফিকেশন অ্যাক্সেস")) { Perms.open(ctx, Perms.listenerIntent()) }
            PermRow(remember(tick) { Perms.post(ctx) }, L.t("Show notifications", "নোটিফিকেশন দেখানো")) { notifPerm.launch("android.permission.POST_NOTIFICATIONS") }
            PermRow(remember(tick) { Perms.battery(ctx) }, L.t("Unrestricted battery use", "ব্যাটারির সীমাহীন ব্যবহার")) { Perms.open(ctx, Perms.batteryIntent(ctx)) }
        }

        SectionLabel(L.t("Security", "নিরাপত্তা"))
        GCard {
            if (!hasPw) ActionRow(Icons.Filled.Lock, L.t("Set app password", "অ্যাপের পাসওয়ার্ড দিন"), L.t("Locks the app and its settings", "অ্যাপ ও এর সেটিংস তালাবদ্ধ রাখে")) { pwDialog = "set" }
            else {
                ActionRow(Icons.Filled.Lock, L.t("Change password", "পাসওয়ার্ড বদলান"), "") { pwDialog = "change" }
                ActionRow(Icons.Filled.Delete, L.t("Remove password", "পাসওয়ার্ড সরান"), "") { pwDialog = "remove" }
                StoreToggle(Icons.Filled.Schedule, L.t("Auto-lock", "অটো-লক"), L.t("Lock again after 1 minute away from the app", "অ্যাপ থেকে ১ মিনিট দূরে থাকলে আবার লক"), "autolock")
            }
        }

        SectionLabel("API key")
        GCard {
            OutlinedTextField(vt, { vt = it }, Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(L.t("VirusTotal (free)", "VirusTotal (ফ্রি)")) })
            OutlinedTextField(sb, { sb = it }, Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(L.t("Google Safe Browsing (free)", "Google Safe Browsing (ফ্রি)")) })
            OutlinedTextField(hibp, { hibp = it }, Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(L.t("HaveIBeenPwned (paid, email check)", "HaveIBeenPwned (পেইড, ইমেইল চেক)")) })
            BigButton(L.t("Save keys", "key সংরক্ষণ"), Icons.Filled.Lock) { Store.put(ctx, "vt_key", vt.trim()); Store.put(ctx, "sb_key", sb.trim()); Store.put(ctx, "hibp_key", hibp.trim()) }
            Hint(L.t("Keys stay on this phone, in this app's private storage.", "key এই ফোনে, অ্যাপের ব্যক্তিগত জায়গায় থাকে।"))
        }

        SectionLabel(L.t("About", "সম্পর্কে"))
        GCard {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.logo), null, Modifier.size(140.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                Spacer(Modifier.height(10.dp))
                Text("Rifat's Hawkeye", style = MaterialTheme.typography.titleLarge)
                Hint(L.t("Version ", "সংস্করণ ") + version)
            }
            Spacer(Modifier.height(6.dp))
            H(L.t("Developer", "ডেভেলপার"))
            TRow(L.t("Name", "নাম"), "Golam Mahmud Rifat")
            ActionRow(Icons.Filled.Email, "rifatmahmud21.18@gmail.com", L.t("Email the developer", "ডেভেলপারকে ইমেইল")) {
                Perms.open(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:rifatmahmud21.18@gmail.com")))
            }
            ActionRow(Icons.Filled.Chat, "WhatsApp: 01533573989", L.t("Message on WhatsApp", "WhatsApp-এ মেসেজ")) {
                Perms.open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/8801533573989")))
            }
            ActionRow(Icons.Filled.Chat, "WhatsApp: 01758567166", L.t("Message on WhatsApp", "WhatsApp-এ মেসেজ")) {
                Perms.open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/8801758567166")))
            }
        }
    }
    if (pwDialog.isNotEmpty()) PwDialog(pwDialog) { pwDialog = "" }
}

package com.rifat.guard

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var sharedText by mutableStateOf("")
    private var sharedFiles by mutableStateOf<List<Uri>>(emptyList())
    private var locked by mutableStateOf(false)
    private var stopAt = 0L
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Alerts.init(this)
        ScanState.load(this)
        Updater.schedule(this)
        Updater.ensureTick(this)
        Updater.autoDump(this)
        if (Store.on(this, "sch_on", false) && Store.long(this, "sch_next", 0L) == 0L) Scheduler.reschedule(this)
        if (Store.get(this, "shield_init").isEmpty()) { Store.put(this, "shield_init", "1"); Store.setOn(this, "shield_on", true) }
        if (Store.on(this, "shield_on", false)) setShield(this, true)
        if (Theft.enabled(this)) GuardService.start(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) notifPerm.launch("android.permission.POST_NOTIFICATIONS")
        handle(intent)
        locked = Pass.enabled(this)
        val ui = UiState(this)
        setContent { AppTheme(ui) { Root(ui, locked, { locked = false }, sharedText, sharedFiles) } }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }

    override fun onStop() { super.onStop(); stopAt = System.currentTimeMillis() }

    override fun onStart() {
        super.onStart()
        if (stopAt > 0 && Pass.enabled(this) && Store.on(this, "autolock", true) && System.currentTimeMillis() - stopAt > 60000) locked = true
    }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent?) {
        when (i?.action) {
            Intent.ACTION_SEND -> {
                val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                val t = i.getStringExtra(Intent.EXTRA_TEXT)
                if (u != null) sharedFiles = listOf(u) else if (!t.isNullOrBlank()) sharedText = t
            }
            Intent.ACTION_SEND_MULTIPLE -> sharedFiles = i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.toList() ?: emptyList()
        }
    }
}

private class Nav(val s: Screen, val icon: ImageVector, val en: String, val bn: String)

private val groups: List<Triple<String, String, List<Nav>>> = listOf(
    Triple("Scan", "স্ক্যান", listOf(
        Nav(Screen.HOME, Icons.Filled.Home, "Home", "হোম"),
        Nav(Screen.FULL, Icons.Filled.Shield, "Full System Scan", "ফুল সিস্টেম স্ক্যান"),
        Nav(Screen.REPORT, Icons.Filled.Description, "Scan Report", "স্ক্যান রিপোর্ট"))),
    Triple("Real-time protection", "রিয়েল-টাইম সুরক্ষা", listOf(
        Nav(Screen.SHIELDS, Icons.Filled.Security, "Shields", "শিল্ড"),
        Nav(Screen.CALLS, Icons.Filled.Phone, "Spam Call Protection", "স্প্যাম কল সুরক্ষা"))),
    Triple("Tools", "টুলস", listOf(
        Nav(Screen.LINKS, Icons.Filled.Link, "Link & Message Check", "লিংক ও মেসেজ যাচাই"),
        Nav(Screen.FILES, Icons.Filled.Folder, "File Check", "ফাইল যাচাই"),
        Nav(Screen.APPS, Icons.Filled.Apps, "Installed Apps", "ইনস্টল করা অ্যাপ"),
        Nav(Screen.JUNK, Icons.Filled.CleaningServices, "Junk Cleaner", "জাঙ্ক ক্লিনার"),
        Nav(Screen.BREACH, Icons.Filled.PrivacyTip, "Breach Check", "ডেটা ফাঁস যাচাই"))),
    Triple("Advanced protection", "উন্নত সুরক্ষা", listOf(
        Nav(Screen.THEFT, Icons.Filled.PhonelinkLock, "Anti-theft", "চুরি-বিরোধী"),
        Nav(Screen.WIFI, Icons.Filled.Wifi, "Wi-Fi Security", "ওয়াইফাই নিরাপত্তা"),
        Nav(Screen.VPN, Icons.Filled.VpnKey, "DNS Shield (VPN)", "DNS শিল্ড (VPN)"))),
    Triple("Manage", "ব্যবস্থাপনা", listOf(
        Nav(Screen.SCHEDULE, Icons.Filled.Schedule, "Scheduled Scan", "শিডিউল স্ক্যান"),
        Nav(Screen.UPDATES, Icons.Filled.Update, "Update Settings", "আপডেট সেটিংস"),
        Nav(Screen.SETTINGS, Icons.Filled.Settings, "Settings", "সেটিংস")))
)

private val gated = setOf(Screen.SHIELDS, Screen.CALLS, Screen.SCHEDULE, Screen.UPDATES, Screen.SETTINGS, Screen.THEFT, Screen.VPN)

private fun titleOf(s: Screen): String = groups.flatMap { it.third }.firstOrNull { it.s == s }?.let { L.t(it.en, it.bn) } ?: "Rifat's Hawkeye"

@Composable
fun Root(ui: UiState, locked: Boolean, onUnlock: () -> Unit, sharedText: String, sharedFiles: List<Uri>) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var gateOk by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableStateOf(0) }
    LaunchedEffect(locked) { if (locked) gateOk = false }
    LaunchedEffect(sharedText) { if (sharedText.isNotBlank()) screen = Screen.LINKS }
    LaunchedEffect(sharedFiles) { if (sharedFiles.isNotEmpty()) screen = Screen.FILES }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val bg = remember(ui.bgVer) { if (ui.bgVer == "0") null else loadBg(ctx) }
    val cs = MaterialTheme.colorScheme
    BackHandler(enabled = screen != Screen.HOME || drawer.isOpen) {
        if (drawer.isOpen) scope.launch { drawer.close() } else screen = Screen.HOME
    }
    Box(Modifier.fillMaxSize().background(cs.background)) {
        if (bg != null) {
            Image(bg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(cs.background.copy(alpha = 0.72f)))
        }
        CompositionLocalProvider(
            LocalContentColor provides cs.onBackground,
            LocalCardColor provides (if (bg != null) cs.surfaceVariant.copy(alpha = 0.85f) else cs.surfaceVariant)
        ) {
            ProvideTextStyle(MaterialTheme.typography.bodyLarge) {
                if (locked) LockScreen(L.t("Rifat's Hawkeye is locked", "Rifat's Hawkeye তালাবদ্ধ"), onUnlock)
                else ModalNavigationDrawer(
                    drawerState = drawer,
                    drawerContent = {
                        ModalDrawerSheet {
                            Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
                                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Image(painterResource(R.drawable.logo), null, Modifier.size(52.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                                    Spacer(Modifier.width(12.dp))
                                    Text("Rifat's Hawkeye", style = MaterialTheme.typography.titleLarge)
                                }
                                groups.forEach { (en, bn, items) ->
                                    Text(L.t(en, bn), style = MaterialTheme.typography.labelLarge, color = cs.primary, modifier = Modifier.padding(start = 24.dp, top = 12.dp, bottom = 4.dp))
                                    items.forEach { n ->
                                        NavigationDrawerItem(
                                            label = { Text(L.t(n.en, n.bn)) },
                                            icon = { Icon(n.icon, null) },
                                            selected = screen == n.s,
                                            onClick = { screen = n.s; scope.launch { drawer.close() } },
                                            modifier = Modifier.padding(horizontal = 12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                ) {
                    Column(Modifier.fillMaxSize()) {
                        val home = screen == Screen.HOME
                        val r = ScanState.result
                        HeaderBanner(
                            title = if (home) "Rifat's Hawkeye" else titleOf(screen),
                            subtitle = if (!home) "" else if (r == null) L.t("Not scanned yet", "এখনও স্ক্যান হয়নি")
                                else L.t("Last scan score ${r.score}/100", "সর্বশেষ স্ক্যান স্কোর ${r.score}/১০০"),
                            tall = home,
                            onMenu = { scope.launch { drawer.open() } },
                            onRefresh = { refreshKey++ },
                            onHome = if (home) null else ({ screen = Screen.HOME })
                        )
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            if (screen in gated && Pass.enabled(ctx) && !gateOk) LockScreen(L.t("Enter password to continue", "চালিয়ে যেতে পাসওয়ার্ড দিন")) { gateOk = true }
                            else key(screen, refreshKey) { when (screen) {
                                Screen.HOME -> HomeScreen { screen = it }
                                Screen.FULL -> FullScanScreen { screen = it }
                                Screen.REPORT -> ReportScreen()
                                Screen.SHIELDS -> ShieldsScreen()
                                Screen.CALLS -> CallsScreen()
                                Screen.LINKS -> LinksScreen(sharedText)
                                Screen.FILES -> FilesScreen(sharedFiles)
                                Screen.APPS -> AppsScreen()
                                Screen.JUNK -> JunkScreen()
                                Screen.BREACH -> BreachScreen()
                                Screen.SCHEDULE -> ScheduleScreen()
                                Screen.UPDATES -> UpdatesScreen()
                                Screen.SETTINGS -> SettingsScreen(ui) { screen = it }
                                Screen.THEFT -> TheftScreen()
                                Screen.WIFI -> WifiScreen()
                                Screen.VPN -> VpnScreen()
                            } }
                        }
                    }
                }
            }
        }
    }
}

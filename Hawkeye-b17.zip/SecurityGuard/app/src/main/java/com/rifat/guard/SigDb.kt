package com.rifat.guard

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

// পুরো ইতিহাস নামানোর অবস্থা (অন্য পেইজে গেলেও হারায় না)
object DumpState {
    var running by mutableStateOf(false)
    var status by mutableStateOf("")
    var progress by mutableStateOf(0f)
    @Volatile var cancel = false
}

private class CountingInputStream(i: InputStream) : FilterInputStream(i) {
    @Volatile var count = 0L
    override fun read(): Int { val r = super.read(); if (r >= 0) count++; return r }
    override fun read(b: ByteArray, off: Int, len: Int): Int { val r = super.read(b, off, len); if (r > 0) count += r; return r }
}

// ফোনের ভেতরের ভাইরাস হ্যাশ তালিকা (অফলাইনে মিলিয়ে দেখা যায়)
object SigDb {
    // EICAR টেস্ট ফাইল: ধরা পড়ছে কিনা পরীক্ষার জন্য
    private val builtin = setOf("275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f")
    @Volatile private var set: HashSet<String>? = null

    private fun file(ctx: Context) = File(ctx.filesDir, "sigs.txt")

    fun load(ctx: Context): Set<String> {
        set?.let { return it }
        val s = HashSet<String>(builtin)
        try { file(ctx).forEachLine { if (it.length == 64) s.add(it) } } catch (e: Exception) { }
        set = s
        return s
    }

    fun count(ctx: Context): Int = load(ctx).size

    fun addHashes(ctx: Context, found: Set<String>): Int {
        val s = HashSet<String>(load(ctx))
        val before = s.size
        s.addAll(found)
        file(ctx).bufferedWriter().use { w -> s.forEach { if (it !in builtin) { w.write(it); w.newLine() } } }
        set = s
        Store.put(ctx, "db_updated", System.currentTimeMillis().toString())
        return s.size - before
    }
    fun isBad(ctx: Context, sha: String): Boolean = sha.isNotEmpty() && load(ctx).contains(sha.lowercase())

    private fun unzip(data: ByteArray): String {
        ZipInputStream(ByteArrayInputStream(data)).use { z ->
            z.nextEntry ?: return ""
            return String(z.readBytes())
        }
    }

    // MalwareBazaar-এর Full data dump (CSV, zip) স্ট্রিম করে পড়ে, শুধু Android অ্যাপ (apk) হ্যাশ রাখে
    fun fullDump(ctx: Context): String {
        val key = Store.get(ctx, "abuse_key")
        var link = Store.get(ctx, "dump_link").trim()
        if (link.isBlank()) {
            if (key.isBlank()) return L.t("Add your Auth-Key or the dump link first", "আগে Auth-Key বা ডাম্পের লিংক বসান")
            link = "https://mb-api.abuse.ch/v2/files/exports/$key/full.csv.zip"
        }
        var conn: HttpURLConnection? = null
        try {
            conn = URL(link).openConnection() as HttpURLConnection
            conn.connectTimeout = 20000
            conn.readTimeout = 120000
            val code = conn.responseCode
            if (code != 200) return L.t("Server refused (code $code). Check the link or key.", "সার্ভার রাজি হয়নি (কোড $code), লিংক বা key দেখুন")
            val total = conn.contentLengthLong
            val counting = CountingInputStream(conn.inputStream)
            val bin = BufferedInputStream(counting, 1 shl 16)
            bin.mark(4)
            val b0 = bin.read(); val b1 = bin.read()
            bin.reset()
            val stream: InputStream = if (b0 == 'P'.code && b1 == 'K'.code) {
                val z = ZipInputStream(bin)
                z.nextEntry ?: return L.t("The downloaded zip is empty", "নামানো zip ফাঁকা")
                z
            } else bin
            val reader = BufferedReader(InputStreamReader(stream, Charsets.UTF_8), 1 shl 16)
            val re = Regex("\\b[0-9a-fA-F]{64}\\b")
            val apkRe = Regex("(^|[\",;])apk([\",;]|\$)", RegexOption.IGNORE_CASE)
            val found = HashSet<String>()
            var lines = 0L
            while (true) {
                if (DumpState.cancel) return L.t("Cancelled", "বাতিল হয়েছে")
                val line = reader.readLine() ?: break
                lines++
                if (line.isEmpty() || line[0] == '#') continue
                if (line.contains("package-archive", true) || apkRe.containsMatchIn(line)) {
                    re.find(line)?.let { found.add(it.value.lowercase()) }
                    if (found.size > 800000) break
                }
                if (lines % 20000L == 0L) {
                    DumpState.status = L.t("Read $lines rows • ${found.size} Android hashes", "$lines সারি পড়া • ${found.size}টি Android হ্যাশ")
                    if (total > 0) DumpState.progress = (counting.count.toFloat() / total).coerceIn(0f, 0.99f)
                }
            }
            val s = HashSet<String>(load(ctx))
            val before = s.size
            s.addAll(found)
            file(ctx).bufferedWriter().use { w -> s.forEach { if (it !in builtin) { w.write(it); w.newLine() } } }
            set = s
            Store.put(ctx, "db_updated", System.currentTimeMillis().toString())
            DumpState.progress = 1f
            if (found.isEmpty()) return L.t("Read $lines rows but found no Android hashes. The file format may differ.", "$lines সারি পড়া হয়েছে, কিন্তু Android হ্যাশ মেলেনি। ফাইলের ধরন আলাদা হতে পারে।")
            return L.t("Done: ${found.size} Android hashes read, ${s.size - before} new, ${s.size} total", "শেষ: ${found.size}টি Android হ্যাশ পড়া, নতুন ${s.size - before}টি, মোট ${s.size}টি")
        } catch (e: Exception) {
            return L.t("Download failed (check internet or link)", "নামানো ব্যর্থ (ইন্টারনেট বা লিংক দেখুন)")
        } finally { conn?.disconnect() }
    }

    fun update(ctx: Context): String {
        val hub = try { DataHub.refresh(ctx) } catch (e: Exception) { "" }
        val a = updateHashes(ctx)
        val m = try { ModelScorer.update(ctx) } catch (e: Exception) { "" }
        var out = a
        if (hub.isNotEmpty()) out += "\n" + hub
        if (m.isNotEmpty()) out += "\n" + m
        return out
    }

    private fun updateHashes(ctx: Context): String {
        val key = Store.get(ctx, "abuse_key")
        if (key.isBlank()) return L.t("Add your abuse.ch Auth-Key first", "আগে abuse.ch Auth-Key বসান")
        return try {
            val (code, data) = Net.bytes("https://mb-api.abuse.ch/v2/files/exports/$key/recent.csv")
            if (code != 200) return L.t("Server refused (code $code). Check the key.", "সার্ভার রাজি হয়নি (কোড $code), key দেখুন")
            val text = if (data.size > 2 && data[0] == 'P'.code.toByte() && data[1] == 'K'.code.toByte()) unzip(data) else String(data)
            val re = Regex("[0-9a-fA-F]{64}")
            val add = HashSet<String>()
            text.lineSequence().forEach { line ->
                if (!line.startsWith("#")) re.find(line)?.let { add.add(it.value.lowercase()) }
            }
            val s = HashSet<String>(load(ctx))
            val before = s.size
            s.addAll(add)
            file(ctx).writeText(s.filter { it !in builtin }.joinToString("\n"))
            set = s
            Store.put(ctx, "db_updated", System.currentTimeMillis().toString())
            L.t("Updated: ${s.size - before} new, ${s.size} total", "আপডেট হয়েছে: নতুন ${s.size - before}টি, মোট ${s.size}টি")
        } catch (e: Exception) { L.t("Update failed (check internet)", "আপডেট ব্যর্থ (ইন্টারনেট দেখুন)") }
    }
}

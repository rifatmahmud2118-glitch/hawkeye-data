package com.rifat.guard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.abs

private data class Preset(val h: Float, val s: Float)

@Composable
private fun GradSlider(value: Float, range: ClosedFloatingPointRange<Float>, colors: List<Color>, onChange: (Float) -> Unit) {
    Box(Modifier.fillMaxWidth().height(40.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 10.dp).height(12.dp).clip(RoundedCornerShape(6.dp)).background(Brush.horizontalGradient(colors)))
        Slider(
            value, onChange, valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Color.Transparent, inactiveTrackColor = Color.Transparent,
                activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent
            )
        )
    }
}

// থিমের যেকোনো রঙ ও রঙের পরিমাণ বদলানোর অংশ
@Composable
fun ThemePicker(ui: UiState) {
    val presets = listOf(
        Preset(265f, 0.5f), Preset(215f, 0.6f), Preset(185f, 0.6f), Preset(160f, 0.55f), Preset(130f, 0.5f),
        Preset(80f, 0.55f), Preset(50f, 0.6f), Preset(28f, 0.65f), Preset(355f, 0.65f), Preset(325f, 0.55f), Preset(0f, 0f)
    )
    H(L.t("Theme color", "থিমের রঙ"))
    Hint(L.t("Pick any color, then choose how strong it looks.", "যেকোনো রঙ বাছুন, তারপর রঙ কতটা গাঢ় হবে ঠিক করুন।"))
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        presets.forEach { p ->
            val c = Color.hsv(p.h, if (p.s == 0f) 0f else 0.65f, 0.9f)
            val picked = abs(ui.hue - p.h) < 3f && ((p.s == 0f) == (ui.sat < 0.05f))
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(c)
                    .border(if (picked) 3.dp else 1.dp, if (picked) Color.White else Color(0x55FFFFFF), CircleShape)
                    .clickable { ui.applyTheme(p.h, p.s, ui.shade) }
            )
        }
    }
    Text(L.t("Any color", "যেকোনো রঙ") + "  ${ui.hue.toInt()}°", style = MaterialTheme.typography.labelLarge)
    GradSlider(ui.hue, 0f..360f, (0..12).map { Color.hsv(it * 30f, 0.75f, 0.95f) }) { ui.applyTheme(it, ui.sat, ui.shade) }
    Text(L.t("Color amount", "রঙের পরিমাণ") + "  ${(ui.sat * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
    GradSlider(ui.sat, 0f..1f, listOf(Color.hsv(ui.hue, 0f, 0.7f), Color.hsv(ui.hue, 1f, 0.9f))) { ui.applyTheme(ui.hue, it, ui.shade) }
    Text(L.t("Background brightness", "ব্যাকগ্রাউন্ডের উজ্জ্বলতা") + "  ${(ui.shade * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
    GradSlider(ui.shade, 0f..1f, listOf(Color.hsv(ui.hue, ui.sat.coerceAtLeast(0.3f), 0.15f), Color.hsv(ui.hue, ui.sat.coerceAtLeast(0.3f) * 0.8f, 0.6f))) { ui.applyTheme(ui.hue, ui.sat, it) }
    BigButton(L.t("Reset to default purple", "ডিফল্ট বেগুনিতে ফিরুন"), Icons.Filled.Refresh, outlined = true) { ui.applyTheme(265f, 0.5f, 0.35f) }
}

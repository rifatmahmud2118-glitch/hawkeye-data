package com.rifat.guard

import android.app.PendingIntent
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.FileObserver
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.provider.Telephony
import java.io.File
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap

// রিয়েল-টাইম সুরক্ষা: File Shield + Behavior Shield + শিডিউল স্ক্যানের ঘড়ি
class ShieldService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val observers = ArrayList<FileObserver>()
    private val seen = ConcurrentHashMap<String, Long>()
    private var pkgReceiver: BroadcastReceiver? = null
    private var started = false
    private val swept = ConcurrentHashMap<String, Long>()

    companion object { @Volatile var alive = false }

    private val tick = object : Runnable {
        override fun run() {
            val c = applicationContext
            Thread { try { BehaviorShield.poll(c); Scheduler.runIfDue(c); sweep() } catch (e: Exception) { } }.start()
            h.postDelayed(this, 60000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Alerts.shield(this)
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(7, n)
        alive = true
        if (!started) { started = true; setup() }
        return START_STICKY
    }

    private fun watch(dir: File) {
        if (!dir.isDirectory) return
        val o = object : FileObserver(dir, FileObserver.CLOSE_WRITE or FileObserver.MOVED_TO) {
            override fun onEvent(event: Int, path: String?) { if (path != null) onFile(File(dir, path)) }
        }
        o.startWatching()
        observers.add(o)
    }

    private fun setup() {
        val base = Environment.getExternalStorageDirectory()
        listOf("Download", "Documents", "Bluetooth", "DCIM", "Telegram/Telegram Documents", "Telegram/Telegram Files",
            "WhatsApp/Media/WhatsApp Documents", "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Documents",
            "Android/media/org.telegram.messenger/Telegram/Telegram Documents").map { File(base, it) }.forEach { d ->
            watch(d)
            d.listFiles()?.filter { it.isDirectory }?.take(30)?.forEach { watch(it) }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package")
        }
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (!Store.on(c, "beh_on", true)) return
                val pkg = i.data?.schemeSpecificPart ?: return
                if (pkg == c.packageName) return
                val added = i.action == Intent.ACTION_PACKAGE_ADDED
                val app = c.applicationContext
                Thread {
                    try {
                        val a = AppAuditor.auditOne(app, pkg) ?: return@Thread
                        if (Trusted.isApp(app, pkg)) return@Thread
                        if (a.sha256.isNotEmpty() && Store.get(app, "vt_key").isNotBlank()) {
                            val vr = VirusTotal.cached(app, a.sha256) ?: VirusTotal.fetch(app, a.sha256)
                            VtStore.map[a.sha256] = vr
                            if (vr.level != Risk.LOW) Alerts.notify(app, L.t("Install check: ", "ইনস্টল যাচাই: ") + vr.level.label(), a.name + "\n" + vr.text())
                        }
                        ShieldStats.checked++
                        if (a.risk == Risk.HIGH || (added && a.risk == Risk.MEDIUM)) {
                            val t = L.t("Install Shield: ", "ইনস্টল শিল্ড: ") + if (a.risk == Risk.HIGH) L.t("dangerous app", "বিপজ্জনক অ্যাপ") else L.t("suspicious app", "সন্দেহজনক অ্যাপ")
                            if (a.risk == Risk.HIGH) { ShieldStats.blocked++; ShieldStats.last = a.name }
                            val del = PendingIntent.getActivity(app, 7, Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                            Alerts.notifyAction(app, t, a.name + "\n" + a.reasons.joinToString("\n• ", "• "), L.t("Uninstall", "মুছে ফেলুন"), del)
                        }
                    } catch (e: Exception) { }
                }.start()
            }
        }
        pkgReceiver = r
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_EXPORTED) else registerReceiver(r, f)
        h.post(tick)
    }

    // FileObserver যা মিস করে তা ধরতে: প্রতি মিনিটে Download ও Documents-এর নতুন ফাইল আবার দেখা
    private fun sweep() {
        val base = Environment.getExternalStorageDirectory()
        val cutoff = System.currentTimeMillis() - 180000L
        listOf("Download", "Documents").forEach { d ->
            File(base, d).walkTopDown().maxDepth(2).forEach { f ->
                if (f.isFile && f.lastModified() > cutoff && swept.put(f.path, f.lastModified()) != f.lastModified()) onFile(f)
            }
        }
        if (swept.size > 2000) swept.clear()
    }

    private fun onFile(f: File) {
        val app = applicationContext
        if (!Store.on(app, "file_on", true)) return
        val now = System.currentTimeMillis()
        val last = seen[f.path]
        if (last != null && now - last < 5000) return
        seen[f.path] = now
        Thread {
            try {
                Thread.sleep(700)
                if (!f.isFile) return@Thread
                val v = Scanner.evaluate(app, f, SigDb.load(app), true)
                var fnd = v.finding?.takeIf { !Trusted.isTrusted(app, it) }
                if (fnd == null && v.isApk && v.sha.isNotEmpty() && Store.get(app, "vt_key").isNotBlank()) {
                    val r = VirusTotal.cached(app, v.sha) ?: VirusTotal.fetch(app, v.sha)
                    VtStore.map[v.sha] = r
                    if (r.level != Risk.LOW) fnd = Finding("file", f.name, r.text(), r.level, f.path, v.sha).takeIf { !Trusted.isTrusted(app, it) }
                }
                ShieldStats.checked++
                if (fnd != null) {
                    ShieldStats.last = fnd.title
                    var head = L.t("File Shield: ", "ফাইল শিল্ড: ") + fnd.risk.label()
                    var text = fnd.title + "\n" + fnd.detail
                    if (fnd.risk == Risk.HIGH && Store.on(app, "auto_q", true) && Quarantine.move(app, f, fnd.sha)) {
                        ShieldStats.blocked++
                        head = L.t("Threat blocked and quarantined", "হুমকি আটকে কোয়ারেন্টিনে রাখা হয়েছে")
                        text += "\n" + L.t("Moved out of your folders. Review it in Shields > Quarantine.", "আপনার ফোল্ডার থেকে সরানো হয়েছে। Shields > Quarantine-এ দেখুন।")
                    }
                    Alerts.notify(app, head, text)
                }
            } catch (e: Exception) { }
        }.start()
    }

    override fun onDestroy() {
        alive = false
        h.removeCallbacks(tick)
        observers.forEach { it.stopWatching() }
        observers.clear()
        pkgReceiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        super.onDestroy()
    }
}

// অ্যাপের সন্দেহজনক আচরণ ধরা: নতুন করে Accessibility, নোটিফিকেশন-পড়া, ডিভাইস অ্যাডমিন বা ডিফল্ট SMS অ্যাপ হওয়া
object BehaviorShield {
    private fun appName(ctx: Context, pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun isSys(ctx: Context, pkg: String): Boolean = try {
        (ctx.packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) != 0
    } catch (e: Exception) { true }

    private fun diff(ctx: Context, key: String, now: Set<String>, msg: String) {
        val first = Store.get(ctx, key, "#") == "#"
        val old = if (first) emptySet() else Store.get(ctx, key).split("|").filter { it.isNotEmpty() }.toSet()
        if (!first) now.filter { it !in old && it != ctx.packageName && !isSys(ctx, it) }.forEach { pkg ->
            Alerts.notify(ctx, L.t("Behavior Shield warning", "বিহেভিয়র শিল্ড সতর্কতা"), appName(ctx, pkg) + ": " + msg)
        }
        Store.put(ctx, key, now.joinToString("|"))
    }

    private fun pkgs(s: String?): Set<String> =
        (s ?: "").split(":").filter { it.contains("/") }.map { it.substringBefore("/") }.toSet()

    fun poll(ctx: Context) {
        if (!Store.on(ctx, "beh_on", true)) return
        val cr = ctx.contentResolver
        diff(ctx, "snap_acc", pkgs(Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)),
            L.t("just got Accessibility access (can see and control your screen)", "এইমাত্র Accessibility অ্যাক্সেস পেয়েছে (স্ক্রিন দেখতে ও চালাতে পারে)"))
        diff(ctx, "snap_nl", pkgs(Settings.Secure.getString(cr, "enabled_notification_listeners")),
            L.t("can now read all your notifications", "এখন আপনার সব নোটিফিকেশন পড়তে পারে"))
        val adm = try {
            (ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).activeAdmins?.map { it.packageName }?.toSet() ?: emptySet()
        } catch (e: Exception) { emptySet() }
        diff(ctx, "snap_adm", adm, L.t("became a device administrator", "ডিভাইস অ্যাডমিন হয়েছে"))
        val sms = try { Telephony.Sms.getDefaultSmsPackage(ctx) } catch (e: Exception) { null }
        diff(ctx, "snap_sms", if (sms == null) emptySet() else setOf(sms), L.t("became your default SMS app", "আপনার ডিফল্ট SMS অ্যাপ হয়েছে"))
    }
}

// শিডিউল স্ক্যান
object Scheduler {
    fun nextAfter(ctx: Context, from: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = from
        cal.set(Calendar.HOUR_OF_DAY, Store.long(ctx, "sch_h", 9).toInt())
        cal.set(Calendar.MINUTE, Store.long(ctx, "sch_m", 0).toInt())
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (Store.get(ctx, "sch_freq", "daily") == "weekly") {
            cal.set(Calendar.DAY_OF_WEEK, Store.long(ctx, "sch_dow", Calendar.FRIDAY.toLong()).toInt())
            while (cal.timeInMillis <= from) cal.add(Calendar.DAY_OF_YEAR, 7)
        } else {
            while (cal.timeInMillis <= from) cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    fun reschedule(ctx: Context) = Store.put(ctx, "sch_next", nextAfter(ctx, System.currentTimeMillis()).toString())

    fun runIfDue(ctx: Context) {
        if (!Store.on(ctx, "sch_on", false)) return
        val next = Store.long(ctx, "sch_next", 0L)
        if (next == 0L) { reschedule(ctx); return }
        if (System.currentTimeMillis() < next) return
        reschedule(ctx)
        if (ScanState.running) return
        if (!ScanState.start(ctx, Store.get(ctx, "sch_type", "quick"))) {
            Alerts.notify(ctx, L.t("Scheduled scan is due", "শিডিউল স্ক্যানের সময় হয়েছে"), L.t("Open the app to run it", "অ্যাপ খুলে চালান"))
        }
    }
}

package com.rifat.guard

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.URL
import java.security.cert.X509Certificate
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import javax.net.ssl.HttpsURLConnection

data class WifiReport(
    val connected: Boolean, val ssid: String, val bssid: String, val security: String, val rssi: Int, val speed: Int,
    val ip: String, val gateway: String, val dns: List<String>, val warnings: List<String>, val good: List<String>, val needLocation: Boolean
)

data class NetCheck(val ok: Boolean, val text: String)

object WifiSec {
    private val knownDns = setOf(
        "8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1", "1.1.1.2", "1.1.1.3", "9.9.9.9", "149.112.112.112",
        "208.67.222.222", "208.67.220.220", "94.140.14.14", "94.140.15.15"
    )

    private fun isPrivate(ip: String): Boolean {
        val p = ip.split(".").mapNotNull { it.toIntOrNull() }
        if (p.size != 4) return ip.startsWith("fe80") || ip.startsWith("fd") || ip.startsWith("fc")
        return p[0] == 10 || (p[0] == 172 && p[1] in 16..31) || (p[0] == 192 && p[1] == 168) || (p[0] == 100 && p[1] in 64..127) || p[0] == 169
    }

    @Suppress("DEPRECATION")
    private fun secFromScan(wm: WifiManager, bssid: String): String {
        val c = try { wm.scanResults.firstOrNull { it.BSSID.equals(bssid, true) }?.capabilities } catch (e: Exception) { null } ?: return "Unknown"
        return when {
            c.contains("WEP") -> "WEP"
            c.contains("SAE") -> "WPA3"
            c.contains("WPA") -> "WPA/WPA2"
            c.contains("EAP") -> "Enterprise"
            else -> "Open"
        }
    }

    @Suppress("DEPRECATION")
    fun inspect(ctx: Context): WifiReport {
        val empty = WifiReport(false, "", "", "", 0, 0, "", "", emptyList(), emptyList(), emptyList(), false)
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val net = cm.activeNetwork ?: return empty
        val caps = cm.getNetworkCapabilities(net)
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) != true) return empty
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val hasLoc = ctx.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0
        var ssid = info?.ssid?.trim('"') ?: ""
        if (ssid == "<unknown ssid>") ssid = ""
        val bssid = info?.bssid ?: ""
        val sec = if (Build.VERSION.SDK_INT >= 31 && info != null) {
            when (info.currentSecurityType) {
                WifiInfo.SECURITY_TYPE_OPEN -> "Open"
                WifiInfo.SECURITY_TYPE_WEP -> "WEP"
                WifiInfo.SECURITY_TYPE_PSK -> "WPA/WPA2"
                WifiInfo.SECURITY_TYPE_SAE -> "WPA3"
                WifiInfo.SECURITY_TYPE_EAP -> "Enterprise"
                WifiInfo.SECURITY_TYPE_OWE -> "OWE"
                else -> "Unknown"
            }
        } else secFromScan(wm, bssid)

        val lp = cm.getLinkProperties(net)
        val ip = lp?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.address?.hostAddress ?: ""
        val gw = lp?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress ?: ""
        val dns = lp?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()

        val warn = ArrayList<String>()
        val good = ArrayList<String>()
        when (sec) {
            "Open" -> warn += L.t("Open network: anyone nearby can read what you send. Avoid logins and payments here.", "খোলা নেটওয়ার্ক: আশেপাশের যে কেউ আপনার ডাটা দেখতে পারে। এখানে লগইন বা পেমেন্ট করবেন না।")
            "WEP" -> warn += L.t("WEP encryption is broken and can be cracked in minutes.", "WEP এনক্রিপশন ভাঙা, কয়েক মিনিটেই খোলা যায়।")
            "WPA/WPA2" -> good += L.t("Encrypted with WPA/WPA2.", "WPA/WPA2 দিয়ে এনক্রিপ্টেড।")
            "WPA3", "OWE", "Enterprise" -> good += L.t("Strong encryption ($sec).", "শক্তিশালী এনক্রিপশন ($sec)।")
        }
        val odd = dns.filter { !isPrivate(it) && it !in knownDns }
        if (odd.isNotEmpty()) warn += L.t("Unusual DNS server: ${odd.joinToString()}. A bad DNS can send you to fake sites.", "অচেনা DNS সার্ভার: ${odd.joinToString()}। খারাপ DNS নকল সাইটে পাঠাতে পারে।")
        else if (dns.isNotEmpty()) good += L.t("DNS servers look normal.", "DNS সার্ভার স্বাভাবিক দেখাচ্ছে।")
        if (Build.VERSION.SDK_INT >= 29 && lp?.isPrivateDnsActive == true) good += L.t("Private DNS (encrypted) is on.", "Private DNS (এনক্রিপ্টেড) চালু আছে।")

        // আগের বার একই নেটওয়ার্কে কী ছিল তার সাথে তুলনা
        val key = (if (ssid.isNotEmpty()) ssid else bssid).ifEmpty { "wifi" }
        val nowDns = dns.sorted().joinToString(",")
        val oldDns = Store.get(ctx, "wifi_dns_$key")
        val oldGw = Store.get(ctx, "wifi_gw_$key")
        if (oldDns.isNotEmpty() && oldDns != nowDns) warn += L.t("DNS servers changed since your last visit to this network.", "এই নেটওয়ার্কে আগের বারের চেয়ে DNS বদলে গেছে।")
        if (oldGw.isNotEmpty() && gw.isNotEmpty() && oldGw != gw) warn += L.t("The router address changed since your last visit. Possible fake hotspot.", "রাউটারের ঠিকানা আগের বারের চেয়ে বদলেছে। নকল হটস্পট হতে পারে।")
        if (nowDns.isNotEmpty()) Store.put(ctx, "wifi_dns_$key", nowDns)
        if (gw.isNotEmpty()) Store.put(ctx, "wifi_gw_$key", gw)

        return WifiReport(true, ssid, bssid, sec, info?.rssi ?: 0, info?.linkSpeed ?: 0, ip, gw, dns, warn, good, !hasLoc || ssid.isEmpty())
    }

    // ইন্টারনেট দিয়ে গভীর পরীক্ষা
    fun deepCheck(): List<NetCheck> {
        val out = ArrayList<NetCheck>()
        try {
            val c = URL("https://www.google.com/generate_204").openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false; c.connectTimeout = 6000; c.readTimeout = 6000
            val code = c.responseCode
            c.disconnect()
            out += if (code == 204) NetCheck(true, L.t("Internet works, no login page in the way.", "ইন্টারনেট ঠিক আছে, মাঝে কোনো লগইন পেজ নেই।"))
            else NetCheck(false, L.t("Got an unexpected reply (code $code). This network may redirect you to a login or fake page.", "অপ্রত্যাশিত উত্তর (কোড $code)। নেটওয়ার্ক আপনাকে লগইন বা নকল পেজে পাঠাচ্ছে হতে পারে।"))
        } catch (e: Exception) { out += NetCheck(false, L.t("Could not reach the internet.", "ইন্টারনেটে পৌঁছানো যায়নি।")) }
        try {
            val c = URL("https://www.google.com").openConnection() as HttpsURLConnection
            c.connectTimeout = 6000; c.readTimeout = 6000
            c.connect()
            val issuer = (c.serverCertificates.firstOrNull() as? X509Certificate)?.issuerX500Principal?.name ?: ""
            c.disconnect()
            out += if (issuer.contains("Google", true) || issuer.contains("GTS", true)) NetCheck(true, L.t("Secure connection looks genuine (no snooping detected).", "নিরাপদ সংযোগ আসল দেখাচ্ছে (আড়ি পাতা ধরা পড়েনি)।"))
            else NetCheck(false, L.t("The secure certificate for google.com looks unusual. Someone may be intercepting traffic.", "google.com এর নিরাপত্তা সার্টিফিকেট অস্বাভাবিক। কেউ ট্রাফিকে আড়ি পাতছে হতে পারে।"))
        } catch (e: Exception) { out += NetCheck(false, L.t("Secure connection test failed.", "নিরাপদ সংযোগের পরীক্ষা ব্যর্থ।")) }
        try {
            val a = InetAddress.getAllByName("one.one.one.one").map { it.hostAddress }
            out += if (a.any { it == "1.1.1.1" || it == "1.0.0.1" }) NetCheck(true, L.t("DNS answers look honest.", "DNS এর উত্তর সৎ দেখাচ্ছে।"))
            else NetCheck(false, L.t("DNS gave a wrong answer for a known name. The network may be tampering with DNS.", "পরিচিত নামের জন্য DNS ভুল উত্তর দিয়েছে। নেটওয়ার্ক DNS নিয়ে কারসাজি করছে হতে পারে।"))
        } catch (e: Exception) { out += NetCheck(false, L.t("DNS test failed.", "DNS পরীক্ষা ব্যর্থ।")) }
        return out
    }

    // একই নেটওয়ার্কে থাকা ডিভাইস (আনুমানিক)
    fun findDevices(ip: String): List<String> {
        if (!ip.contains(".")) return emptyList()
        val prefix = ip.substringBeforeLast('.')
        val pool = Executors.newFixedThreadPool(40)
        try {
            val tasks = (1..254).map { n -> Callable { val a = "$prefix.$n"; try { if (InetAddress.getByName(a).isReachable(350)) a else null } catch (e: Exception) { null } } }
            return pool.invokeAll(tasks).mapNotNull { try { it.get() } catch (e: Exception) { null } }.sortedBy { it.substringAfterLast('.').toInt() }
        } finally { pool.shutdownNow() }
    }
}

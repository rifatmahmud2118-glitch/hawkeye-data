package com.rifat.guard

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------- চুরি-বিরোধী ----------------
@Composable
fun TheftScreen() {
    val ctx = LocalContext.current
    val tick = resumeTick()
    var on by remember { mutableStateOf(Theft.enabled(ctx)) }
    var code by remember { mutableStateOf(Theft.code(ctx)) }
    var num by remember { mutableStateOf(Theft.num(ctx)) }
    var msg by remember { mutableStateOf("") }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    val smsOk = remember(tick) { ctx.checkSelfPermission("android.permission.SEND_SMS") == 0 && Perms.sms(ctx) }
    val phoneOk = remember(tick) { ctx.checkSelfPermission("android.permission.READ_PHONE_STATE") == 0 }
    val locOk = remember(tick) { ctx.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0 }
    val bgOk = remember(tick) { Build.VERSION.SDK_INT < 29 || ctx.checkSelfPermission("android.permission.ACCESS_BACKGROUND_LOCATION") == 0 }
    val adminOk = remember(tick) { Theft.adminActive(ctx) }
    Page {
        GCard {
            SettingRow(Icons.Filled.PhonelinkLock, L.t("Anti-theft by SMS", "SMS দিয়ে চুরি-বিরোধী সুরক্ষা"),
                L.t("Find, ring or lock your phone by sending it a secret SMS", "গোপন SMS পাঠিয়ে ফোন খোঁজা, বাজানো বা লক করা"), on) {
                if (it && code.length < 6) msg = L.t("Save a secret code of 6 or more characters first.", "আগে ৬ বা তার বেশি অক্ষরের গোপন কোড সংরক্ষণ করুন।")
                else { on = it; Store.setOn(ctx, "theft_on", it); if (it) Theft.saveSim(ctx); GuardService.refresh(ctx); msg = "" }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)
        }
        GCard {
            H(L.t("Secret code", "গোপন কোড"))
            OutlinedTextField(code, { code = it.filter { c -> !c.isWhitespace() } }, Modifier.fillMaxWidth(), singleLine = true,
                visualTransformation = PasswordVisualTransformation(), label = { Text(L.t("Secret code (6+ characters)", "গোপন কোড (৬+ অক্ষর)")) })
            H(L.t("Trusted number (gets SIM change alerts)", "বিশ্বস্ত নম্বর (সিম বদলের খবর পাবে)"))
            OutlinedTextField(num, { num = it }, Modifier.fillMaxWidth(), singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), label = { Text(L.t("e.g. +8801XXXXXXXXX", "যেমন +8801XXXXXXXXX")) })
            BigButton(L.t("Save", "সংরক্ষণ"), Icons.Filled.Lock, outlined = true) {
                Store.put(ctx, "theft_code", code.trim()); Store.put(ctx, "theft_num", num.trim())
                msg = L.t("Saved.", "সংরক্ষিত হয়েছে।")
            }
        }
        SectionLabel(L.t("Permissions it needs", "যে অনুমতি লাগবে"))
        GCard {
            PermRow(smsOk && phoneOk, L.t("SMS and phone state", "SMS ও ফোনের অবস্থা")) { perm.launch(arrayOf("android.permission.SEND_SMS", "android.permission.RECEIVE_SMS", "android.permission.READ_PHONE_STATE")) }
            PermRow(locOk, L.t("Location", "লোকেশন")) { perm.launch(arrayOf("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION")) }
            PermRow(bgOk, L.t("Location: Allow all the time", "লোকেশন: সব সময় অনুমতি")) {
                Perms.open(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }
            PermRow(adminOk, L.t("Device admin (for remote lock)", "ডিভাইস অ্যাডমিন (দূর থেকে লকের জন্য)")) { Perms.open(ctx, Theft.adminIntent(ctx)) }
            PermRow(Perms.battery(ctx), L.t("Unrestricted battery", "ব্যাটারি সীমাহীন")) { Perms.open(ctx, Perms.batteryIntent(ctx)) }
        }
        SectionLabel(L.t("Automatic guards", "নিজে-নিজে পাহারা"))
        GCard {
            var armedNow by remember { mutableStateOf(Guard.armed(ctx)) }
            SettingRow(Icons.Filled.Security, L.t("Arm the guard", "পাহারা চালু (আর্ম)"),
                L.t("When armed, moving the phone, unplugging the charger or removing the SIM sets off the alarm and texts you.", "আর্ম থাকলে ফোন নাড়ালে, চার্জার খুললে বা সিম খুললে অ্যালার্ম বাজে ও আপনাকে SMS যায়।"), armedNow) {
                armedNow = it; Theft.arm(ctx, it)
            }
            StoreToggle(Icons.Filled.Bolt, L.t("Charger unplug alarm", "চার্জার খোলার অ্যালার্ম"), "", "g_charger", true)
            StoreToggle(Icons.Filled.Security, L.t("Motion alarm", "নড়াচড়ার অ্যালার্ম"), L.t("Starts 15 seconds after arming", "আর্ম করার ১৫ সেকেন্ড পর শুরু"), "g_motion", true)
            StoreToggle(Icons.Filled.Phone, L.t("SIM removed alarm", "সিম খোলার অ্যালার্ম"), "", "g_simabs", true)
            StoreToggle(Icons.Filled.Warning, L.t("Airplane mode alarm", "এয়ারপ্লেন মোডের অ্যালার্ম"), L.t("Rings if airplane mode is turned on while armed or lost", "আর্ম বা হারানো মোডে এয়ারপ্লেন চালু হলে বাজে"), "g_air", true)
            StoreToggle(Icons.Filled.Notifications, L.t("Low-battery location report", "ব্যাটারি কমলে লোকেশন পাঠানো"), L.t("Texts the last location when the battery gets very low", "ব্যাটারি খুব কমলে শেষ লোকেশন SMS করে"), "g_battlow", true)
        }
        GCard {
            var wrong by remember { mutableStateOf(Store.get(ctx, "g_wrong", "3")) }
            H(L.t("Wrong unlock attempts", "ভুল আনলক চেষ্টা"))
            Hint(L.t("Texts you after this many wrong PIN or pattern tries. Turn Device admin off and on once after this update so Android allows it.", "এতবার ভুল পিন বা প্যাটার্ন দিলে আপনাকে SMS করে। এই আপডেটের পর ডিভাইস অ্যাডমিন একবার বন্ধ করে আবার চালু করুন, তাহলে Android অনুমতি দেবে।"))
            ChoiceRow(listOf("0" to L.t("Off", "বন্ধ"), "3" to "3", "5" to "5", "10" to "10"), wrong) { wrong = it; Store.put(ctx, "g_wrong", it) }
        }
        GCard {
            val scope = rememberCoroutineScope()
            var radius by remember { mutableStateOf(Store.get(ctx, "g_home_r", "300")) }
            var homeMsg by remember { mutableStateOf(if (Store.get(ctx, "g_home_lat").isNotEmpty()) L.t("Home saved", "ঘর সংরক্ষিত") else L.t("Home not set", "ঘর সেট করা হয়নি")) }
            StoreToggle(Icons.Filled.Home, L.t("Home zone alert", "ঘরের এলাকা ছাড়লে সতর্কতা"), L.t("When armed, texts you if the phone leaves the zone", "আর্ম থাকলে ফোন এলাকা ছাড়লে SMS করে"), "g_home_on", false)
            ChoiceRow(listOf("100" to "100 m", "300" to "300 m", "1000" to "1 km"), radius) { radius = it; Store.put(ctx, "g_home_r", it) }
            BigButton(L.t("Save current location as home", "এখনকার লোকেশন ঘর হিসেবে সংরক্ষণ"), Icons.Filled.Home, outlined = true) {
                homeMsg = L.t("Getting location…", "লোকেশন নেওয়া হচ্ছে…")
                scope.launch(Dispatchers.IO) {
                    val ok = Theft.setHome(ctx)
                    withContext(Dispatchers.Main) { homeMsg = if (ok) L.t("Home saved", "ঘর সংরক্ষিত") else L.t("Could not get location. Turn on GPS and allow location.", "লোকেশন পাওয়া যায়নি। GPS চালু করে অনুমতি দিন।") }
                }
            }
            Hint(homeMsg)
        }
        GCard {
            var lostMsg by remember { mutableStateOf(Store.get(ctx, "g_lost_msg")) }
            H(L.t("Lost-phone message", "হারানো ফোনের বার্তা"))
            OutlinedTextField(lostMsg, { lostMsg = it }, Modifier.fillMaxWidth(), label = { Text(L.t("Shown on the lock screen in lost mode", "হারানো মোডে লক স্ক্রিনে দেখাবে")) })
            BigButton(L.t("Save message", "বার্তা সংরক্ষণ"), Icons.Filled.Lock, outlined = true) { Store.put(ctx, "g_lost_msg", lostMsg.trim()) }
        }
        SectionLabel(L.t("Commands (send from another phone)", "কমান্ড (অন্য ফোন থেকে পাঠান)"))
        GCard {
            Text("HAWK <${L.t("code", "কোড")}> RING", style = MaterialTheme.typography.titleSmall)
            Hint(L.t("Plays a loud alarm for 2 minutes, even if the phone is on silent.", "ফোন সাইলেন্ট থাকলেও ২ মিনিট জোরে অ্যালার্ম বাজায়।"))
            Text("HAWK <${L.t("code", "কোড")}> STOP", style = MaterialTheme.typography.titleSmall)
            Hint(L.t("Stops the alarm.", "অ্যালার্ম থামায়।"))
            Text("HAWK <${L.t("code", "কোড")}> LOCATE", style = MaterialTheme.typography.titleSmall)
            Hint(L.t("Replies with a Google Maps link of where the phone is.", "ফোন কোথায় আছে তার Google Maps লিংক SMS-এ ফেরত দেয়।"))
            Text("HAWK <${L.t("code", "কোড")}> LOCK", style = MaterialTheme.typography.titleSmall)
            Hint(L.t("Locks the screen. Needs Device admin.", "স্ক্রিন লক করে। ডিভাইস অ্যাডমিন লাগে।"))
            Text("HAWK <${L.t("code", "কোড")}> INFO", style = MaterialTheme.typography.titleSmall)
            Hint(L.t("Replies with battery level and phone model.", "ব্যাটারি কত আর ফোনের মডেল জানায়।"))
        }
        GCard {
            H(L.t("More commands", "আরও কমান্ড"))
            listOf(
                "STATUS" to L.t("Battery, network, GPS, lock state and last location.", "ব্যাটারি, নেটওয়ার্ক, GPS, লকের অবস্থা ও শেষ লোকেশন।"),
                "PING" to L.t("Replies if the phone is online.", "ফোন অনলাইনে থাকলে উত্তর দেয়।"),
                "FLASH" to L.t("Blinks the flashlight so you can spot the phone in the dark.", "ফ্ল্যাশলাইট জ্বালিয়ে-নিভিয়ে অন্ধকারে ফোন খুঁজতে সাহায্য করে।"),
                "TRACK 6" to L.t("Texts the location every 10 minutes for 6 hours (1 to 72).", "৬ ঘণ্টা ধরে প্রতি ১০ মিনিটে লোকেশন SMS করে (১ থেকে ৭২)।"),
                "UNTRACK" to L.t("Stops tracking.", "ট্র্যাকিং বন্ধ করে।"),
                "LOST your message" to L.t("Lost mode: shows your message on the lock screen, rings, blinks and tracks for 24 hours.", "হারানো মোড: লক স্ক্রিনে বার্তা, অ্যালার্ম, ফ্ল্যাশ ও ২৪ ঘণ্টা ট্র্যাকিং।"),
                "FOUND" to L.t("Ends lost mode.", "হারানো মোড শেষ করে।"),
                "ARM" to L.t("Arms the guard remotely.", "দূর থেকে পাহারা চালু করে।"),
                "DISARM" to L.t("Disarms the guard.", "পাহারা বন্ধ করে।"),
                "HELP" to L.t("Lists all commands.", "সব কমান্ডের তালিকা পাঠায়।")
            ).forEach { (c, d) ->
                Text("HAWK <${L.t("code", "কোড")}> $c", style = MaterialTheme.typography.titleSmall)
                Hint(d)
            }
        }
        GCard {
            BigButton(L.t("Test the alarm", "অ্যালার্ম পরীক্ষা"), Icons.Filled.NotificationsActive) { Theft.ring(ctx) }
            BigButton(L.t("Stop the alarm", "অ্যালার্ম থামান"), Icons.Filled.NotificationsOff, outlined = true) { Theft.stopRing(ctx) }
        }
        GCard {
            H(L.t("Limits you should know", "যে সীমাগুলো জানা দরকার"))
            Hint(L.t("It cannot work if the phone is switched off, has no signal or SIM, or was factory reset. Phone makers may stop background apps, so allow unrestricted battery. Google Find My Device is free and works better when the phone is online. Use this as an extra layer.",
                "ফোন বন্ধ, নেটওয়ার্ক বা সিম না থাকলে, বা ফ্যাক্টরি রিসেট করলে কাজ করবে না। কিছু ফোন ব্যাকগ্রাউন্ড অ্যাপ বন্ধ করে দেয়, তাই ব্যাটারি সীমাহীন করে দিন। Google Find My Device ফ্রি, ফোন অনলাইনে থাকলে ভালো কাজ করে। এটাকে বাড়তি স্তর হিসেবে রাখুন।"))
        }
    }
}

// ---------------- ওয়াইফাই নিরাপত্তা ----------------
@Composable
fun WifiScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = resumeTick()
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    val rep = remember(tick) { try { WifiSec.inspect(ctx) } catch (e: Exception) { null } }
    var checks by remember { mutableStateOf<List<NetCheck>>(emptyList()) }
    var devices by remember { mutableStateOf<List<String>?>(null) }
    var busy by remember { mutableStateOf(false) }
    Page {
        if (rep == null || !rep.connected) {
            Hint(L.t("You are not connected to Wi-Fi. Connect to a network to check it.", "আপনি ওয়াইফাইতে যুক্ত নন। পরীক্ষা করতে একটা নেটওয়ার্কে যুক্ত হন।"))
            return@Page
        }
        if (rep.needLocation) PermRow(false, L.t("Location (Android needs it to show the Wi-Fi name)", "লোকেশন (Android ওয়াইফাইয়ের নাম দেখাতে এটা চায়)")) {
            perm.launch(arrayOf("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"))
        }
        GCard {
            H(L.t("This network", "এই নেটওয়ার্ক"))
            TRow(L.t("Name", "নাম"), if (rep.ssid.isNotEmpty()) rep.ssid else L.t("Hidden until location is allowed", "লোকেশনের অনুমতি না দেওয়া পর্যন্ত লুকানো"))
            TRow(L.t("Security", "নিরাপত্তা"), rep.security)
            TRow(L.t("Signal", "সিগন্যাল"), "${rep.rssi} dBm")
            TRow(L.t("Link speed", "গতি"), "${rep.speed} Mbps")
            TRow(L.t("Your address", "আপনার ঠিকানা"), rep.ip.ifEmpty { "-" })
            TRow(L.t("Router address", "রাউটারের ঠিকানা"), rep.gateway.ifEmpty { "-" })
            TRow("DNS", if (rep.dns.isEmpty()) "-" else rep.dns.joinToString(", "))
        }
        if (rep.warnings.isNotEmpty() || rep.good.isNotEmpty()) GCard {
            H(L.t("Result", "ফলাফল"))
            rep.warnings.forEach { Text("⚠  $it", color = MaterialTheme.colorScheme.error) }
            rep.good.forEach { Text("✓  $it") }
        }
        GCard {
            BigButton(if (busy) L.t("Checking…", "পরীক্ষা চলছে…") else L.t("Deep check (uses internet)", "গভীর পরীক্ষা (ইন্টারনেট লাগে)"), Icons.Filled.Security, enabled = !busy) {
                busy = true; checks = emptyList()
                scope.launch(Dispatchers.IO) {
                    val r = try { WifiSec.deepCheck() } catch (e: Exception) { emptyList<NetCheck>() }
                    withContext(Dispatchers.Main) { checks = r; busy = false }
                }
            }
            checks.forEach { Text((if (it.ok) "✓  " else "⚠  ") + it.text, color = if (it.ok) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error) }
            BigButton(if (busy) L.t("Looking…", "খোঁজা হচ্ছে…") else L.t("Find devices on this network", "এই নেটওয়ার্কের ডিভাইস খুঁজুন"), Icons.Filled.Router, enabled = !busy, outlined = true) {
                busy = true; devices = null
                val ip = rep.ip
                scope.launch(Dispatchers.IO) {
                    val d = try { WifiSec.findDevices(ip) } catch (e: Exception) { emptyList() }
                    withContext(Dispatchers.Main) { devices = d; busy = false }
                }
            }
            devices?.let { d ->
                Text(L.t("${d.size} devices answered", "${d.size}টি ডিভাইস সাড়া দিয়েছে"), style = MaterialTheme.typography.titleSmall)
                d.forEach { Hint(it + (if (it == rep.ip) "  (" + L.t("this phone", "এই ফোন") + ")" else if (it == rep.gateway) "  (" + L.t("router", "রাউটার") + ")" else "")) }
                Hint(L.t("Some devices hide from this test, so the list may be shorter than reality. Unknown ones are worth a look.", "কিছু ডিভাইস এই পরীক্ষায় ধরা পড়ে না, তাই তালিকা আসলের চেয়ে ছোট হতে পারে। অচেনা কিছু থাকলে খেয়াল করুন।"))
            }
        }
    }
}

// ---------------- DNS শিল্ড (VPN) ----------------
@Composable
fun VpnScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var prov by remember { mutableStateOf(Store.get(ctx, "vpn_prov", "adguard")) }
    var count by remember { mutableStateOf(BlockList.count(ctx)) }
    var adCount by remember { mutableStateOf(BlockList.adCount(ctx)) }
    var last by remember { mutableStateOf(Store.long(ctx, "blocklist_updated", 0)) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) DnsVpnService.start(ctx)
    }
    fun restart() { if (VpnState.running) { DnsVpnService.stop(ctx); DnsVpnService.start(ctx) } }
    Page {
        GCard {
            SettingRow(Icons.Filled.VpnKey, L.t("Private DNS Shield", "প্রাইভেট DNS শিল্ড"),
                L.t("Blocks bad sites and ads in every app, and hides the site names you look up from your internet provider.", "সব অ্যাপে ক্ষতিকর সাইট ও বিজ্ঞাপন আটকায়, আর আপনি কোন সাইটের নাম খুঁজছেন তা ইন্টারনেট সেবাদাতার কাছ থেকে লুকায়।"), VpnState.running) { want ->
                if (want) {
                    val i = VpnService.prepare(ctx)
                    if (i != null) launcher.launch(i) else DnsVpnService.start(ctx)
                } else DnsVpnService.stop(ctx)
            }
            TRow(L.t("Sites checked", "যাচাই করা সাইট"), "${VpnState.total}")
            TRow(L.t("Malware and phishing blocked", "ম্যালওয়্যার ও ফিশিং আটকানো"), "${VpnState.blocked}")
            TRow(L.t("Ads and trackers blocked", "বিজ্ঞাপন ও ট্র্যাকার আটকানো"), "${VpnState.ads}")
            TRow(L.t("Answered from memory (faster)", "মনে রাখা উত্তর (দ্রুত)"), "${VpnState.cached}")
            TRow(L.t("Encrypted lookups", "এনক্রিপ্টেড অনুসন্ধান"), "${VpnState.encrypted}")
            if (VpnState.fallback > 0) TRow(L.t("Plain lookups (not hidden)", "সাধারণ অনুসন্ধান (লুকানো নয়)"), "${VpnState.fallback}")
            if (VpnState.last.isNotEmpty()) TRow(L.t("Last blocked", "সর্বশেষ আটকানো"), VpnState.last)
        }
        GCard {
            H(L.t("DNS provider", "DNS সেবাদাতা"))
            ChoiceRow(listOf("adguard" to "AdGuard", "cf" to "Cloudflare", "quad9" to "Quad9"), prov) { prov = it; Store.put(ctx, "vpn_prov", it); restart() }
            Hint(when (prov) {
                "cf" -> L.t("Cloudflare Security: blocks malware and phishing. Does not block ads.", "Cloudflare Security: ম্যালওয়্যার ও ফিশিং আটকায়। বিজ্ঞাপন আটকায় না।")
                "quad9" -> L.t("Quad9: blocks malware and phishing, strong privacy rules. Does not block ads.", "Quad9: ম্যালওয়্যার ও ফিশিং আটকায়, গোপনীয়তার নিয়ম ভালো। বিজ্ঞাপন আটকায় না।")
                else -> L.t("AdGuard: blocks ads, trackers, malware and phishing. Best all-round choice.", "AdGuard: বিজ্ঞাপন, ট্র্যাকার, ম্যালওয়্যার ও ফিশিং আটকায়। সবচেয়ে ভালো সব-মিলিয়ে পছন্দ।")
            })
        }
        GCard {
            StoreToggle(Icons.Filled.Lock, L.t("Encrypted DNS", "এনক্রিপ্টেড DNS"), L.t("Sends lookups through an encrypted tunnel (DNS-over-TLS) so your provider cannot read them", "অনুসন্ধান এনক্রিপ্টেড লাইনে পাঠায় (DNS-over-TLS), তাই সেবাদাতা পড়তে পারে না"), "vpn_dot", true) { restart() }
            StoreToggle(Icons.Filled.Warning, L.t("Strict privacy", "কড়া গোপনীয়তা"), L.t("If encryption fails, do not use plain DNS. Some sites may not open on networks that block it.", "এনক্রিপশন ব্যর্থ হলে সাধারণ DNS ব্যবহার করবে না। যেসব নেটওয়ার্ক এটা আটকায় সেখানে কিছু সাইট খুলবে না।"), "vpn_strict", false)
            StoreToggle(Icons.Filled.Security, L.t("Block malware and phishing sites", "ম্যালওয়্যার ও ফিশিং সাইট আটকান"), "", "vpn_sec", true)
            StoreToggle(Icons.Filled.NotificationsOff, L.t("Block ads and trackers", "বিজ্ঞাপন ও ট্র্যাকার আটকান"), L.t("Works in browsers and inside apps", "ব্রাউজার ও অ্যাপের ভেতরে কাজ করে"), "vpn_ads", true)
        }
        GCard {
            H(L.t("Block lists", "আটকানোর তালিকা"))
            TRow(L.t("Bad sites", "ক্ষতিকর সাইট"), "$count")
            TRow(L.t("Ad and tracker sites", "বিজ্ঞাপন ও ট্র্যাকার সাইট"), "$adCount")
            TRow(L.t("Last updated", "সর্বশেষ আপডেট"), if (last > 0) fmtDate(last) else L.t("Never", "কখনও না"))
            BigButton(if (busy) L.t("Updating…", "আপডেট চলছে…") else L.t("Update lists", "তালিকা আপডেট"), Icons.Filled.Update, enabled = !busy) {
                busy = true; msg = ""
                scope.launch(Dispatchers.IO) {
                    val r = BlockList.update(ctx)
                    withContext(Dispatchers.Main) { msg = r; count = BlockList.count(ctx); adCount = BlockList.adCount(ctx); last = Store.long(ctx, "blocklist_updated", 0); busy = false }
                }
            }
            if (msg.isNotEmpty()) Text(msg)
            Hint(L.t("Sources: URLhaus and OpenPhish for bad sites, StevenBlack for ads. All free, no key.", "উৎস: ক্ষতিকর সাইটের জন্য URLhaus ও OpenPhish, বিজ্ঞাপনের জন্য StevenBlack। সবই ফ্রি, key লাগে না।"))
        }
        GCard {
            H(L.t("What it can and cannot do", "কী পারে, কী পারে না"))
            Hint(L.t("Can: block bad sites and most ads in all apps, hide DNS lookups from your internet provider, answer repeat lookups faster from memory.\n\nCannot: hide the addresses (IPs) you connect to. Your provider can still see those, and often the site name in the connection start. To hide everything you need a real VPN app (for example Proton VPN free). Android runs only one VPN at a time, so turn this off while that one is on.\n\nAlso cannot remove ads that come from the same address as the content, such as YouTube video ads.",
                "পারে: সব অ্যাপে ক্ষতিকর সাইট ও বেশিরভাগ বিজ্ঞাপন আটকাতে, ইন্টারনেট সেবাদাতার কাছ থেকে DNS অনুসন্ধান লুকাতে, বারবার খোঁজা সাইট মেমরি থেকে দ্রুত দিতে।\n\nপারে না: আপনি কোন ঠিকানায় (IP) যুক্ত হচ্ছেন তা লুকাতে। সেবাদাতা ওটা দেখতে পায়, অনেক সময় সংযোগের শুরুতে সাইটের নামও দেখে। সব লুকাতে হলে আসল VPN অ্যাপ লাগবে (যেমন Proton VPN ফ্রি)। Android একসাথে একটাই VPN চালায়, তাই ওটা চালালে এটা বন্ধ রাখুন।\n\nআরও পারে না: মূল কনটেন্টের একই ঠিকানা থেকে আসা বিজ্ঞাপন সরাতে, যেমন YouTube ভিডিওর বিজ্ঞাপন।"))
        }
        GCard {
            H(L.t("Alternative: Android Private DNS", "বিকল্প: Android Private DNS"))
            Hint(L.t("Android 9+ can do encrypted DNS by itself and it works together with any VPN. In phone Settings find Private DNS, choose the hostname option and type:", "Android ৯+ নিজেই এনক্রিপ্টেড DNS চালাতে পারে, আর যেকোনো VPN-এর সাথে একসাথে চলে। ফোনের Settings-এ Private DNS খুঁজে hostname বাছুন ও লিখুন:"))
            Text("dns.adguard-dns.com", style = MaterialTheme.typography.titleSmall)
            BigButton(L.t("Open network settings", "নেটওয়ার্ক সেটিংস খুলুন"), Icons.Filled.Settings, outlined = true) {
                Perms.open(ctx, Intent(Settings.ACTION_WIRELESS_SETTINGS))
            }
        }
    }
}

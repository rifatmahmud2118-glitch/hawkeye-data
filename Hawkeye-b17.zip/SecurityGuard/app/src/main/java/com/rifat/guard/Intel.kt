package com.rifat.guard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.security.MessageDigest

data class VtResult(val status: String, val mal: Int, val sus: Int, val at: Long = System.currentTimeMillis()) {
    val level: Risk get() = when {
        mal >= 3 -> Risk.HIGH
        mal >= 1 || sus >= 3 -> Risk.MEDIUM
        else -> Risk.LOW
    }
    fun text(): String = when (status) {
        "bad" -> L.t("VirusTotal: flagged by $mal engines", "VirusTotal: $mal টি ইঞ্জিন ক্ষতিকর বলেছে")
        "clean" -> L.t("VirusTotal: clean", "VirusTotal: পরিষ্কার")
        "unknown" -> L.t("Not on VirusTotal (never submitted, this does not mean a virus)", "VirusTotal-এ নেই (কেউ আগে জমা দেয়নি, এটা ভাইরাস নয়)")
        "nokey" -> L.t("Add a VirusTotal key in Settings", "সেটিংসে VirusTotal key দিন")
        else -> L.t("Could not check, try later", "যাচাই করা গেল না, পরে চেষ্টা করুন")
    }
}

object VtStore { val map = androidx.compose.runtime.mutableStateMapOf<String, VtResult>() }

object VirusTotal {
    fun cached(ctx: Context, sha: String): VtResult? {
        val v = Store.get(ctx, "vt_$sha").split(",")
        if (v.size != 4) return null
        val at = v[3].toLongOrNull() ?: return null
        if (System.currentTimeMillis() - at > 24 * 3600 * 1000L) return null
        return VtResult(v[0], v[1].toInt(), v[2].toInt(), at)
    }

    // ফ্রি key-তে মিনিটে ৪টি। কলকারী ১৬ সেকেন্ড বিরতি দেবে
    fun fetch(ctx: Context, sha: String): VtResult {
        val key = Store.get(ctx, "vt_key")
        if (key.isBlank() || sha.isBlank()) return VtResult("nokey", 0, 0)
        return try {
            val (code, body) = Net.request("https://www.virustotal.com/api/v3/files/$sha", headers = mapOf("x-apikey" to key))
            val r = when (code) {
                200 -> {
                    val st = JSONObject(body).getJSONObject("data").getJSONObject("attributes").getJSONObject("last_analysis_stats")
                    val m = st.optInt("malicious"); val s = st.optInt("suspicious")
                    VtResult(if (m + s > 0) "bad" else "clean", m, s)
                }
                404 -> VtResult("unknown", 0, 0)
                else -> return VtResult("error", 0, 0)
            }
            Store.put(ctx, "vt_$sha", "${r.status},${r.mal},${r.sus},${r.at}")
            r
        } catch (e: Exception) { VtResult("error", 0, 0) }
    }
}

data class Report(val level: Risk, val reasons: List<String>)

object Inspector {
    private val urlRe = Regex("(?i)\\b(?:https?://|www\\.)[^\\s<>\"]+")
    private val shorteners = setOf("bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy", "shorturl.at", "ow.ly")
    private val badTlds = listOf(".xyz", ".top", ".click", ".icu", ".live", ".buzz", ".cfd", ".sbs", ".rest")
    private val brands = mapOf(
        "bkash" to listOf("bkash.com", "bka.sh"),
        "nagad" to listOf("nagad.com.bd"),
        "facebook" to listOf("facebook.com", "fb.com", "fb.me", "messenger.com"),
        "whatsapp" to listOf("whatsapp.com", "wa.me"),
        "telegram" to listOf("telegram.org", "t.me"),
        "paypal" to listOf("paypal.com"),
        "apple" to listOf("apple.com", "icloud.com"),
        "google" to listOf("google.com", "google.com.bd", "googleapis.com", "gstatic.com", "goo.gl", "g.co", "googleusercontent.com"),
    )

    fun analyze(ctx: Context, text: String): Report {
        var score = 0
        val reasons = mutableListOf<String>()
        val t = text.lowercase()
        if (Regex("otp|পিন|\\bpin\\b|কোড|code").containsMatchIn(t) && Regex("share|send|দিন|বলুন|পাঠান|জানান").containsMatchIn(t)) {
            score += 40; reasons += L.t("Asks for an OTP/PIN/code. Real banks and services never do.", "OTP/পিন/কোড চাইছে, সত্যিকারের ব্যাংক বা সেবা কখনও এটা চায় না")
        }
        if (Regex("lottery|winner|prize|লটারি|পুরস্কার|জিতেছেন|বিজয়ী").containsMatchIn(t)) {
            score += 30; reasons += L.t("Prize/lottery bait", "পুরস্কার/লটারির টোপ")
        }
        if (Regex("account.*(block|suspend|close)|একাউন্ট.*বন্ধ|অ্যাকাউন্ট.*বন্ধ|verify now|এখনই যাচাই").containsMatchIn(t)) {
            score += 30; reasons += L.t("Pressures you with a fake account-closure threat", "একাউন্ট বন্ধের ভয় দেখিয়ে তাড়া দিচ্ছে")
        }
        val urls = urlRe.findAll(text).map { it.value.trimEnd('.', ',', ')', '!') }.distinct().take(5).toList()
        var worst = 0
        urls.forEach { u ->
            val (s, r) = link(ctx, u)
            if (s > worst) worst = s
            r.forEach { reasons += "${u.take(40)}: $it" }
        }
        score += worst
        val level = when { score >= 60 -> Risk.HIGH; score >= 30 -> Risk.MEDIUM; else -> Risk.LOW }
        return Report(level, reasons)
    }

    private fun link(ctx: Context, raw: String): Pair<Int, List<String>> {
        var s = 0
        val r = mutableListOf<String>()
        val u = if (raw.startsWith("www.", true)) "http://$raw" else raw
        val host = try { URI(u).host?.lowercase() ?: "" } catch (e: Exception) { "" }
        if (host.isEmpty()) return 0 to emptyList()
        if (Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host)) { s += 40; r += L.t("Raw IP address instead of a name", "নামের বদলে সরাসরি IP ঠিকানা") }
        if (host in shorteners) { s += 15; r += L.t("Shortened link hides the real destination", "ছোট করা লিংক, আসল গন্তব্য লুকানো") }
        if (host.contains("xn--")) { s += 30; r += L.t("Lookalike-character address", "নকল অক্ষর দিয়ে বানানো ঠিকানা হতে পারে") }
        if (u.startsWith("http://", true)) { s += 10; r += L.t("Not secure (no HTTPS)", "নিরাপদ (HTTPS) নয়") }
        if (badTlds.any { host.endsWith(it) }) { s += 15; r += L.t("Domain type common in scam sites", "ফাঁদ সাইটে বেশি দেখা যায় এমন ডোমেইন") }
        if (host.count { it == '-' } >= 3) { s += 10; r += L.t("Unusually many hyphens", "অস্বাভাবিক বেশি হাইফেন") }
        if (u.contains("@")) { s += 25; r += L.t("@ sign inside the link (address trick)", "লিংকের ভেতরে @ চিহ্ন (ঠিকানা লুকানোর কৌশল)") }
        if (u.substringBefore('?').endsWith(".apk", true)) { s += 30; r += L.t("Direct APK download link", "সরাসরি APK ডাউনলোড লিংক") }
        brands.forEach { (b, official) ->
            if (host.contains(b) && official.none { host == it || host.endsWith(".$it") }) {
                s += 40; r += L.t("Uses the name $b but is not their real site", "$b-এর নাম ব্যবহার করছে, কিন্তু এটা তাদের আসল সাইট নয়")
            }
        }
        if (BlockList.isBlocked(ctx, host)) { s += 100; r += L.t("Listed as a malware or phishing site", "ম্যালওয়্যার বা ফিশিং সাইট হিসেবে তালিকাভুক্ত") }
        if (BadUrls.hit(ctx, u, host)) { s += 100; r += L.t("Listed as a malware-distribution link by abuse.ch URLhaus", "abuse.ch URLhaus-এর ক্ষতিকর লিংক তালিকায় আছে") }
        val key = Store.get(ctx, "sb_key")
        if (key.isNotBlank()) try {
            val body = JSONObject()
                .put("client", JSONObject().put("clientId", "securityguard").put("clientVersion", "2.0"))
                .put("threatInfo", JSONObject()
                    .put("threatTypes", JSONArray(listOf("MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION")))
                    .put("platformTypes", JSONArray(listOf("ANY_PLATFORM")))
                    .put("threatEntryTypes", JSONArray(listOf("URL")))
                    .put("threatEntries", JSONArray().put(JSONObject().put("url", u))))
            val (code, res) = Net.request("https://safebrowsing.googleapis.com/v4/threatMatches:find?key=$key",
                "POST", mapOf("Content-Type" to "application/json"), body.toString())
            if (code == 200 && JSONObject(res).has("matches")) { s += 100; r += L.t("Google says: malicious or phishing site!", "Google জানিয়েছে: ক্ষতিকর বা ফিশিং সাইট!") }
        } catch (e: Exception) { }
        return s to r
    }

    fun inspect(ctx: Context, source: String, text: String) {
        val rep = analyze(ctx, text)
        if (rep.level != Risk.LOW) Alerts.notify(ctx, "$source: ${rep.level.label()}", rep.reasons.joinToString("\n• ", "• "))
    }
}

object Breach {
    fun email(ctx: Context, email: String): String {
        val key = Store.get(ctx, "hibp_key")
        if (key.isBlank()) return L.t("Add a HaveIBeenPwned key in Settings (paid)", "সেটিংসে HaveIBeenPwned key দিন (এটা পেইড)")
        return try {
            val (code, body) = Net.request(
                "https://haveibeenpwned.com/api/v3/breachedaccount/${URLEncoder.encode(email, "UTF-8")}?truncateResponse=true",
                headers = mapOf("hibp-api-key" to key, "user-agent" to "SecurityGuard"))
            when (code) {
                200 -> { val a = JSONArray(body); L.t("Leaked in ${a.length()} sites: ", "${a.length()}টি সাইটে ফাঁস হয়েছে: ") + (0 until a.length()).joinToString(", ") { a.getJSONObject(it).getString("Name") } + L.t("\nChange your password on those sites.", "\nএই সাইটগুলোতে পাসওয়ার্ড বদলান।") }
                404 -> L.t("Not found in any known leak", "কোনো ফাঁসে পাওয়া যায়নি")
                401 -> L.t("Wrong key", "key ভুল")
                429 -> L.t("Too many requests, try later", "অনেক বেশি অনুরোধ, একটু পরে চেষ্টা করুন")
                else -> L.t("Could not check ($code)", "যাচাই করা গেল না ($code)")
            }
        } catch (e: Exception) { L.t("Internet problem", "ইন্টারনেট সমস্যা") }
    }

    fun password(pw: String): String {
        return try {
            val h = MessageDigest.getInstance("SHA-1").digest(pw.toByteArray()).joinToString("") { "%02X".format(it) }
            val (code, body) = Net.request("https://api.pwnedpasswords.com/range/${h.take(5)}")
            if (code != 200) return L.t("Could not check", "যাচাই করা গেল না")
            val n = body.lineSequence().firstOrNull { it.startsWith(h.drop(5), true) }?.substringAfter(':')?.trim()?.toLongOrNull()
            if (n == null) L.t("This password is not in any known leak list", "এই পাসওয়ার্ড কোনো ফাঁস তালিকায় নেই")
            else L.t("Danger! This password leaked $n times. Stop using it.", "বিপদ! এই পাসওয়ার্ড $n বার ফাঁস হয়েছে। এটা আর ব্যবহার করবেন না।")
        } catch (e: Exception) { L.t("Internet problem", "ইন্টারনেট সমস্যা") }
    }
}
